# safe-start

`safe-start` adds a quiet coaching skill and defense-in-depth hooks to Claude
Code for people new to coding, especially clinicians. It reduces common
accidental disclosure and data-loss mistakes. It is **not** a sandbox, a backup,
a secret manager, a data-loss guarantee, or a HIPAA compliance product.

It pairs with `clinician-first-cli-session`, the one-time Mac + Claude Code
build, break, and recover lesson. The installer below installs **safe-start
only**: the Claude Code skill and its hooks. It does not install the lesson.

## Install after the pinned release is published

This command is supported only after the public `v1.1.0` tag exists and every
gate in `HOSTING.md` has passed. Until then, the source is a release candidate
and the URL may return `404`; do not substitute mutable `main`.

```bash
/usr/bin/curl -fsSL https://raw.githubusercontent.com/dochobbs/OC_Safe_start/v1.1.0/install.sh | /bin/bash
```

The bootstrap and the package payload both default to the same `v1.1.0` tag.
The installer preserves unrelated Claude settings and hooks and must finish its
self-tests and registration before reporting success. Remote fetch and exact-tag
verification use macOS system Git and suppress inherited Git repository
redirects, injected/global/system configuration (including URL rewrites), trace
sinks, SSH-agent access, and interactive prompt helpers so the caller's shell
cannot silently change what ref is verified. Install and uninstall reset
executable lookup to the fixed macOS system path. Package validation, settings
mutation, and persistent hook commands bind `/usr/bin/python3 -I`, so a
PATH-injected Python wrapper or inherited Python startup path cannot replace the
reviewed runtime.

Remove it with:

```bash
/bin/bash ~/.claude/skills/safe-start/uninstall.sh
```

## Check a Mac + Claude setup

Run the read-only preflight from the project folder you intend to use:

```bash
/usr/bin/python3 -I ~/.claude/skills/safe-start/scripts/doctor.py
```

Run that installed path only after the pinned installer or an equivalent
reviewed package verification has established its provenance, and only when the
doctor is a regular non-symlink file. Presence at the expected path alone is not
enough; if either check is uncertain, do not execute it and treat the install as
unverified.

Add `--json` for stable structured output. The doctor reports the exact physical
working folder; macOS, Git, and Claude availability; Git repository state
without a worktree-cleanliness claim; whether Git author name/email are
configured and at which scope without printing either value; likely cloud-sync
risk; safe-start version and hook registration; known permission defaults from
user/project settings; and fixed `CLAUDE.md` locations. It binds Git probes to
macOS `/usr/bin/git` and deliberately avoids `git status`, which can execute a
repository-configured filter. Do not run the doctor in a workspace that contains
a credibly sensitive source.

Warnings keep a zero exit status because missing setup is what a doctor is
expected to find. A nonzero status is reserved for an invalid invocation or an
internal startup failure. Permission defaults in settings are not proof of the
active Claude session mode; use `/permissions` inside that Claude Code session.

## What it does

| Control | Behavior |
|---|---|
| Prompt guard | Locally rejects high-confidence secrets and structured identifiers without echoing the value; the user removes them and resubmits |
| Tool guard | Asks before covered destructive commands, sensitive/out-of-project reads or writes, and risky Git operations |
| Project on-ramp | Confirms location, inventories first, merges ignore/project rules without clobbering, stages named files, scans the exact staged set, and verifies the first commit |
| Git coaching | Offers a reviewed savepoint before risky work and verifies it in `git log`; never claims an automatic checkpoint happened |
| Git rescue | Explains unfinished merges, conflicts, and detached HEAD states before offering choices |
| Orientation | Surfaces changed location, cloud-sync risk, weakened permissions, and loose ends when relevant |
| Read-only doctor | Checks the Mac/Claude/Git setup without printing Git identity values or project contents; it omits worktree cleanliness and is not for a contaminated workspace |
| Sharing check | Reviews the exact share set, defaults GitHub to private, and states what the scan cannot prove |
| Teaching layer | Plans multi-step work, translates jargon, adjusts explanation volume, and gives plain-language recaps |

The prompt guard is intentionally stricter than the tool warnings: a detected
high-confidence value is rejected locally so it does not continue with the
prompt. Other covered tool actions normally use Claude Code's native ask flow.

## Security boundary and known limits

- Use synthetic data only in the first-session project. In ongoing work, use an
  appropriately de-identified derivative only when the organization has
  explicitly approved that workflow. Keep any real or re-identifiable source
  outside the agent workspace in an organization-approved encrypted system.
- `.gitignore` prevents ordinary Git tracking; it does not stop Claude or a
  local process from reading a file. An ignored `/private/` path is retained only
  as a legacy defensive exclusion, never as a place for PHI.
- Prefer environment variables, macOS Keychain, or an approved secret manager.
  If a project requires `.env`, never ask the agent to read, print, summarize,
  or echo it.
- Regexes cannot reliably identify free-text clinical narrative. A private Git
  repository is not an approved place for patient data.
- Native tool checks cover only hook events Claude Code emits. Bash inspection
  is best-effort: variables, scripts, aliases, nested interpreters, and future
  syntax can hide behavior.
- The hooks' own Git probes use macOS system Git with a scrubbed Git environment,
  disabled fsmonitor/automatic maintenance, and ignored submodules where
  applicable. That hardens the probe itself; it does not make every later Git
  command or repository configuration safe.
- In a contaminated workspace, do not run the doctor or any Git command and
  label it metadata-only. Use exact-path filesystem metadata only, and defer Git
  checks until the sensitive source is confirmed absent. A trusted external
  runner may capture Git evidence only when it independently sandboxes every
  external helper.
- Scope warnings are not an OS sandbox. Keep Claude's permission prompts on and
  use least-privilege filesystem access for a real boundary.
- Git commits are restore points, not backups. They protect only reviewed work
  that was actually committed.
- Before a public push, review author and committer name and email for every
  outgoing commit. Current Git config does not rewrite existing commits; require
  informed approval or an explicitly approved and reverified history repair.
  Offer a user-chosen pseudonymous name and repository-local GitHub noreply
  address rather than inventing either value.

## Claude controls and Git history

Teach controls when they become useful: `Esc` stops current work, `Shift+Tab`
cycles available permission modes, `/plan` supports review-focused planning but
does not sandbox modifying shell commands,
`/permissions` shows the active session's permission configuration, and
`/rewind` or `Esc` twice while the prompt is empty opens Claude's checkpoint
choices. Keep Manual (`default`), the ask-before-acting flow, for a first
session unless the user makes a deliberate informed choice.

Claude checkpoints are saved with the conversation and may survive resume, but
cover only changes made directly through Claude's file-editing tools. They do
not capture Bash file operations such as `rm`, `mv`, or `cp`. Git commits are
durable project history. Neither reliably reverses external side effects such
as uploads, API calls, deployments, or messages. A finished first session
should hand back the absolute project/tool paths, exact run command, verified
commit, clean/dirty Git state, push and visibility state, verified
hook-registration state, and one next feature.

## Platform

The supported audience is a beginner using Claude Code on macOS with Git and
Python 3.9 or newer. safe-start does not claim support for other assistants or
operating systems.

## License

safe-start is licensed under the Apache License, Version 2.0. See the bundled
`LICENSE` file.

## Layout

```text
safe-start/
├── SKILL.md
├── LICENSE
├── install.sh / uninstall.sh
├── hooks/
│   ├── pretooluse.py
│   ├── userpromptsubmit.py
│   ├── sessionstart.py
│   └── lib/{detectors,common}.py
├── install/merge_settings.py
├── scripts/doctor.py
├── templates/{gitignore,CLAUDE.md}
└── tests/
```

## Develop and test

```bash
python3 tests/test_detectors.py
python3 tests/test_doctor.py
python3 tests/test_hooks.py
python3 tests/test_lifecycle.py
```

In the private `offcall` source checkout, also run this from the repository root:

```bash
python3 scripts/build_skill_archives.py --check
```

That archive builder is a source-repository release check; it is not included in
the standalone public distribution copy. Do not publish or stage-demo a build
until the lifecycle, package, clean-install, and clean-uninstall release gates
also pass. The source-repository security model is the authority for those gates
and for every user-facing safety claim.
