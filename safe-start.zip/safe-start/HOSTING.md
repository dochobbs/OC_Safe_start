# Publishing safe-start

**Distribution repository:** `https://github.com/dochobbs/OC_Safe_start`

**Release target:** `v1.1.0`. The version tag, not the mutable `main` branch, is
the supported installation boundary. Do not announce the release as available
until that public tag exists and every release gate below passes.

The canonical command for this release is:

```bash
/usr/bin/curl -fsSL https://raw.githubusercontent.com/dochobbs/OC_Safe_start/v1.1.0/install.sh | /bin/bash
```

Source of truth remains this `offcall` checkout. The public repository is the
reviewed distribution copy.

## Version-pinning contract

The bootstrap script above is fetched from `v1.1.0`, and its default payload
fetch must resolve the same `v1.1.0` tag. Never fetch a pinned bootstrap and then
silently install payload files from `main`.

Local development may use an explicit `SAFE_START_SRC` checkout. Release and
stage-demo instructions must use the pinned public tag so the tested bytes and
the installed bytes can be compared.

## Public repository shape

Copy the contents of `skills/safe-start/` to the public repository root. The
root must contain `LICENSE`, `VERSION`, `install.sh`, `uninstall.sh`,
`SKILL.md`, `hooks/`, `install/`, `scripts/`, `templates/`, `tests/`, and user
documentation. Do not include Git metadata, caches, local state, credentials,
sensitive fixtures, or real patient data.

The installer installs **safe-start only** into `~/.claude`: the coaching skill,
Claude Code hooks, templates, and owned state. It does not install
`clinician-first-cli-session`. This distribution supports Claude Code on macOS;
it does not claim cross-assistant or cross-platform enforcement.

## Release gates

Treat the checklist below as the public distribution contract. The private
source checkout also maintains the fuller security model used during review.
Before creating or announcing the tag:

1. Run detector, hook, doctor, lifecycle, persona-harness, and
   package-validation tests on the oldest supported Apple Python and the
   current development Python. The doctor suite must use temporary homes and
   mocked subprocesses; it must never inspect the test operator's real
   `~/.claude`. Persona self-tests validate fixtures and isolation only; they
   are not evidence that the coaching behavior passed. Hook tests must prove
   that configured fsmonitor executables cannot run during internal Git probes.
   Doctor tests must prove that a PATH-injected Git wrapper is never selected
   and that repository-local fsmonitor/filter helpers cannot run during its
   fixed metadata probes.
   Lifecycle tests must prove that hostile inherited `GIT_*` repository
   redirects, global/system config and URL rewrites, trace sinks, and prompt
   helpers cannot alter the remote clone or exact-tag verification, and that a
   PATH-injected wrappers for Git, Python, Bash, and core install/uninstall
   utilities are never executed; inherited Python startup paths cannot run; and
   every installed hook command remains bound to `/usr/bin/python3 -I`.
2. Forward-run all nine persona scenarios with fresh roleplayer, assistant,
   and evaluator contexts. Keep tools disabled unless an external runner
   enforces every manifest denial. For each of the eight tool-using scenarios,
   require the trusted runner's complete action trace, atomically seal it mode
   `0400` outside the assistant write allowlist, and retain the raw runner log.
   `missing-git-tools` remains conversational-only and has no tool events.
   Require every rubric's score, required-item, forbidden-behavior, turn-budget,
   action-evidence, and deterministic post-state rule to pass through the
   `persona_regression.py grade` check; retain transcripts, sealed traces,
   evaluator results, and raw logs as release evidence. The grader binds those
   artifacts, verifies exact source references, arithmetic, budgets, known
   unsafe-action backstops, post-state invariants, and verdict consistency. A
   release reviewer must still compare the trace to the trusted runner log and
   spot-check whether each cited quote semantically supports its rating; the
   command scanner is intentionally not an exhaustive shell parser.
3. From the `offcall` source-repository root, verify the generated archives and
   executable modes:

   ```bash
   python3 scripts/build_skill_archives.py --check
   ```

   This source-only builder is not part of the standalone public copy.
4. Install into a fresh isolated home, run both doctor renderers, and confirm
   every expected hook is registered, state/config permissions are private, and
   the installed version is `1.1.0`:

   ```bash
   /usr/bin/python3 -I ~/.claude/skills/safe-start/scripts/doctor.py
   /usr/bin/python3 -I ~/.claude/skills/safe-start/scripts/doctor.py --json
   ```

   A settings default reported by the doctor is not evidence of the effective
   permission mode in an already-running Claude Code session.
5. Exercise malformed/unwritable settings failures and verify the prior install
   and settings remain intact with a nonzero exit and no success banner.
6. Exercise uninstall success and forced deregistration failure. Never delete
   hook scripts while owned registrations remain active.
7. Copy the reviewed package to the public repository, create the `v1.1.0` tag,
   push it, and compare that tag with the reviewed package.
8. Run the pinned one-liner on a clean Mac, then run the documented uninstall:

   ```bash
   /bin/bash ~/.claude/skills/safe-start/uninstall.sh
   ```

9. Re-run the pinned install once to test the supported update/reinstall path.
   Confirm unrelated Claude settings and hooks remain unchanged.

Only then call the release live or use it in a stage demo.

## Test without touching the real Claude home

After the public tag exists:

```bash
HOME=$(/usr/bin/mktemp -d) /bin/bash -c '/usr/bin/curl -fsSL https://raw.githubusercontent.com/dochobbs/OC_Safe_start/v1.1.0/install.sh | /bin/bash'
```

Inspect the isolated home rather than trusting the success banner alone. Verify
the installed `VERSION`, hook registrations, doctor human/JSON output, file
modes, and uninstall result. Ordinary doctor warnings must remain exit zero;
only invalid doctor invocation or startup failure may be nonzero.

## Publish a later release

Choose a new semantic version, update `VERSION` and every pinned bootstrap and
payload reference together, repeat the full release gates, then publish a new
immutable tag. Update user-facing install commands only after that tag has been
verified. Never repoint an existing tag or advise users to install from `main`.

## Security notes

- A public tag is executable code. Review the exact tag before telling users to
  pipe it to a shell; a tag is versioned, but an unsigned tag does not eliminate
  maintainer-account compromise.
- `.gitignore`, prompt regexes, and advisory hooks do not make PHI safe. Use
  synthetic data only in a first-session project. In ongoing work, use an
  appropriately de-identified derivative only when the organization has
  explicitly approved that workflow.
- Keep real or re-identifiable source data in an organization-approved encrypted
  system outside the workspace and model context.
- macOS is the supported v1 platform.
