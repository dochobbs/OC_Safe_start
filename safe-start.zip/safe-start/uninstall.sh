#!/bin/bash
# SPDX-License-Identifier: Apache-2.0
# Remove safe-start only after its owned hooks are verifiably deregistered.
set -euo pipefail
SAFE_SYSTEM_PATH="/usr/bin:/bin:/usr/sbin:/sbin"
SYSTEM_PYTHON="/usr/bin/python3"
# Deregistration executes installed code and then removes files. Bind every
# executable lookup before inspecting or mutating the installation.
export PATH="$SAFE_SYSTEM_PATH"
unset PYTHONHOME PYTHONINSPECT PYTHONPATH PYTHONSTARTUP
export PYTHONDONTWRITEBYTECODE=1
export PYTHONNOUSERSITE=1

CLAUDE_LINK="${HOME:?HOME must be set}/.claude"
CLAUDE_DIR=""
SKILLS_DIR=""
DEST=""
STATE_DIR=""
MERGER=""
HOOKS_DIR=""

say() { printf '%s\n' "$*"; }

prepare_uninstall_paths() {
  local logical_skills
  if [ ! -d "$CLAUDE_LINK" ]; then
    say "safe-start: $CLAUDE_LINK is not a usable Claude directory."
    return 1
  fi
  logical_skills="$CLAUDE_LINK/skills"
  if [ -L "$logical_skills" ] || [ ! -d "$logical_skills" ]; then
    say "safe-start: $logical_skills must be a real directory, not a link."
    return 1
  fi

  CLAUDE_DIR="$(CDPATH= cd -- "$CLAUDE_LINK" && pwd -P)" || return 1
  SKILLS_DIR="$(CDPATH= cd -- "$logical_skills" && pwd -P)" || return 1
  if [ "$SKILLS_DIR" != "$CLAUDE_DIR/skills" ]; then
    say "safe-start: $logical_skills resolves outside the Claude directory."
    return 1
  fi
  DEST="$SKILLS_DIR/safe-start"
  STATE_DIR="$CLAUDE_DIR/safe-start"
  MERGER="$DEST/install/merge_settings.py"
  HOOKS_DIR="$DEST/hooks"
}

managed_roots_are_safe() {
  [ -n "$CLAUDE_DIR" ] \
    && [ -d "$CLAUDE_DIR" ] \
    && [ ! -L "$CLAUDE_DIR" ] \
    && [ -d "$SKILLS_DIR" ] \
    && [ ! -L "$SKILLS_DIR" ] \
    && [ "$SKILLS_DIR" = "$CLAUDE_DIR/skills" ] \
    && [ "$(CDPATH= cd -- "$CLAUDE_DIR" 2>/dev/null && pwd -P)" = "$CLAUDE_DIR" ] \
    && [ "$(CDPATH= cd -- "$SKILLS_DIR" 2>/dev/null && pwd -P)" = "$SKILLS_DIR" ]
}

managed_tree_is_safe() {
  local candidate="$1"
  local parent="$2"
  [ "${candidate%/*}" = "$parent" ] \
    && [ ! -L "$candidate" ] \
    && { [ ! -e "$candidate" ] || [ -d "$candidate" ]; }
}

installed_layout_is_safe() {
  [ -d "$DEST/install" ] \
    && [ ! -L "$DEST/install" ] \
    && [ "$(CDPATH= cd -- "$DEST/install" 2>/dev/null && pwd -P)" = "$DEST/install" ] \
    && [ -d "$HOOKS_DIR" ] \
    && [ ! -L "$HOOKS_DIR" ] \
    && [ "$(CDPATH= cd -- "$HOOKS_DIR" 2>/dev/null && pwd -P)" = "$HOOKS_DIR" ] \
    && [ -f "$MERGER" ] \
    && [ ! -L "$MERGER" ]
}

if ! prepare_uninstall_paths; then
  say "Nothing was removed."
  exit 1
fi

if ! managed_roots_are_safe \
  || ! managed_tree_is_safe "$DEST" "$SKILLS_DIR" \
  || ! managed_tree_is_safe "$STATE_DIR" "$CLAUDE_DIR"; then
  say "safe-start: install paths are not safe to remove."
  say "Nothing was removed; repair/reinstall safe-start, then uninstall again."
  exit 1
fi

SCRIPT_FILE="${BASH_SOURCE[0]:-}"
SCRIPT_DIR=""
if [ -n "$SCRIPT_FILE" ] && [ -f "$SCRIPT_FILE" ] && [ ! -L "$SCRIPT_FILE" ]; then
  SCRIPT_PARENT="${SCRIPT_FILE%/*}"
  if [ "$SCRIPT_PARENT" = "$SCRIPT_FILE" ]; then
    SCRIPT_PARENT="."
  fi
  SCRIPT_DIR="$(CDPATH= cd -- "$SCRIPT_PARENT" && pwd -P)"
fi
if [ "$SCRIPT_DIR" != "$DEST" ]; then
  say "safe-start: run the regular installed uninstaller at $DEST/uninstall.sh."
  say "Nothing was removed."
  exit 1
fi

if [ ! -x "$SYSTEM_PYTHON" ]; then
  say "safe-start: Python 3 is required to deregister the guards safely."
  say "Nothing was removed."
  exit 1
fi

if ! installed_layout_is_safe; then
  say "safe-start: cannot find $MERGER, so guard removal cannot be verified."
  say "Nothing was removed; repair/reinstall safe-start, then uninstall again."
  exit 1
fi

if ! "$SYSTEM_PYTHON" -I "$MERGER" remove "$HOOKS_DIR" \
  --claude-dir "$CLAUDE_DIR"; then
  say "safe-start: guard deregistration failed."
  say "Nothing was removed; the installed scripts are preserved for recovery."
  exit 1
fi

if ! "$SYSTEM_PYTHON" -I "$MERGER" verify-absent "$HOOKS_DIR" \
  --claude-dir "$CLAUDE_DIR" >/dev/null; then
  say "safe-start: owned hooks still appear in settings after deregistration."
  say "Nothing was removed; the installed scripts are preserved for recovery."
  exit 1
fi

if ! managed_roots_are_safe \
  || ! managed_tree_is_safe "$DEST" "$SKILLS_DIR" \
  || ! managed_tree_is_safe "$STATE_DIR" "$CLAUDE_DIR" \
  || ! installed_layout_is_safe; then
  say "safe-start: install paths changed during deregistration."
  say "Installed files were preserved; repair/reinstall before retrying."
  exit 1
fi

rm -rf -- "$DEST"
if [ -d "$STATE_DIR" ]; then
  rm -rf -- "$STATE_DIR"
fi

say "safe-start removed. Your other settings and hooks are untouched."
