"""Hermetic tests for the read-only safe-start doctor.

The suite always points HOME at a temporary directory and mocks every external
command. It never reads or writes the developer's real ~/.claude directory.

Runnable two ways:
  python3 tests/test_doctor.py
  pytest tests/test_doctor.py
"""

import contextlib
import importlib.util
import io
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import tempfile
import unittest
from unittest import mock


ROOT = Path(__file__).resolve().parent.parent
DOCTOR_PATH = ROOT / "scripts" / "doctor.py"
SPEC = importlib.util.spec_from_file_location("safe_start_doctor_under_test", DOCTOR_PATH)
assert SPEC is not None and SPEC.loader is not None
doctor = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(doctor)


GIT = "/usr/bin/git"
CLAUDE = "/opt/homebrew/bin/claude"
PYTHON = "/usr/bin/python3"
IDENTITY_NAME = "Dr Secret Name"
IDENTITY_EMAIL = "private-address@example.invalid"


def _completed(argv, returncode=0, stdout=""):
    return subprocess.CompletedProcess(argv, returncode, stdout=stdout, stderr="")


def _finder(name):
    return {"git": GIT, "claude": CLAUDE, "python3": PYTHON}.get(name)


def _hook_settings(permission_mode="default", python_path=PYTHON):
    hooks_dir = ROOT / "hooks"
    commands = {
        script: "%s -I %s" % (
            shlex.quote(str(python_path)),
            shlex.quote(str(hooks_dir / script)),
        )
        for script in ("pretooluse.py", "userpromptsubmit.py", "sessionstart.py")
    }
    return {
        "permissions": {"defaultMode": permission_mode},
        "hooks": {
            "PreToolUse": [{
                "matcher": "Bash|Read|Glob|Grep|Write|Edit|NotebookEdit",
                "hooks": [{"type": "command", "command": commands["pretooluse.py"]}],
            }],
            "UserPromptSubmit": [{
                "matcher": "",
                "hooks": [{
                    "type": "command",
                    "command": commands["userpromptsubmit.py"],
                }],
            }],
            "SessionStart": [{
                "matcher": "",
                "hooks": [{"type": "command", "command": commands["sessionstart.py"]}],
            }],
        },
    }


def _git_and_claude_runner(project, *, inside=True, clean=True):
    """Return a subprocess.run side effect with identity values as bait."""
    physical = str(project.resolve())
    safe_repo = (GIT, "-C", physical) + tuple(doctor.SAFE_GIT_CONFIG)

    def run(argv, **kwargs):
        argv = [str(item) for item in argv]
        command = tuple(argv)
        if command == (GIT, "--version"):
            return _completed(argv, stdout="git version 2.49.0 (Apple Git-154)\n")
        if command == (CLAUDE, "--version"):
            return _completed(argv, stdout="2.1.3 (Claude Code)\n")
        if command == safe_repo + ("rev-parse", "--is-inside-work-tree"):
            return _completed(argv, 0 if inside else 128, "true\n" if inside else "")
        if command == safe_repo + ("rev-parse", "--show-toplevel"):
            return _completed(argv, stdout=physical + "\n")
        if command == safe_repo + (
            "status", "--porcelain=v1", "-z", "--untracked-files=normal",
            "--ignore-submodules=all",
        ):
            return _completed(argv, stdout="" if clean else " M tool.py\0")
        if command == safe_repo + (
            "config", "--local", "--type=bool", "--get", "extensions.worktreeConfig",
        ):
            return _completed(argv, 1)

        # The fake returns real-looking identity strings even though the doctor
        # sends those probes to DEVNULL. They must never reach either renderer.
        if command == (
            GIT, "-C", physical, *doctor.SAFE_GIT_CONFIG,
            "config", "--local", "--get", "user.name",
        ):
            return _completed(argv, 1, IDENTITY_NAME + "\n")
        if command == (
            GIT, "-C", physical, *doctor.SAFE_GIT_CONFIG,
            "config", "--local", "--get", "user.email",
        ):
            return _completed(argv, 0, IDENTITY_EMAIL + "\n")
        if command == (
            GIT, *doctor.SAFE_GIT_CONFIG,
            "config", "--global", "--get", "user.name",
        ):
            return _completed(argv, 0, IDENTITY_NAME + "\n")
        if command == (
            GIT, *doctor.SAFE_GIT_CONFIG,
            "config", "--global", "--get", "user.email",
        ):
            return _completed(argv, 1, IDENTITY_EMAIL + "\n")
        if command in {
            (
                GIT, *doctor.SAFE_GIT_CONFIG,
                "config", "--system", "--get", "user.name",
            ),
            (
                GIT, *doctor.SAFE_GIT_CONFIG,
                "config", "--system", "--get", "user.email",
            ),
        }:
            return _completed(argv, 1)
        raise AssertionError("unexpected subprocess: %r" % (command,))

    return run


class DoctorTests(unittest.TestCase):
    def test_non_command_owned_hook_is_reported_as_mismatch(self):
        with tempfile.TemporaryDirectory(prefix="safe-start-doctor-") as raw:
            base = Path(raw)
            home = base / "home"
            project = base / "project"
            (home / ".claude").mkdir(parents=True)
            project.mkdir()
            settings = _hook_settings()
            settings["hooks"]["SessionStart"][0]["hooks"][0]["type"] = "http"
            (home / ".claude" / "settings.json").write_text(json.dumps(settings))

            with mock.patch.dict(
                os.environ, {"HOME": str(home)}, clear=False
            ), mock.patch.object(
                doctor.subprocess,
                "run",
                side_effect=_git_and_claude_runner(project),
            ):
                report = doctor.collect_report(
                    cwd=project,
                    system_name="Darwin",
                    mac_version="15.5",
                    finder=_finder,
                )

            self.assertEqual(report["hooks"]["status"], "mismatch")
            self.assertFalse(report["hooks"]["registered"])

    def test_async_owned_hook_is_reported_as_mismatch(self):
        with tempfile.TemporaryDirectory(prefix="safe-start-doctor-") as raw:
            base = Path(raw)
            home = base / "home"
            project = base / "project"
            (home / ".claude").mkdir(parents=True)
            project.mkdir()
            settings = _hook_settings()
            settings["hooks"]["PreToolUse"][0]["hooks"][0]["async"] = True
            (home / ".claude" / "settings.json").write_text(json.dumps(settings))

            with mock.patch.dict(
                os.environ, {"HOME": str(home)}, clear=False
            ), mock.patch.object(
                doctor.subprocess,
                "run",
                side_effect=_git_and_claude_runner(project),
            ):
                report = doctor.collect_report(
                    cwd=project,
                    system_name="Darwin",
                    mac_version="15.5",
                    finder=_finder,
                )

            self.assertEqual(report["hooks"]["status"], "mismatch")
            self.assertFalse(report["hooks"]["registered"])

    def test_hook_registration_survives_current_path_interpreter_drift(self):
        with tempfile.TemporaryDirectory(prefix="safe-start-doctor-") as raw:
            base = Path(raw)
            home = base / "home"
            project = base / "project"
            (home / ".claude").mkdir(parents=True)
            project.mkdir()
            (home / ".claude" / "settings.json").write_text(
                json.dumps(_hook_settings())
            )

            def drifted_finder(name):
                return {
                    "git": GIT,
                    "claude": CLAUDE,
                    "python3": PYTHON,
                }.get(name)

            with mock.patch.dict(
                os.environ, {"HOME": str(home)}, clear=False
            ), mock.patch.object(
                doctor.subprocess,
                "run",
                side_effect=_git_and_claude_runner(project),
            ):
                report = doctor.collect_report(
                    cwd=project,
                    system_name="Darwin",
                    mac_version="15.5",
                    finder=drifted_finder,
                )

            self.assertEqual(report["hooks"]["status"], "registered")
            self.assertTrue(report["hooks"]["registered"])

    def test_hook_registration_rejects_non_system_interpreter(self):
        with tempfile.TemporaryDirectory(prefix="safe-start-doctor-") as raw:
            base = Path(raw)
            home = base / "home"
            project = base / "project"
            foreign_python = base / "installed-bin" / "python3"
            (home / ".claude").mkdir(parents=True)
            project.mkdir()
            foreign_python.parent.mkdir()
            foreign_python.write_text("#!/bin/sh\nexit 0\n")
            foreign_python.chmod(0o700)
            (home / ".claude" / "settings.json").write_text(
                json.dumps(_hook_settings(python_path=foreign_python))
            )

            with mock.patch.dict(
                os.environ, {"HOME": str(home)}, clear=False
            ), mock.patch.object(
                doctor.subprocess,
                "run",
                side_effect=_git_and_claude_runner(project),
            ):
                report = doctor.collect_report(
                    cwd=project,
                    system_name="Darwin",
                    mac_version="15.5",
                    finder=_finder,
                )

            self.assertEqual(report["hooks"]["status"], "mismatch")
            self.assertFalse(report["hooks"]["registered"])

    def test_command_runner_removes_git_redirect_and_trace_environment(self):
        captured = {}

        def runner(argv, **kwargs):
            captured.update(kwargs["env"])
            return _completed(argv, stdout="git version test\n")

        inherited = {
            "GIT_CONFIG_COUNT": "1",
            "GIT_CONFIG_KEY_0": "core.fsmonitor",
            "GIT_CONFIG_VALUE_0": "malicious-helper",
            "GIT_DIR": "/outside/repository",
            "GIT_TRACE": "/outside/trace.log",
            "GIT_WORK_TREE": "/outside/worktree",
        }
        with mock.patch.dict(os.environ, inherited, clear=False), mock.patch.object(
            doctor.subprocess, "run", side_effect=runner
        ):
            result = doctor._run_command([GIT, "--version"])

        self.assertEqual(result["returncode"], 0)
        self.assertEqual(captured["GIT_CONFIG_COUNT"], "0")
        self.assertEqual(captured["GIT_CONFIG_GLOBAL"], "/dev/null")
        self.assertEqual(captured["GIT_CONFIG_NOSYSTEM"], "1")
        self.assertEqual(captured["GIT_CONFIG_SYSTEM"], "/dev/null")
        self.assertEqual(captured["GIT_OPTIONAL_LOCKS"], "0")
        self.assertEqual(captured["GIT_PAGER"], "")
        self.assertEqual(captured["PAGER"], "")
        self.assertNotIn("GIT_CONFIG_KEY_0", captured)
        self.assertNotIn("GIT_DIR", captured)
        self.assertNotIn("GIT_TRACE", captured)
        self.assertNotIn("GIT_WORK_TREE", captured)

    @unittest.skipUnless(Path(GIT).is_file(), "requires /usr/bin/git")
    def test_default_macos_probe_ignores_path_injected_git_wrapper(self):
        with tempfile.TemporaryDirectory(prefix="safe-start-doctor-path-") as raw:
            base = Path(raw)
            home = base / "home"
            project = base / "project"
            fake_bin = base / "fake-bin"
            home.mkdir()
            project.mkdir()
            fake_bin.mkdir()
            marker = base / "path-git-ran"
            wrapper = fake_bin / "git"
            wrapper.write_text(
                "#!/bin/sh\nprintf ran > %s\nexit 99\n"
                % shlex.quote(str(marker)),
                encoding="utf-8",
            )
            wrapper.chmod(0o700)

            with mock.patch.dict(
                os.environ,
                {"HOME": str(home), "PATH": str(fake_bin)},
                clear=False,
            ):
                report = doctor.collect_report(
                    cwd=project,
                    home=home,
                    system_name="Darwin",
                    mac_version="15.0",
                )

            self.assertEqual(report["commands"]["git"]["path"], GIT)
            self.assertFalse(marker.exists())

    @unittest.skipUnless(Path(GIT).is_file(), "requires /usr/bin/git")
    def test_hostile_git_config_cannot_run_helpers_and_identity_is_preserved(self):
        with tempfile.TemporaryDirectory(prefix="safe-start-doctor-git-") as raw:
            base = Path(raw)
            home = base / "home"
            project = base / "project"
            home.mkdir()
            project.mkdir()

            clean_env = {
                key: value for key, value in os.environ.items()
                if not key.startswith("GIT_")
            }
            clean_env.update({
                "GIT_CONFIG_GLOBAL": "/dev/null",
                "GIT_CONFIG_NOSYSTEM": "1",
                "HOME": str(home),
                "LC_ALL": "C",
            })
            subprocess.run(
                [GIT, "init", "--quiet", str(project)],
                check=True,
                env=clean_env,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )

            fsmonitor_marker = base / "fsmonitor-ran"
            fsmonitor = base / "fsmonitor.sh"
            fsmonitor.write_text(
                "#!/bin/sh\nprintf ran > %s\nexit 0\n"
                % shlex.quote(str(fsmonitor_marker)),
                encoding="utf-8",
            )
            fsmonitor.chmod(0o700)
            hooks = base / "hooks"
            hooks.mkdir()
            hook_marker = base / "hook-ran"
            hook = hooks / "post-index-change"
            hook.write_text(
                "#!/bin/sh\nprintf ran > %s\n"
                % shlex.quote(str(hook_marker)),
                encoding="utf-8",
            )
            hook.chmod(0o700)
            filter_marker = base / "filter-ran"
            clean_filter = base / "clean-filter.sh"
            clean_filter.write_text(
                "#!/bin/sh\nprintf ran > %s\n/bin/cat\n"
                % shlex.quote(str(filter_marker)),
                encoding="utf-8",
            )
            clean_filter.chmod(0o700)

            for key, value in (
                ("core.fsmonitor", str(fsmonitor)),
                ("core.hooksPath", str(hooks)),
                ("gc.auto", "1"),
                ("maintenance.auto", "true"),
                ("filter.doctor-probe.clean", str(clean_filter)),
                ("filter.doctor-probe.required", "true"),
            ):
                subprocess.run(
                    [GIT, "-C", str(project), "config", "--local", key, value],
                    check=True,
                    env=clean_env,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )

            (project / ".gitattributes").write_text(
                "payload.txt filter=doctor-probe\n", encoding="utf-8"
            )
            payload = project / "payload.txt"
            payload.write_text("first version\n", encoding="utf-8")
            subprocess.run(
                [GIT, "-C", str(project), "add", ".gitattributes", "payload.txt"],
                check=True,
                env=clean_env,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            self.assertTrue(filter_marker.is_file())
            for generated in (fsmonitor_marker, hook_marker, filter_marker):
                if generated.exists():
                    generated.unlink()

            # Prove ordinary status executes the configured fsmonitor. The
            # clean filter was proved above during add; the guarded runner below
            # makes any later status dispatch observable as a filter-risk marker.
            subprocess.run(
                [GIT, "-C", str(project), "status", "--porcelain=v1"],
                check=True,
                env=clean_env,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            self.assertTrue(fsmonitor_marker.is_file())
            for generated in (fsmonitor_marker, hook_marker, filter_marker):
                if generated.exists():
                    generated.unlink()

            (home / ".gitconfig").write_text(
                "[user]\n"
                "\tname = Doctor Test\n"
                "\temail = doctor-test@example.invalid\n"
                "[core]\n"
                "\tfsmonitor = %s\n"
                "\thooksPath = %s\n"
                "[gc]\n"
                "\tauto = 1\n"
                "[maintenance]\n"
                "\tauto = true\n"
                % (str(fsmonitor), str(hooks)),
                encoding="utf-8",
            )
            hostile_global = base / "hostile-global-config"
            hostile_system = base / "hostile-system-config"
            hostile_global.write_text("[invalid\n", encoding="utf-8")
            hostile_system.write_text("[invalid\n", encoding="utf-8")

            inherited = {
                "GIT_CONFIG_GLOBAL": str(hostile_global),
                "GIT_CONFIG_SYSTEM": str(hostile_system),
                "GIT_PAGER": str(fsmonitor),
                "GIT_TRACE": str(base / "trace-leak"),
                "HOME": str(home),
            }
            warnings = []
            real_run = subprocess.run

            def filter_guarded_run(argv, **kwargs):
                if "status" in [str(item) for item in argv]:
                    filter_marker.write_text("status dispatched\n", encoding="utf-8")
                return real_run(argv, **kwargs)

            with mock.patch.dict(
                os.environ, inherited, clear=False
            ), mock.patch.object(
                doctor.subprocess, "run", side_effect=filter_guarded_run
            ):
                report = doctor._git_report(
                    {
                        "available": True,
                        "path": GIT,
                    },
                    project,
                    warnings,
                )

            self.assertTrue(report["repository"]["inside"])
            self.assertIsNone(report["repository"]["clean"])
            self.assertTrue(report["identity"]["complete"])
            self.assertEqual(
                report["identity"]["name"]["effective_scope"], "global"
            )
            self.assertEqual(
                report["identity"]["email"]["effective_scope"], "global"
            )
            self.assertFalse(fsmonitor_marker.exists())
            self.assertFalse(hook_marker.exists())
            self.assertFalse(filter_marker.exists())
            self.assertFalse((base / "trace-leak").exists())
            self.assertIn(
                "git_cleanliness_not_checked",
                {item["code"] for item in warnings},
            )

    def test_complete_mac_report_is_exact_safe_and_plain(self):
        with tempfile.TemporaryDirectory(prefix="safe-start-doctor-") as raw:
            base = Path(raw)
            home = base / "home"
            project = base / "Library" / "CloudStorage" / "Dropbox" / "tiny-tool"
            home.mkdir()
            (project / ".claude").mkdir(parents=True)
            (home / ".claude").mkdir()
            (project / "CLAUDE.md").write_text("project instructions are not doctor output\n")
            (home / ".claude" / "settings.json").write_text(
                json.dumps(_hook_settings())
            )
            (project / ".claude" / "settings.json").write_text(
                json.dumps({"permissions": {"defaultMode": "plan"}})
            )
            alias = base / "project-alias"
            alias.symlink_to(project, target_is_directory=True)

            with mock.patch.dict(os.environ, {"HOME": str(home)}, clear=False), mock.patch.object(
                doctor.subprocess,
                "run",
                side_effect=_git_and_claude_runner(project),
            ):
                report = doctor.collect_report(
                    cwd=alias,
                    system_name="Darwin",
                    mac_version="15.5",
                    finder=_finder,
                )

            self.assertEqual(report["cwd"]["physical"], str(project.resolve()))
            self.assertTrue(report["platform"]["is_macos"])
            self.assertTrue(report["commands"]["git"]["available"])
            self.assertTrue(report["commands"]["claude"]["available"])
            self.assertIsNone(report["git"]["repository"]["clean"])
            self.assertEqual(
                report["git"]["identity"]["name"]["effective_scope"], "global"
            )
            self.assertEqual(
                report["git"]["identity"]["email"]["effective_scope"], "local"
            )
            self.assertTrue(report["cloud_sync"]["likely"])
            self.assertEqual(report["cloud_sync"]["provider"], "Dropbox")
            self.assertEqual(report["safe_start"]["version"], "1.1.0")
            self.assertEqual(report["hooks"]["status"], "registered")
            self.assertTrue(report["hooks"]["registered"])
            self.assertTrue(report["claude_md"]["project_present"])
            modes = {
                item["scope"]: item["mode"]
                for item in report["permissions"]["configured_defaults"]
            }
            self.assertEqual(modes, {"user": "default", "project": "plan"})
            self.assertFalse(report["permissions"]["active_session_mode_observed"])

            human = doctor.render_human(report)
            encoded = json.dumps(report, sort_keys=True)
            for forbidden in (IDENTITY_NAME, IDENTITY_EMAIL, "project instructions"):
                self.assertNotIn(forbidden, human)
                self.assertNotIn(forbidden, encoded)
            self.assertIn("Working folder (physical):", human)
            self.assertIn("user=Manual (default)", human)
            self.assertIn("not current session mode", human)
            self.assertIn("use /permissions", human)
            self.assertIn("state unknown", human)

    def test_missing_tools_non_mac_and_missing_setup_are_warnings(self):
        with tempfile.TemporaryDirectory(prefix="safe-start-doctor-") as raw:
            base = Path(raw)
            home = base / "home"
            project = base / "project"
            home.mkdir()
            project.mkdir()

            def finder(name):
                return PYTHON if name == "python3" else None

            with mock.patch.dict(os.environ, {"HOME": str(home)}, clear=False), mock.patch.object(
                doctor.subprocess,
                "run",
                side_effect=AssertionError("no subprocess should run"),
            ):
                report = doctor.collect_report(
                    cwd=project,
                    system_name="Linux",
                    mac_version="",
                    finder=finder,
                )

            codes = {item["code"] for item in report["warnings"]}
            self.assertIn("unsupported_platform", codes)
            self.assertIn("git_missing", codes)
            self.assertIn("claude_missing", codes)
            self.assertIn("hooks_not_registered", codes)
            self.assertEqual(
                report["hooks"]["settings_path"],
                str(home.resolve() / ".claude/settings.json"),
            )
            self.assertIsNone(report["git"]["repository"]["inside"])

            # main returns zero for the already-collected ordinary warnings.
            stdout = io.StringIO()
            with mock.patch.object(
                doctor, "collect_report", return_value=report
            ), contextlib.redirect_stdout(stdout):
                result = doctor.main(["--json"])
            self.assertEqual(result, 0)
            parsed = json.loads(stdout.getvalue())
            self.assertEqual(parsed["platform"]["system"], "Linux")

    def test_existing_settings_without_owned_hooks_is_not_registered(self):
        with tempfile.TemporaryDirectory(prefix="safe-start-doctor-") as raw:
            base = Path(raw)
            home = base / "home"
            project = base / "project"
            (home / ".claude").mkdir(parents=True)
            project.mkdir()
            (home / ".claude" / "settings.json").write_text(
                json.dumps({"permissions": {"defaultMode": "default"}})
            )

            with mock.patch.dict(
                os.environ, {"HOME": str(home)}, clear=False
            ), mock.patch.object(
                doctor.subprocess,
                "run",
                side_effect=_git_and_claude_runner(project),
            ):
                report = doctor.collect_report(
                    cwd=project,
                    system_name="Darwin",
                    mac_version="15.0",
                    finder=_finder,
                )

            self.assertEqual(report["hooks"]["status"], "not_registered")
            self.assertEqual(report["hooks"]["owned_count"], 0)
            codes = {item["code"] for item in report["warnings"]}
            self.assertIn("hooks_not_registered", codes)
            self.assertNotIn("hook_registration_mismatch", codes)

    def test_dirty_non_repository_and_incomplete_identity_are_reported_without_paths(self):
        with tempfile.TemporaryDirectory(prefix="safe-start-doctor-") as raw:
            base = Path(raw)
            home = base / "home"
            project = base / "project"
            home.mkdir()
            project.mkdir()

            with mock.patch.dict(os.environ, {"HOME": str(home)}, clear=False), mock.patch.object(
                doctor.subprocess,
                "run",
                side_effect=_git_and_claude_runner(project, inside=False),
            ):
                report = doctor.collect_report(
                    cwd=project,
                    system_name="Darwin",
                    mac_version="14.7",
                    finder=_finder,
                )

            self.assertFalse(report["git"]["repository"]["inside"])
            self.assertFalse(report["git"]["identity"]["email"]["present"])
            codes = {item["code"] for item in report["warnings"]}
            self.assertIn("not_a_git_repository", codes)
            self.assertIn("git_identity_incomplete", codes)

    def test_repository_cleanliness_is_not_probed_or_changed_paths_reported(self):
        with tempfile.TemporaryDirectory(prefix="safe-start-doctor-") as raw:
            base = Path(raw)
            home = base / "home"
            project = base / "project"
            home.mkdir()
            project.mkdir()

            with mock.patch.dict(os.environ, {"HOME": str(home)}, clear=False), mock.patch.object(
                doctor.subprocess,
                "run",
                side_effect=_git_and_claude_runner(project, inside=True, clean=False),
            ):
                report = doctor.collect_report(
                    cwd=project,
                    system_name="Darwin",
                    mac_version="15.0",
                    finder=_finder,
                )

            self.assertIsNone(report["git"]["repository"]["clean"])
            rendered = doctor.render_human(report) + json.dumps(report)
            self.assertNotIn("tool.py", rendered)
            self.assertIn("git_cleanliness_not_checked", rendered)

    def test_failed_git_probe_with_nearby_metadata_is_unknown_not_not_a_repo(self):
        with tempfile.TemporaryDirectory(prefix="safe-start-doctor-") as raw:
            base = Path(raw)
            home = base / "home"
            project = base / "project"
            home.mkdir()
            (project / ".git").mkdir(parents=True)

            with mock.patch.dict(os.environ, {"HOME": str(home)}, clear=False), mock.patch.object(
                doctor.subprocess,
                "run",
                side_effect=_git_and_claude_runner(project, inside=False),
            ):
                report = doctor.collect_report(
                    cwd=project,
                    system_name="Darwin",
                    mac_version="15.0",
                    finder=_finder,
                )

            self.assertIsNone(report["git"]["repository"]["inside"])
            codes = {item["code"] for item in report["warnings"]}
            self.assertIn("git_repository_unknown", codes)
            self.assertNotIn("not_a_git_repository", codes)

    def test_empty_git_identity_values_are_not_reported_as_configured(self):
        with tempfile.TemporaryDirectory(prefix="safe-start-doctor-") as raw:
            base = Path(raw)
            home = base / "home"
            project = base / "project"
            home.mkdir()
            project.mkdir()
            ordinary_runner = _git_and_claude_runner(project)

            def blank_identity_runner(argv, **kwargs):
                command = tuple(str(item) for item in argv)
                if (
                    "config" in command
                    and command[-1] == "user.name"
                    and "--local" in command
                ):
                    return _completed(argv, 0, "   \n")
                if "config" in command and command[-1] == "user.email":
                    return _completed(argv, 0, "   \n")
                return ordinary_runner(argv, **kwargs)

            with mock.patch.dict(os.environ, {"HOME": str(home)}, clear=False), mock.patch.object(
                doctor.subprocess,
                "run",
                side_effect=blank_identity_runner,
            ):
                report = doctor.collect_report(
                    cwd=project,
                    system_name="Darwin",
                    mac_version="15.0",
                    finder=_finder,
                )

            self.assertFalse(report["git"]["identity"]["name"]["present"])
            self.assertFalse(report["git"]["identity"]["email"]["present"])
            self.assertFalse(report["git"]["identity"]["complete"])
            self.assertEqual(
                report["git"]["identity"]["name"]["effective_scope"], "local"
            )
            self.assertEqual(report["git"]["identity"]["name"]["scopes"], ["global"])
            self.assertEqual(
                report["git"]["identity"]["name"]["empty_scopes"], ["local"]
            )
            self.assertIn(
                "name not configured (empty local value)",
                doctor.render_human(report),
            )

    def test_hook_mismatch_and_unknown_mode_hide_unrecognized_value(self):
        with tempfile.TemporaryDirectory(prefix="safe-start-doctor-") as raw:
            base = Path(raw)
            home = base / "home"
            project = base / "project"
            (home / ".claude").mkdir(parents=True)
            project.mkdir()
            unknown = "secret-looking-unknown-mode"
            settings = _hook_settings(permission_mode=unknown)
            settings["hooks"]["SessionStart"] = []
            (home / ".claude" / "settings.json").write_text(json.dumps(settings))

            with mock.patch.dict(os.environ, {"HOME": str(home)}, clear=False), mock.patch.object(
                doctor.subprocess,
                "run",
                side_effect=_git_and_claude_runner(project),
            ):
                report = doctor.collect_report(
                    cwd=project,
                    system_name="Darwin",
                    mac_version="15.0",
                    finder=_finder,
                )

            self.assertEqual(report["hooks"]["status"], "mismatch")
            configured = report["permissions"]["configured_defaults"]
            self.assertEqual(configured[0]["mode"], None)
            self.assertFalse(configured[0]["recognized"])
            output = doctor.render_human(report) + json.dumps(report)
            self.assertNotIn(unknown, output)
            self.assertIn("unrecognized value hidden", output)

    def test_reduced_review_default_warns_without_claiming_active_mode(self):
        with tempfile.TemporaryDirectory(prefix="safe-start-doctor-") as raw:
            base = Path(raw)
            home = base / "home"
            project = base / "project"
            (home / ".claude").mkdir(parents=True)
            project.mkdir()
            (home / ".claude" / "settings.json").write_text(
                json.dumps(_hook_settings(permission_mode="bypassPermissions"))
            )

            with mock.patch.dict(os.environ, {"HOME": str(home)}, clear=False), mock.patch.object(
                doctor.subprocess,
                "run",
                side_effect=_git_and_claude_runner(project),
            ):
                report = doctor.collect_report(
                    cwd=project,
                    system_name="Darwin",
                    mac_version="15.0",
                    finder=_finder,
                )

            codes = {item["code"] for item in report["warnings"]}
            self.assertIn("permission_mode_user_reduced_review", codes)
            self.assertFalse(report["permissions"]["active_session_mode_observed"])
            human = doctor.render_human(report)
            self.assertIn("does not establish the active session mode", human)
            self.assertIn("not observable here", human)

    def test_manual_alias_is_recognized_and_rendered_as_manual(self):
        with tempfile.TemporaryDirectory(prefix="safe-start-doctor-") as raw:
            base = Path(raw)
            home = base / "home"
            project = base / "project"
            (home / ".claude").mkdir(parents=True)
            project.mkdir()
            (home / ".claude" / "settings.json").write_text(
                json.dumps(_hook_settings(permission_mode="manual"))
            )

            with mock.patch.dict(os.environ, {"HOME": str(home)}, clear=False), mock.patch.object(
                doctor.subprocess,
                "run",
                side_effect=_git_and_claude_runner(project),
            ):
                report = doctor.collect_report(
                    cwd=project,
                    system_name="Darwin",
                    mac_version="15.0",
                    finder=_finder,
                )

            configured = report["permissions"]["configured_defaults"][0]
            self.assertEqual(configured["mode"], "manual")
            self.assertTrue(configured["recognized"])
            self.assertIn("user=Manual (manual alias)", doctor.render_human(report))

    def test_dont_ask_is_recognized_but_not_called_reduced_review(self):
        with tempfile.TemporaryDirectory(prefix="safe-start-doctor-") as raw:
            base = Path(raw)
            home = base / "home"
            project = base / "project"
            (home / ".claude").mkdir(parents=True)
            project.mkdir()
            (home / ".claude" / "settings.json").write_text(
                json.dumps(_hook_settings(permission_mode="dontAsk"))
            )

            with mock.patch.dict(os.environ, {"HOME": str(home)}, clear=False), mock.patch.object(
                doctor.subprocess,
                "run",
                side_effect=_git_and_claude_runner(project),
            ):
                report = doctor.collect_report(
                    cwd=project,
                    system_name="Darwin",
                    mac_version="15.0",
                    finder=_finder,
                )

            configured = report["permissions"]["configured_defaults"][0]
            self.assertEqual(configured["mode"], "dontAsk")
            self.assertTrue(configured["recognized"])
            codes = {item["code"] for item in report["warnings"]}
            self.assertNotIn("permission_mode_user_reduced_review", codes)

    def test_project_auto_is_reported_as_configured_but_ignored(self):
        with tempfile.TemporaryDirectory(prefix="safe-start-doctor-") as raw:
            base = Path(raw)
            home = base / "home"
            project = base / "project"
            (home / ".claude").mkdir(parents=True)
            (project / ".claude").mkdir(parents=True)
            (home / ".claude" / "settings.json").write_text(
                json.dumps(_hook_settings(permission_mode="default"))
            )
            (project / ".claude" / "settings.json").write_text(
                json.dumps({"permissions": {"defaultMode": "auto"}})
            )

            with mock.patch.dict(os.environ, {"HOME": str(home)}, clear=False), mock.patch.object(
                doctor.subprocess,
                "run",
                side_effect=_git_and_claude_runner(project),
            ):
                report = doctor.collect_report(
                    cwd=project,
                    system_name="Darwin",
                    mac_version="15.0",
                    finder=_finder,
                )

            configured = {
                item["scope"]: item for item in report["permissions"]["configured_defaults"]
            }
            self.assertEqual(configured["project"]["mode"], "auto")
            self.assertTrue(configured["project"]["recognized"])
            codes = {item["code"] for item in report["warnings"]}
            self.assertIn("permission_mode_project_auto_ignored", codes)
            self.assertNotIn("permission_mode_project_reduced_review", codes)

    def test_malformed_settings_is_an_ordinary_unverifiable_warning(self):
        with tempfile.TemporaryDirectory(prefix="safe-start-doctor-") as raw:
            base = Path(raw)
            home = base / "home"
            project = base / "project"
            (home / ".claude").mkdir(parents=True)
            project.mkdir()
            (home / ".claude" / "settings.json").write_text('{"hooks": [')

            with mock.patch.dict(os.environ, {"HOME": str(home)}, clear=False), mock.patch.object(
                doctor.subprocess,
                "run",
                side_effect=_git_and_claude_runner(project),
            ):
                report = doctor.collect_report(
                    cwd=project,
                    system_name="Darwin",
                    mac_version="15.0",
                    finder=_finder,
                )
            self.assertEqual(report["hooks"]["status"], "unverifiable")
            codes = {item["code"] for item in report["warnings"]}
            self.assertIn("hook_settings_unreadable", codes)
            self.assertIn("permission_settings_user_unreadable", codes)

    def test_settings_symlink_is_not_followed(self):
        with tempfile.TemporaryDirectory(prefix="safe-start-doctor-") as raw:
            base = Path(raw)
            home = base / "home"
            project = base / "project"
            claude_dir = home / ".claude"
            claude_dir.mkdir(parents=True)
            project.mkdir()
            victim = base / "do-not-read.json"
            secret = "secret-value-that-must-not-appear"
            victim.write_text(json.dumps({"secret": secret}))
            (claude_dir / "settings.json").symlink_to(victim)

            with mock.patch.dict(os.environ, {"HOME": str(home)}, clear=False), mock.patch.object(
                doctor.subprocess,
                "run",
                side_effect=_git_and_claude_runner(project),
            ):
                report = doctor.collect_report(
                    cwd=project,
                    system_name="Darwin",
                    mac_version="15.0",
                    finder=_finder,
                )

            self.assertEqual(
                report["permissions"]["sources_checked"][0]["status"], "unsafe_type"
            )
            self.assertEqual(report["hooks"]["status"], "unverifiable")
            self.assertNotIn(secret, doctor.render_human(report) + json.dumps(report))

    def test_control_characters_in_paths_are_escaped_in_human_output(self):
        with tempfile.TemporaryDirectory(prefix="safe-start-doctor-") as raw:
            base = Path(raw)
            home = base / "home\nFAKE-HOME-LINE\u202eBIDI"
            project = base / "project\nFAKE-PROJECT-LINE\u202eBIDI"
            (home / ".claude").mkdir(parents=True)
            project.mkdir()
            (project / "CLAUDE.md").write_text("fixed marker only\n")

            with mock.patch.dict(os.environ, {"HOME": str(home)}, clear=False), mock.patch.object(
                doctor.subprocess,
                "run",
                side_effect=_git_and_claude_runner(project),
            ):
                report = doctor.collect_report(
                    cwd=project,
                    system_name="Darwin",
                    mac_version="15.0",
                    finder=_finder,
                )

            human = doctor.render_human(report)
            self.assertNotIn("\nFAKE-HOME-LINE", human)
            self.assertNotIn("\nFAKE-PROJECT-LINE", human)
            self.assertNotIn("\u202e", human)
            self.assertIn("\\nFAKE-HOME-LINE", human)
            self.assertIn("\\nFAKE-PROJECT-LINE", human)
            self.assertIn("\\u202eBIDI", human)

    def test_command_timeout_and_os_error_are_ordinary_warnings(self):
        for error in (
            subprocess.TimeoutExpired([GIT, "--version"], 8),
            OSError("fixed test error"),
        ):
            warnings = []
            with mock.patch.object(doctor.subprocess, "run", side_effect=error):
                probe = doctor._command_probe("git", warnings, lambda name: GIT)
            self.assertTrue(probe["found"])
            self.assertFalse(probe["available"])
            self.assertEqual([item["code"] for item in warnings], ["git_unavailable"])

    def test_internal_startup_error_is_nonzero_and_sanitized(self):
        stderr = io.StringIO()
        with mock.patch.object(
            doctor,
            "collect_report",
            side_effect=RuntimeError("private implementation detail"),
        ), contextlib.redirect_stderr(stderr):
            result = doctor.main([])
        self.assertEqual(result, 1)
        self.assertIn("internal error", stderr.getvalue())
        self.assertNotIn("private implementation detail", stderr.getvalue())

    def test_missing_or_relative_home_is_an_invocation_error(self):
        with mock.patch.dict(os.environ, {}, clear=True):
            with self.assertRaises(doctor.DoctorInvocationError):
                doctor._home_path()
        with mock.patch.dict(os.environ, {"HOME": "relative-home"}, clear=True):
            with self.assertRaises(doctor.DoctorInvocationError):
                doctor._home_path()


if __name__ == "__main__":
    unittest.main()
