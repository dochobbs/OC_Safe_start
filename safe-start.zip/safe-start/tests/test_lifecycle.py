"""Isolated installation, settings-transaction, and uninstall tests.

Every test supplies a temporary HOME. The installer deliberately self-tests the
detector, hook, and doctor suites; the sentinel below makes accidental recursive
execution of this lifecycle suite fail immediately.

Runnable two ways:
  python3 tests/test_lifecycle.py
  pytest tests/test_lifecycle.py
"""

import json
import os
from pathlib import Path
import shlex
import shutil
import stat
import subprocess
import sys
import tempfile


if (
  __name__ == "__main__"
  and os.environ.get("SAFE_START_LIFECYCLE_RUNNING") == "1"
):
  print("lifecycle suite must not be run as an installer self-test")
  sys.exit(97)


ROOT = Path(__file__).resolve().parent.parent
INSTALLER = ROOT / "install.sh"
MERGER = ROOT / "install" / "merge_settings.py"
HOOK_SCRIPTS = ("pretooluse.py", "userpromptsubmit.py", "sessionstart.py")
MARKER = "skills/safe-start/hooks/"
SYSTEM_BASH = Path("/bin/bash")
SYSTEM_PYTHON = Path("/usr/bin/python3")


def _env(home: Path, **updates) -> dict:
  env = dict(os.environ)
  for key in ("SAFE_START_SRC", "SAFE_START_REPO", "SAFE_START_REF"):
    env.pop(key, None)
  env.update({
    "HOME": str(home),
    "PYTHONDONTWRITEBYTECODE": "1",
    "SAFE_START_LIFECYCLE_RUNNING": "1",
  })
  env.update({key: str(value) for key, value in updates.items()})
  return env


def _run(argv, home: Path, *, env_updates=None, cwd=None, input_text=None,
         timeout=90):
  return subprocess.run(
    [str(arg) for arg in argv],
    cwd=str(cwd) if cwd else None,
    env=_env(home, **(env_updates or {})),
    input=input_text,
    capture_output=True,
    text=True,
    timeout=timeout,
  )


def _install(home: Path):
  return _run(
    [SYSTEM_BASH, INSTALLER], home,
    env_updates={"SAFE_START_SRC": ROOT},
  )


def _settings(home: Path) -> Path:
  return home / ".claude" / "settings.json"


def _dest(home: Path) -> Path:
  return home / ".claude" / "skills" / "safe-start"


def _owned_commands(data: dict):
  commands = []
  for groups in data.get("hooks", {}).values():
    for group in groups:
      for hook in group.get("hooks", []):
        command = hook.get("command", "")
        if MARKER in command:
          commands.append(command)
  return commands


def _other_settings_fixture() -> dict:
  return {
    "model": "example-model",
    "permissions": {"allow": ["Bash(git status)"]},
    "hooks": {
      "PreToolUse": [{
        "matcher": "Bash",
        "hooks": [{"type": "command", "command": "printf other-pre-hook"}],
      }],
      "Stop": [{
        "matcher": "",
        "hooks": [{"type": "command", "command": "printf other-stop-hook"}],
      }],
    },
  }


def test_install_success_modes_and_direct_executable_uninstall():
  with tempfile.TemporaryDirectory(prefix="safe-start-home-") as raw_home:
    home = Path(raw_home)
    result = _install(home)
    assert result.returncode == 0, result.stdout + result.stderr
    assert "safe-start v1.1.0 is on" in result.stdout
    assert "guards registered and verified" in result.stdout

    dest = _dest(home)
    state_dir = home / ".claude" / "safe-start"
    config = state_dir / "config.json"
    assert dest.is_dir()
    assert stat.S_IMODE(state_dir.stat().st_mode) == 0o700
    assert stat.S_IMODE(config.stat().st_mode) == 0o600
    assert (dest / "LICENSE").is_file()
    assert (dest / "scripts" / "doctor.py").is_file()
    assert os.access(dest / "scripts" / "doctor.py", os.X_OK)
    assert os.access(dest / "uninstall.sh", os.X_OK)

    data = json.loads(_settings(home).read_text())
    assert len(_owned_commands(data)) == 3
    pre_matchers = [
      group.get("matcher")
      for group in data["hooks"]["PreToolUse"]
      if any(MARKER in hook.get("command", "")
             for hook in group.get("hooks", []))
    ]
    assert pre_matchers == ["Bash|Read|Glob|Grep|Write|Edit|NotebookEdit"]

    removed = _run([dest / "uninstall.sh"], home)
    assert removed.returncode == 0, removed.stdout + removed.stderr
    assert not dest.exists()
    assert not state_dir.exists()
    assert not _owned_commands(json.loads(_settings(home).read_text()))


def test_symlinked_claude_directory_has_verifiable_hook_registration():
  with tempfile.TemporaryDirectory(prefix="safe-start-symlink-home-") as raw_base:
    base = Path(raw_base)
    home = base / "home"
    physical_claude = base / "physical-claude"
    home.mkdir()
    physical_claude.mkdir()
    (home / ".claude").symlink_to(physical_claude, target_is_directory=True)

    installed = _install(home)
    assert installed.returncode == 0, installed.stdout + installed.stderr

    doctor_result = _run(
      [sys.executable, _dest(home) / "scripts" / "doctor.py", "--json"],
      home,
      cwd=home,
    )
    assert doctor_result.returncode == 0, doctor_result.stdout + doctor_result.stderr
    report = json.loads(doctor_result.stdout)
    assert report["hooks"]["status"] == "registered"
    assert report["hooks"]["registered"] is True

    removed = _run([_dest(home) / "uninstall.sh"], home)
    assert removed.returncode == 0, removed.stdout + removed.stderr
    assert not _dest(home).exists()
    assert not (physical_claude / "safe-start").exists()


def test_symlinked_skills_directory_is_refused_without_touching_target():
  with tempfile.TemporaryDirectory(prefix="safe-start-skills-link-") as raw_base:
    base = Path(raw_base)
    home = base / "home"
    claude = home / ".claude"
    external = base / "external-skills"
    victim = external / "safe-start"
    claude.mkdir(parents=True)
    victim.mkdir(parents=True)
    marker = victim / "unrelated-content.txt"
    marker.write_bytes(b"leave this external directory alone\n")
    settings = claude / "settings.json"
    original_settings = b'{"model":"existing"}\n'
    settings.write_bytes(original_settings)
    (claude / "skills").symlink_to(external, target_is_directory=True)

    result = _install(home)
    assert result.returncode != 0
    assert "skills must be a real directory, not a link" in result.stdout
    assert marker.read_bytes() == b"leave this external directory alone\n"
    assert not (victim / "SKILL.md").exists()
    assert settings.read_bytes() == original_settings
    assert not (claude / "safe-start").exists()


def test_uninstall_refuses_retargeted_skills_parent_without_mutation():
  with tempfile.TemporaryDirectory(prefix="safe-start-uninstall-link-") as raw_base:
    base = Path(raw_base)
    home = base / "home"
    home.mkdir()
    installed = _install(home)
    assert installed.returncode == 0, installed.stdout + installed.stderr

    claude = home / ".claude"
    original_skills = claude / "skills"
    parked_skills = claude / "skills-original"
    original_skills.rename(parked_skills)
    external = base / "external-skills"
    external_victim = external / "safe-start"
    external_victim.mkdir(parents=True)
    marker = external_victim / "unrelated-content.txt"
    marker.write_bytes(b"do not remove this directory\n")
    original_skills.symlink_to(external, target_is_directory=True)

    settings = claude / "settings.json"
    settings_before = settings.read_bytes()
    config = claude / "safe-start" / "config.json"
    config_before = config.read_bytes()
    physical_uninstaller = parked_skills / "safe-start" / "uninstall.sh"
    result = _run([physical_uninstaller], home)

    assert result.returncode != 0
    assert "skills must be a real directory, not a link" in result.stdout
    assert "Nothing was removed" in result.stdout
    assert marker.read_bytes() == b"do not remove this directory\n"
    assert (parked_skills / "safe-start" / "SKILL.md").is_file()
    assert settings.read_bytes() == settings_before
    assert config.read_bytes() == config_before


def test_malformed_settings_aborts_and_restores_previous_install():
  with tempfile.TemporaryDirectory(prefix="safe-start-home-") as raw_home:
    home = Path(raw_home)
    old_dest = _dest(home)
    old_dest.mkdir(parents=True)
    marker = old_dest / "old-install-marker.txt"
    marker.write_text("keep the known-good install\n")

    settings = _settings(home)
    malformed = b'{"hooks": [\n'
    settings.write_bytes(malformed)
    os.chmod(settings, 0o640)

    result = _install(home)
    assert result.returncode != 0
    assert "not valid UTF-8 JSON" in result.stderr
    assert "restored the previous safe-start installation" in result.stdout
    assert marker.read_text() == "keep the known-good install\n"
    assert not (old_dest / "SKILL.md").exists()
    assert settings.read_bytes() == malformed
    assert stat.S_IMODE(settings.stat().st_mode) == 0o640
    assert not (settings.parent / "settings.json.safe-start.bak").exists()
    assert not (home / ".claude" / "safe-start").exists()


def test_non_regular_package_entry_is_rejected_before_live_replacement():
  with tempfile.TemporaryDirectory(prefix="safe-start-source-") as raw_base:
    base = Path(raw_base)
    home = base / "home"
    source = base / "source"
    home.mkdir()
    shutil.copytree(
      ROOT,
      source,
      ignore=shutil.ignore_patterns("__pycache__", "*.pyc"),
    )
    os.symlink("SKILL.md", source / "unexpected-link")

    old_dest = _dest(home)
    old_dest.mkdir(parents=True)
    marker = old_dest / "old-install-marker.txt"
    marker.write_text("known-good\n")

    result = _run(
      [SYSTEM_BASH, INSTALLER], home,
      env_updates={"SAFE_START_SRC": source},
    )
    assert result.returncode != 0
    assert "package entries must be regular files or directories" in result.stdout
    assert "safe-start v1.1.0 is on" not in result.stdout
    assert marker.read_text() == "known-good\n"


def test_hostile_path_and_python_startup_cannot_intercept_lifecycle():
  with tempfile.TemporaryDirectory(prefix="safe-start-path-") as raw_base:
    base = Path(raw_base)
    home = base / "home"
    hostile_bin = base / "hostile-bin"
    hostile_python = base / "hostile-python"
    wrapper_marker = base / "path-wrapper-ran"
    startup_marker = base / "python-startup-ran"
    home.mkdir()
    hostile_bin.mkdir()
    hostile_python.mkdir()

    wrapper = "#!/bin/sh\n/usr/bin/touch %s\nexit 97\n" % shlex.quote(
      str(wrapper_marker)
    )
    for name in (
      "bash", "cat", "chmod", "dirname", "find", "git", "grep",
      "mkdir", "mktemp", "mv", "python3", "rm", "rmdir", "tar", "tr",
    ):
      candidate = hostile_bin / name
      candidate.write_text(wrapper)
      candidate.chmod(0o755)
    (hostile_python / "sitecustomize.py").write_text(
      "from pathlib import Path\nPath(%r).write_text('loaded\\n')\n"
      % str(startup_marker)
    )
    hostile_env = {
      "PATH": str(hostile_bin),
      "PYTHONHOME": str(hostile_python),
      "PYTHONINSPECT": "1",
      "PYTHONPATH": str(hostile_python),
      "PYTHONSTARTUP": str(hostile_python / "sitecustomize.py"),
    }

    installed = _run(
      [SYSTEM_BASH, INSTALLER], home,
      env_updates={"SAFE_START_SRC": ROOT, **hostile_env},
    )
    assert installed.returncode == 0, installed.stdout + installed.stderr
    assert not wrapper_marker.exists()
    assert not startup_marker.exists()

    data = json.loads(_settings(home).read_text())
    for command in _owned_commands(data):
      parts = shlex.split(command)
      assert parts[:2] == [str(SYSTEM_PYTHON), "-I"]
      assert len(parts) == 3

    removed = _run(
      [_dest(home) / "uninstall.sh"], home,
      env_updates=hostile_env,
    )
    assert removed.returncode == 0, removed.stdout + removed.stderr
    assert not _dest(home).exists()
    assert not wrapper_marker.exists()
    assert not startup_marker.exists()


def test_update_is_convergent_and_uninstall_preserves_other_settings_hooks():
  with tempfile.TemporaryDirectory(prefix="safe-start-home-") as raw_home:
    home = Path(raw_home)
    settings = _settings(home)
    settings.parent.mkdir(parents=True)
    original = _other_settings_fixture()
    original_bytes = (json.dumps(original, indent=2) + "\n").encode()
    settings.write_bytes(original_bytes)
    os.chmod(settings, 0o644)

    first = _install(home)
    assert first.returncode == 0, first.stdout + first.stderr
    first_data = json.loads(settings.read_text())
    assert first_data["model"] == original["model"]
    assert first_data["permissions"] == original["permissions"]
    assert len(_owned_commands(first_data)) == 3
    assert stat.S_IMODE(settings.stat().st_mode) == 0o600
    backup = settings.parent / "settings.json.safe-start.bak"
    assert backup.read_bytes() == original_bytes
    assert stat.S_IMODE(backup.stat().st_mode) == 0o600

    settings_inode = settings.stat().st_ino
    second = _install(home)
    assert second.returncode == 0, second.stdout + second.stderr
    second_data = json.loads(settings.read_text())
    assert second_data == first_data
    assert len(_owned_commands(second_data)) == 3
    assert settings.stat().st_ino == settings_inode

    removed = _run([_dest(home) / "uninstall.sh"], home)
    assert removed.returncode == 0, removed.stdout + removed.stderr
    final = json.loads(settings.read_text())
    assert final == original
    assert stat.S_IMODE(settings.stat().st_mode) == 0o600


def test_merge_settings_is_atomic_locked_private_and_shell_safe():
  with tempfile.TemporaryDirectory(prefix="safe start's home ") as raw_home:
    home = Path(raw_home)
    hooks_dir = home / ".claude" / "skills" / "safe-start" / "hooks"
    shutil.copytree(ROOT / "hooks", hooks_dir)
    settings = _settings(home)
    original = _other_settings_fixture()
    original_bytes = (json.dumps(original) + "\n").encode()
    settings.write_bytes(original_bytes)
    os.chmod(settings, 0o640)
    before_inode = settings.stat().st_ino

    result = _run([sys.executable, MERGER, "add", hooks_dir], home)
    assert result.returncode == 0, result.stdout + result.stderr
    assert settings.stat().st_ino != before_inode
    assert stat.S_IMODE(settings.stat().st_mode) == 0o600
    assert (settings.parent / "settings.json.safe-start.bak").read_bytes() == original_bytes
    assert stat.S_IMODE(
      (settings.parent / "settings.json.safe-start.bak").stat().st_mode
    ) == 0o600
    assert stat.S_IMODE(
      (settings.parent / ".safe-start-settings.lock").stat().st_mode
    ) == 0o600
    assert not list(settings.parent.glob(".settings.json.safe-start.*"))

    data = json.loads(settings.read_text())
    expected_dir = hooks_dir.resolve()
    for command in _owned_commands(data):
      parts = shlex.split(command)
      assert parts[0:2] == [str(SYSTEM_PYTHON), "-I"]
      assert SYSTEM_PYTHON.is_file()
      assert len(parts) == 3
      assert Path(parts[2]).parent.resolve() == expected_dir

    converged_inode = settings.stat().st_ino
    os.chmod(settings, 0o644)
    again = _run([sys.executable, MERGER, "add", hooks_dir], home)
    assert again.returncode == 0, again.stdout + again.stderr
    assert settings.stat().st_ino == converged_inode
    assert stat.S_IMODE(settings.stat().st_mode) == 0o600

    # Concurrent updaters must serialize and converge to one owned hook/event.
    processes = [
      subprocess.Popen(
        [sys.executable, str(MERGER), "add", str(hooks_dir)],
        env=_env(home), stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        text=True,
      )
      for _ in range(4)
    ]
    for process in processes:
      stdout, stderr = process.communicate(timeout=30)
      assert process.returncode == 0, stdout + stderr
    assert len(_owned_commands(json.loads(settings.read_text()))) == 3

  with tempfile.TemporaryDirectory(prefix="safe-start-new-home-") as raw_home:
    home = Path(raw_home)
    result = _run([sys.executable, MERGER, "add", ROOT / "hooks"], home)
    assert result.returncode == 0, result.stdout + result.stderr
    assert stat.S_IMODE(_settings(home).stat().st_mode) == 0o600


def test_remove_preserves_foreign_marker_collision_command():
  with tempfile.TemporaryDirectory(prefix="safe-start-marker-collision-") as raw_home:
    home = Path(raw_home)
    settings = _settings(home)
    settings.parent.mkdir(parents=True)
    owned_hooks = home / ".claude" / "skills" / "safe-start" / "hooks"
    foreign = "python3 /private/tmp/other-project/skills/safe-start/hooks/pretooluse.py"
    legacy_owned = "%s %s" % (
      "/usr/bin/python3",
      shlex.quote(str(owned_hooks / "pretooluse.py")),
    )
    owned_with_args = "%s -u %s --mode audit" % (
      "/opt/homebrew/bin/python3",
      shlex.quote(str(owned_hooks / "userpromptsubmit.py")),
    )
    direct_owned_with_args = "%s --unexpected" % shlex.quote(
      str(owned_hooks / "sessionstart.py")
    )
    nested_owned = "/bin/sh -c %s" % shlex.quote(
      "/usr/bin/python3 -I %s --nested" % shlex.quote(
        str(owned_hooks / "pretooluse.py")
      )
    )
    embedded_owned = "/usr/bin/python3 -c %s" % shlex.quote(
      "exec(open(%r).read())" % str(owned_hooks / "pretooluse.py")
    )
    hooks_relative_to_home = Path(".claude/skills/safe-start/hooks")
    home_variable_owned = (
      '/usr/bin/python3 -I "$HOME/%s/userpromptsubmit.py" --extra'
      % hooks_relative_to_home
    )
    tilde_owned = "/usr/bin/python3 -I ~/%s/sessionstart.py --extra" % (
      hooks_relative_to_home
    )
    original = {
      "hooks": {
        "Stop": [{
          "matcher": "",
          "hooks": [
            {"type": "command", "command": foreign},
            {"type": "command", "command": legacy_owned},
            {"type": "command", "command": owned_with_args},
            {"type": "command", "command": direct_owned_with_args},
            {"type": "command", "command": nested_owned},
            {"type": "command", "command": embedded_owned},
            {"type": "command", "command": home_variable_owned},
            {"type": "command", "command": tilde_owned},
          ],
        }],
      },
    }
    settings.write_text(json.dumps(original) + "\n")

    settings_before = settings.read_bytes()
    still_present = _run(
      [sys.executable, MERGER, "verify-absent", owned_hooks], home
    )
    assert still_present.returncode != 0
    assert "owned hooks remain" in still_present.stderr
    assert settings.read_bytes() == settings_before

    removed = _run(
      [sys.executable, MERGER, "remove", owned_hooks], home
    )
    assert removed.returncode == 0, removed.stdout + removed.stderr
    final = json.loads(settings.read_text())
    assert final["hooks"]["Stop"][0]["hooks"] == [
      {"type": "command", "command": foreign},
    ]

    verified = _run(
      [sys.executable, MERGER, "verify-absent", owned_hooks], home
    )
    assert verified.returncode == 0, verified.stdout + verified.stderr


def test_remove_fails_closed_for_malformed_owned_command():
  with tempfile.TemporaryDirectory(prefix="safe-start-malformed-owned-") as raw_home:
    home = Path(raw_home)
    settings = _settings(home)
    settings.parent.mkdir(parents=True)
    owned_path = str(ROOT / "hooks" / "pretooluse.py")
    original = {
      "hooks": {
        "Stop": [{
          "matcher": "",
          "hooks": [{
            "type": "command",
            "command": "/usr/bin/python3 '%s" % owned_path,
          }],
        }],
      },
    }
    original_bytes = (json.dumps(original) + "\n").encode()
    settings.write_bytes(original_bytes)

    removed = _run(
      [sys.executable, MERGER, "remove", ROOT / "hooks"], home
    )
    assert removed.returncode != 0
    assert "cannot safely classify a malformed command" in removed.stderr
    assert settings.read_bytes() == original_bytes

    verified = _run(
      [sys.executable, MERGER, "verify-absent", ROOT / "hooks"], home
    )
    assert verified.returncode != 0
    assert "cannot safely classify a malformed command" in verified.stderr
    assert settings.read_bytes() == original_bytes


def test_remove_fails_closed_for_relative_owned_namespace_reference():
  with tempfile.TemporaryDirectory(prefix="safe-start-relative-owned-") as raw_home:
    home = Path(raw_home)
    settings = _settings(home)
    settings.parent.mkdir(parents=True)
    owned_hooks = home / ".claude" / "skills" / "safe-start" / "hooks"
    foreign = (
      "/usr/bin/python3 "
      "/private/tmp/other-project/skills/safe-start/hooks/pretooluse.py"
    )
    relative = (
      "/usr/bin/python3 -I "
      "../.claude/skills/safe-start/hooks/pretooluse.py --extra"
    )
    original = {
      "hooks": {
        "Stop": [{
          "matcher": "",
          "hooks": [
            {"type": "command", "command": foreign},
            {"type": "command", "command": relative},
          ],
        }],
      },
    }
    original_bytes = (json.dumps(original) + "\n").encode()
    settings.write_bytes(original_bytes)

    for mode in ("remove", "verify-absent"):
      result = _run(
        [sys.executable, MERGER, mode, owned_hooks], home
      )
      assert result.returncode != 0
      assert "cannot safely resolve a relative or variable command" in result.stderr
      assert settings.read_bytes() == original_bytes


def test_explicit_claude_root_survives_home_link_retarget():
  with tempfile.TemporaryDirectory(prefix="safe-start-root-retarget-") as raw_base:
    base = Path(raw_base)
    home = base / "home"
    first = base / "first-claude"
    second = base / "second-claude"
    home.mkdir()
    first.mkdir()
    second.mkdir()
    claude_link = home / ".claude"
    claude_link.symlink_to(first, target_is_directory=True)
    bound_root = claude_link.resolve()

    first_settings = first / "settings.json"
    second_settings = second / "settings.json"
    first_original = b'{"model":"first"}\n'
    second_original = b'{"model":"second"}\n'
    first_settings.write_bytes(first_original)
    second_settings.write_bytes(second_original)

    claude_link.unlink()
    claude_link.symlink_to(second, target_is_directory=True)
    added = _run([
      sys.executable,
      MERGER,
      "add",
      ROOT / "hooks",
      "--claude-dir",
      bound_root,
    ], home)
    assert added.returncode == 0, added.stdout + added.stderr
    assert len(_owned_commands(json.loads(first_settings.read_text()))) == 3
    assert second_settings.read_bytes() == second_original

    removed = _run([
      sys.executable,
      MERGER,
      "remove",
      ROOT / "hooks",
      "--claude-dir",
      bound_root,
    ], home)
    assert removed.returncode == 0, removed.stdout + removed.stderr
    assert json.loads(first_settings.read_text()) == {"model": "first"}
    assert second_settings.read_bytes() == second_original


def test_merge_settings_refuses_lock_symlink_without_touching_target():
  with tempfile.TemporaryDirectory(prefix="safe-start-lock-") as raw_home:
    home = Path(raw_home)
    claude = home / ".claude"
    claude.mkdir()
    victim = home / "victim.txt"
    victim.write_text("leave me alone\n")
    os.chmod(victim, 0o640)
    os.symlink(victim, claude / ".safe-start-settings.lock")

    result = _run([sys.executable, MERGER, "add", ROOT / "hooks"], home)
    assert result.returncode != 0
    assert "is a symlink" in result.stderr
    assert victim.read_text() == "leave me alone\n"
    assert stat.S_IMODE(victim.stat().st_mode) == 0o640
    assert not _settings(home).exists()


def test_uninstall_failure_preserves_recovery_scripts():
  with tempfile.TemporaryDirectory(prefix="safe-start-home-") as raw_home:
    home = Path(raw_home)
    installed = _install(home)
    assert installed.returncode == 0, installed.stdout + installed.stderr
    settings = _settings(home)
    settings.write_text('{"hooks":')

    dest = _dest(home)
    result = _run([dest / "uninstall.sh"], home)
    assert result.returncode != 0
    assert "installed scripts are preserved" in result.stdout
    assert dest.is_dir()
    assert (dest / "uninstall.sh").is_file()
    assert (home / ".claude" / "safe-start" / "config.json").is_file()


def test_piped_installer_does_not_trust_cwd_and_uses_pinned_ref():
  with tempfile.TemporaryDirectory(prefix="safe-start-piped-") as raw_base:
    base = Path(raw_base)
    home = base / "home"
    cwd = base / "lookalike-cwd"
    repository = base / "release-repository"
    fake_bin = base / "fake-bin"
    home.mkdir()
    (cwd / "hooks").mkdir(parents=True)
    fake_bin.mkdir()
    (cwd / "SKILL.md").write_text("MALICIOUS-CWD-MARKER\n")
    (cwd / "hooks" / "pretooluse.py").write_text("raise SystemExit(99)\n")

    shutil.copytree(
      ROOT,
      repository,
      ignore=shutil.ignore_patterns(".git", "__pycache__", "*.pyc"),
    )

    def git(*args):
      result = subprocess.run(
        ["/usr/bin/git", *args],
        cwd=repository,
        capture_output=True,
        text=True,
      )
      assert result.returncode == 0, result.stdout + result.stderr

    git("init")
    git("config", "--local", "user.name", "Persona Release Test")
    git("config", "--local", "user.email", "release@example.invalid")
    git("add", "--all")
    git("commit", "-m", "fixture release")
    git("tag", "v1.1.0")
    git("tag", "v9.9.9")

    fake_git = fake_bin / "git"
    fake_git.write_text("""#!/bin/sh
printf 'invoked\\n' > "$HOME/poisoned-path-git-ran"
exit 99
""")
    os.chmod(fake_git, 0o755)

    path = str(fake_bin) + os.pathsep + os.environ.get("PATH", "")
    result = _run(
      [SYSTEM_BASH], home, cwd=cwd, input_text=INSTALLER.read_text(),
      env_updates={
        "PATH": path,
        "SAFE_START_REPO": repository,
        "GIT_CONFIG_COUNT": "1",
        "GIT_CONFIG_KEY_0": "url.file:///redirected.invalid.insteadOf",
        "GIT_CONFIG_VALUE_0": str(repository),
        "GIT_CONFIG_GLOBAL": str(base / "redirected.gitconfig"),
        "GIT_DIR": str(base / "outside.git"),
        "GIT_TRACE": str(base / "git-trace.log"),
        "GIT_TRACE2_EVENT": str(base / "git-trace2.json"),
        "GIT_WORK_TREE": str(base / "outside-worktree"),
        "GIT_ASKPASS": str(base / "hostile-askpass"),
        "GIT_SSH_COMMAND": str(base / "hostile-ssh"),
        "SSH_ASKPASS": str(base / "hostile-askpass"),
      },
    )
    assert result.returncode == 0, result.stdout + result.stderr
    assert "safe-start v1.1.0 is on" in result.stdout
    assert (_dest(home) / "SKILL.md").read_text() != "MALICIOUS-CWD-MARKER\n"
    assert not (home / "poisoned-path-git-ran").exists()
    assert not (base / "git-trace.log").exists()
    assert not (base / "git-trace2.json").exists()

    mismatch_home = base / "mismatch-home"
    mismatch_home.mkdir()
    mismatch = _run(
      [SYSTEM_BASH], mismatch_home, cwd=cwd, input_text=INSTALLER.read_text(),
      env_updates={
        "PATH": path,
        "SAFE_START_REPO": repository,
        "SAFE_START_REF": "v9.9.9",
      },
    )
    assert mismatch.returncode != 0
    assert "Release mismatch: v9.9.9 contains VERSION 1.1.0" in mismatch.stdout


def test_remote_install_refuses_branch_without_exact_tag():
  with tempfile.TemporaryDirectory(prefix="safe-start-tag-") as raw_base:
    base = Path(raw_base)
    repository = base / "repository"
    shutil.copytree(
      ROOT,
      repository,
      ignore=shutil.ignore_patterns(".git", "__pycache__", "*.pyc"),
    )

    def git(*args):
      result = subprocess.run(
        [shutil.which("git"), *args],
        cwd=repository,
        capture_output=True,
        text=True,
      )
      assert result.returncode == 0, result.stdout + result.stderr

    git("init")
    git("config", "--local", "user.name", "Persona Release Test")
    git("config", "--local", "user.email", "release@example.invalid")
    git("add", "--all")
    git("commit", "-m", "fixture release")
    git("branch", "-M", "v1.1.0")

    branch_home = base / "branch-home"
    branch_home.mkdir()
    branch_only = _run(
      [SYSTEM_BASH],
      branch_home,
      input_text=INSTALLER.read_text(),
      env_updates={
        "SAFE_START_REPO": repository,
        "SAFE_START_REF": "v1.1.0",
      },
    )
    assert branch_only.returncode != 0
    assert "not the exact v1.1.0 tag" in branch_only.stdout
    assert not _dest(branch_home).exists()

    git("tag", "v1.1.0")
    tag_home = base / "tag-home"
    tag_home.mkdir()
    tagged = _run(
      [SYSTEM_BASH],
      tag_home,
      input_text=INSTALLER.read_text(),
      env_updates={
        "SAFE_START_REPO": repository,
        "SAFE_START_REF": "v1.1.0",
      },
    )
    assert tagged.returncode == 0, tagged.stdout + tagged.stderr
    assert (_dest(tag_home) / "VERSION").read_text().strip() == "1.1.0"


def test_remote_install_refuses_ambient_git_redirects_and_url_rewrites():
  with tempfile.TemporaryDirectory(prefix="safe-start-git-env-") as raw_base:
    base = Path(raw_base)
    repository = base / "branch-only-repository"
    shutil.copytree(
      ROOT,
      repository,
      ignore=shutil.ignore_patterns(".git", "__pycache__", "*.pyc"),
    )

    def git(cwd, *args):
      result = subprocess.run(
        [shutil.which("git"), *args],
        cwd=cwd,
        capture_output=True,
        text=True,
      )
      assert result.returncode == 0, result.stdout + result.stderr

    git(repository, "init")
    git(repository, "config", "--local", "user.name", "Persona Release Test")
    git(
      repository,
      "config",
      "--local",
      "user.email",
      "release@example.invalid",
    )
    git(repository, "add", "--all")
    git(repository, "commit", "-m", "branch-only fixture")
    git(repository, "branch", "-M", "v1.1.0")

    decoy = base / "tagged-decoy"
    git(base, "clone", str(repository), str(decoy))
    git(decoy, "tag", "v1.1.0")

    global_config = base / "redirected.gitconfig"
    global_config.write_text(
      '[url "%s"]\n\tinsteadOf = %s\n'
      % (decoy.as_uri(), repository.as_uri())
    )
    trace = base / "git-trace.log"
    trace2 = base / "git-trace2.json"
    prompt_marker = base / "prompt-helper-ran"
    prompt_helper = base / "prompt-helper"
    prompt_helper.write_text(
      "#!/bin/sh\nprintf invoked > %s\n" % shlex.quote(str(prompt_marker))
    )
    os.chmod(prompt_helper, 0o700)

    home = base / "home"
    home.mkdir()
    result = _run(
      [SYSTEM_BASH],
      home,
      input_text=INSTALLER.read_text(),
      env_updates={
        "SAFE_START_REPO": repository.as_uri(),
        "SAFE_START_REF": "v1.1.0",
        "GIT_CONFIG_GLOBAL": global_config,
        "GIT_DIR": decoy / ".git",
        "GIT_TRACE": trace,
        "GIT_TRACE2_EVENT": trace2,
        "GIT_WORK_TREE": decoy,
        "GIT_ASKPASS": prompt_helper,
        "GIT_SSH_COMMAND": prompt_helper,
        "SSH_ASKPASS": prompt_helper,
      },
    )

    assert result.returncode != 0
    assert "not the exact v1.1.0 tag" in result.stdout
    assert not _dest(home).exists()
    assert not trace.exists()
    assert not trace2.exists()
    assert not prompt_marker.exists()


def _main() -> int:
  tests = [value for name, value in sorted(globals().items())
           if name.startswith("test_")]
  passed = 0
  failed = 0
  for test in tests:
    try:
      test()
      passed += 1
    except AssertionError as exc:
      failed += 1
      print("FAIL: %s  %s" % (test.__name__, exc))
    except Exception as exc:  # noqa: BLE001
      failed += 1
      print("ERROR: %s  %r" % (test.__name__, exc))
  print("\n%d passed, %d failed, %d total" %
        (passed, failed, passed + failed))
  return 1 if failed else 0


if __name__ == "__main__":
  sys.exit(_main())
