#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Read-only preflight for safe-start on macOS and Claude Code.

The doctor reports only fixed metadata and booleans/counts derived from Git and
Claude configuration. It never prints project contents or deliberately parses
them. It deliberately does not run ``git status``: even a nominally read-only
status can execute a repository-configured filter or other helper.
Ordinary missing-tool, setup, and configuration findings are warnings and keep
the exit status at zero. A nonzero status is reserved for an invalid invocation
or for the doctor itself being unable to start.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import os
from pathlib import Path
import platform
import re
import shlex
import shutil
import subprocess
import sys
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple


# Importing the registration verifier must not create __pycache__ in the
# installed skill; the doctor is a read-only diagnostic.
sys.dont_write_bytecode = True


ROOT = Path(__file__).resolve().parent.parent
VERSION_FILE = ROOT / "VERSION"
MERGER_FILE = ROOT / "install" / "merge_settings.py"
HOOKS_DIR = ROOT / "hooks"
SCHEMA_VERSION = 1
COMMAND_TIMEOUT_SECONDS = 8
MACOS_GIT_EXECUTABLE = "/usr/bin/git"
DEFAULT_FINDER = shutil.which
SAFE_GIT_CONFIG = (
    "-c", "core.fsmonitor=false",
    "-c", "core.hooksPath=/dev/null",
    "-c", "gc.auto=0",
    "-c", "maintenance.auto=false",
)

KNOWN_PERMISSION_MODES = {
    "default",
    "manual",
    "acceptEdits",
    "plan",
    "dontAsk",
    "bypassPermissions",
    "auto",
}

REDUCED_REVIEW_PERMISSION_MODES = {
    "acceptEdits",
    "bypassPermissions",
    "auto",
}

CLOUD_MARKERS: Tuple[Tuple[str, Tuple[str, ...]], ...] = (
    (
        "iCloud Drive",
        (
            "/library/mobile documents/",
            "/mobile documents/com~apple~clouddocs/",
        ),
    ),
    ("Dropbox", ("/library/cloudstorage/dropbox", "/dropbox/")),
    ("OneDrive", ("/library/cloudstorage/onedrive", "/onedrive/")),
    (
        "Google Drive",
        (
            "/library/cloudstorage/googledrive",
            "/google drive/",
            "/googledrive/",
            "/my drive/",
        ),
    ),
)


class DoctorInvocationError(Exception):
    """The doctor could not establish the minimum context needed to run."""


def _warning(warnings: List[Dict[str, str]], code: str, message: str) -> None:
    if not any(item["code"] == code for item in warnings):
        warnings.append({"code": code, "message": message})


def _physical_cwd() -> Path:
    try:
        return Path(os.path.realpath(os.getcwd()))
    except OSError as exc:
        raise DoctorInvocationError("cannot resolve the current working folder") from exc


def _home_path() -> Path:
    raw = os.environ.get("HOME")
    if not raw:
        raise DoctorInvocationError("HOME is not set")
    expanded = os.path.expanduser(raw)
    if not os.path.isabs(expanded):
        raise DoctorInvocationError("HOME is not an absolute path")
    return Path(os.path.realpath(expanded))


def _run_command(
    argv: Sequence[str],
    *,
    cwd: Optional[Path] = None,
    capture: bool = True,
    git_config_scope: Optional[str] = None,
) -> Dict[str, Any]:
    """Run one fixed, non-shell command and normalize operational failures."""
    env = dict(os.environ)
    for key in list(env):
        if key.startswith("GIT_"):
            env.pop(key, None)
    env.update({
        "GIT_ATTR_NOSYSTEM": "1",
        "GIT_CONFIG_COUNT": "0",
        "GIT_OPTIONAL_LOCKS": "0",
        "GIT_PAGER": "",
        "GIT_TERMINAL_PROMPT": "0",
        "LC_ALL": "C",
        "PAGER": "",
    })
    # Repository metadata probes must not inherit either machine-wide config
    # scope. Identity probes opt one explicit scope back in so the doctor can
    # still report presence without ever returning the configured value.
    if git_config_scope != "global":
        env["GIT_CONFIG_GLOBAL"] = "/dev/null"
    if git_config_scope != "system":
        env.update({
            "GIT_CONFIG_NOSYSTEM": "1",
            "GIT_CONFIG_SYSTEM": "/dev/null",
        })
    try:
        completed = subprocess.run(
            list(argv),
            cwd=str(cwd) if cwd else None,
            env=env,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE if capture else subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=COMMAND_TIMEOUT_SECONDS,
            check=False,
        )
        return {
            "returncode": completed.returncode,
            "stdout": completed.stdout if capture and completed.stdout else "",
            "failure": None,
        }
    except FileNotFoundError:
        return {"returncode": None, "stdout": "", "failure": "not_found"}
    except subprocess.TimeoutExpired:
        return {"returncode": None, "stdout": "", "failure": "timeout"}
    except OSError:
        return {"returncode": None, "stdout": "", "failure": "os_error"}


def _safe_version_line(raw: str) -> Optional[str]:
    if not raw:
        return None
    first = raw.splitlines()[0][:200]
    cleaned = "".join(ch for ch in first if ch.isprintable()).strip()
    return cleaned or None


def _command_probe(
    name: str,
    warnings: List[Dict[str, str]],
    finder: Callable[[str], Optional[str]],
) -> Dict[str, Any]:
    path = finder(name)
    if not path:
        _warning(
            warnings,
            "%s_missing" % name,
            "%s was not found on PATH." % ("Claude Code" if name == "claude" else "Git"),
        )
        return {
            "found": False,
            "available": False,
            "path": None,
            "version": None,
        }

    result = _run_command([path, "--version"])
    available = result["returncode"] == 0
    version = _safe_version_line(result["stdout"]) if available else None
    if not available:
        _warning(
            warnings,
            "%s_unavailable" % name,
            "%s resolved on PATH but did not run successfully."
            % ("Claude Code" if name == "claude" else "Git"),
        )
    elif not version:
        _warning(
            warnings,
            "%s_version_unknown" % name,
            "%s ran, but its version could not be read."
            % ("Claude Code" if name == "claude" else "Git"),
        )
    return {
        "found": True,
        "available": available,
        "path": os.path.abspath(path),
        "version": version,
    }


def _macos_system_git(name: str) -> Optional[str]:
    """Resolve only Apple's fixed Git entry point, never an inherited PATH shim."""
    if name != "git":
        return None
    path = Path(MACOS_GIT_EXECUTABLE)
    try:
        if path.is_symlink() or not path.is_file() or not os.access(path, os.X_OK):
            return None
    except OSError:
        return None
    return str(path)


def _read_version(warnings: List[Dict[str, str]]) -> Optional[str]:
    try:
        if not VERSION_FILE.is_file() or VERSION_FILE.is_symlink():
            raise OSError
        raw = VERSION_FILE.read_text(encoding="utf-8")
    except (OSError, UnicodeError):
        _warning(
            warnings,
            "safe_start_version_unreadable",
            "The bundled safe-start VERSION file could not be read safely.",
        )
        return None
    value = raw.strip()
    if not re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+", value):
        _warning(
            warnings,
            "safe_start_version_invalid",
            "The bundled safe-start VERSION is not a semantic version.",
        )
        return None
    return value


def _platform_report(system_name: str, mac_version: str) -> Dict[str, Any]:
    is_macos = system_name == "Darwin"
    return {
        "system": system_name or "unknown",
        "is_macos": is_macos,
        "macos_version": mac_version or None if is_macos else None,
        "supported": is_macos,
    }


def _cloud_report(cwd: Path) -> Dict[str, Any]:
    normalized = "/" + str(cwd).replace(os.sep, "/").strip("/").lower() + "/"
    for provider, markers in CLOUD_MARKERS:
        if any(marker in normalized for marker in markers):
            return {
                "likely": True,
                "provider": provider,
                "basis": "The physical path contains a known sync-provider location.",
            }
    return {
        "likely": False,
        "provider": None,
        "basis": "No known sync-provider marker was found; this is not proof that sync is off.",
    }


def _git_command(git_path: str, cwd: Path, args: Sequence[str], *, capture: bool = True):
    return _run_command(
        [git_path, "-C", str(cwd)] + list(SAFE_GIT_CONFIG) + list(args),
        capture=capture,
    )


def _git_marker_nearby(cwd: Path) -> bool:
    """Notice fixed .git metadata without opening the marker or project files."""
    for directory in (cwd,) + tuple(cwd.parents):
        if os.path.lexists(str(directory / ".git")):
            return True
    return False


def _config_present(
    git_path: str,
    cwd: Path,
    scope: str,
    key: str,
) -> Optional[str]:
    argv = [git_path]
    if scope in {"local", "worktree"}:
        argv.extend(["-C", str(cwd)])
    argv.extend(SAFE_GIT_CONFIG)
    argv.extend(["config", "--%s" % scope, "--get", key])
    # Git exits zero even when a configured value is empty. Capture only to
    # distinguish blank from present, and never place the value in the report.
    result = _run_command(argv, git_config_scope=scope)
    if result["returncode"] == 0:
        return "present" if result["stdout"].strip() else "empty"
    if result["returncode"] == 1:
        return "absent"
    return None


def _identity_report(
    git_path: str,
    cwd: Path,
    inside_repo: bool,
    warnings: List[Dict[str, str]],
) -> Dict[str, Any]:
    scopes = ["global", "system"]
    if inside_repo:
        scopes.insert(0, "local")
        worktree = _git_command(
            git_path,
            cwd,
            ["config", "--local", "--type=bool", "--get", "extensions.worktreeConfig"],
        )
        if worktree["returncode"] == 0 and worktree["stdout"].strip() == "true":
            scopes.insert(0, "worktree")

    values: Dict[str, Dict[str, Any]] = {}
    for label, key in (("name", "user.name"), ("email", "user.email")):
        present_scopes: List[str] = []
        empty_scopes: List[str] = []
        unavailable_scopes: List[str] = []
        states: Dict[str, Optional[str]] = {}
        for scope in scopes:
            state = _config_present(git_path, cwd, scope, key)
            states[scope] = state
            if state == "present":
                present_scopes.append(scope)
            elif state == "empty":
                empty_scopes.append(scope)
            elif state is None:
                unavailable_scopes.append(scope)
        if unavailable_scopes:
            _warning(
                warnings,
                "git_identity_%s_scope_unavailable" % label,
                "One or more Git configuration scopes could not be checked for user.%s."
                % label,
            )
        effective_scope = next(
            (scope for scope in scopes if states[scope] in {"present", "empty"}),
            None,
        )
        values[label] = {
            "present": (
                effective_scope is not None and states[effective_scope] == "present"
            ),
            "scopes": present_scopes,
            "empty_scopes": empty_scopes,
            "effective_scope": effective_scope,
        }
    values["complete"] = values["name"]["present"] and values["email"]["present"]
    if not values["complete"]:
        _warning(
            warnings,
            "git_identity_incomplete",
            "Git author name and email are not both configured in the checked scopes.",
        )
    return values


def _git_report(
    git_probe: Dict[str, Any],
    cwd: Path,
    warnings: List[Dict[str, str]],
) -> Dict[str, Any]:
    repository: Dict[str, Any] = {
        "inside": None,
        "root": None,
        "clean": None,
    }
    identity: Dict[str, Any] = {
        "name": {
            "present": False,
            "scopes": [],
            "empty_scopes": [],
            "effective_scope": None,
        },
        "email": {
            "present": False,
            "scopes": [],
            "empty_scopes": [],
            "effective_scope": None,
        },
        "complete": False,
    }
    if not git_probe["available"]:
        return {"repository": repository, "identity": identity}

    git_path = git_probe["path"]
    inside = _git_command(
        git_path, cwd, ["rev-parse", "--is-inside-work-tree"]
    )
    if inside["returncode"] == 0 and inside["stdout"].strip() == "true":
        repository["inside"] = True
        root_result = _git_command(git_path, cwd, ["rev-parse", "--show-toplevel"])
        if root_result["returncode"] == 0 and root_result["stdout"].strip():
            repository["root"] = os.path.realpath(root_result["stdout"].strip())
        else:
            _warning(
                warnings,
                "git_root_unknown",
                "Git reports a repository, but its project root could not be resolved.",
            )
        # Do not run `git status` here. Repository-local attributes may attach
        # arbitrary clean filters, and status can execute them while comparing
        # worktree content. A diagnostic cannot make that safe with a finite
        # list of `-c` overrides because filter driver names are user-defined.
        _warning(
            warnings,
            "git_cleanliness_not_checked",
            "Git worktree cleanliness was not checked because status can run "
            "repository-configured helpers; check it separately only in a trusted "
            "workspace.",
        )
    elif inside["returncode"] is not None:
        if _git_marker_nearby(cwd):
            _warning(
                warnings,
                "git_repository_unknown",
                "Git metadata is nearby, but Git repository state could not be checked.",
            )
        else:
            repository["inside"] = False
            _warning(
                warnings,
                "not_a_git_repository",
                "The working folder is not inside a Git repository.",
            )
    else:
        _warning(
            warnings,
            "git_repository_unknown",
            "Git repository state could not be checked.",
        )

    identity = _identity_report(
        git_path, cwd, repository["inside"] is True, warnings
    )
    return {"repository": repository, "identity": identity}


def _read_json_object(path: Path) -> Tuple[str, Optional[Dict[str, Any]]]:
    """Read a fixed Claude settings file without returning any raw content."""
    try:
        if not os.path.lexists(str(path)):
            return "missing", None
        if path.is_symlink() or not path.is_file():
            return "unsafe_type", None
        if path.stat().st_size > 5 * 1024 * 1024:
            return "too_large", None
        raw = path.read_text(encoding="utf-8")
        data = {} if not raw.strip() else json.loads(raw)
        if not isinstance(data, dict):
            return "unexpected_shape", None
        return "ok", data
    except (OSError, UnicodeError, json.JSONDecodeError):
        return "invalid", None


def _load_merger():
    spec = importlib.util.spec_from_file_location("safe_start_doctor_merger", MERGER_FILE)
    if spec is None or spec.loader is None:
        raise ImportError("merge_settings loader unavailable")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _hooks_report(
    settings_path: Path,
    settings_status: str,
    settings_data: Optional[Dict[str, Any]],
    warnings: List[Dict[str, str]],
) -> Dict[str, Any]:
    script_files_present = all(
        (HOOKS_DIR / script).is_file() and not (HOOKS_DIR / script).is_symlink()
        for script in ("pretooluse.py", "userpromptsubmit.py", "sessionstart.py")
    )
    result: Dict[str, Any] = {
        "settings_path": str(settings_path),
        "status": "unverifiable",
        "registered": False,
        "expected_count": 3,
        "owned_count": None,
        "script_files_present": script_files_present,
    }
    if settings_status == "missing":
        result.update({"status": "not_registered", "owned_count": 0})
        _warning(
            warnings,
            "hooks_not_registered",
            "Claude settings do not contain safe-start hook registrations.",
        )
        return result
    if settings_status != "ok" or settings_data is None:
        _warning(
            warnings,
            "hook_settings_unreadable",
            "Claude settings could not be safely parsed for hook verification.",
        )
        return result
    try:
        merger = _load_merger()
        hooks = merger._validate_hooks_schema(settings_data)
    except Exception:  # The doctor must turn package/config problems into warnings.
        _warning(
            warnings,
            "hook_verification_error",
            "safe-start's hook registration schema could not be verified.",
        )
        return result

    expected_records = sorted(
        (event, matcher, str((HOOKS_DIR / script).resolve()))
        for event, (matcher, script) in merger.REGISTRY.items()
    )
    expected_script_paths = {
        str(HOOKS_DIR / script) for _, script in merger.REGISTRY.values()
    } | {record[2] for record in expected_records}
    actual_records = []
    interpreters = set()
    owned_count = 0
    malformed = False
    for event, groups in hooks.items():
        for group in groups:
            for hook in group["hooks"]:
                command = hook.get("command")
                if not isinstance(command, str):
                    continue
                try:
                    parts = shlex.split(command)
                except ValueError:
                    if merger.MARKER in command:
                        owned_count += 1
                        malformed = True
                    continue
                path_matches_loaded_package = (
                    len(parts) == 3 and parts[2] in expected_script_paths
                )
                if merger.MARKER not in command and not path_matches_loaded_package:
                    continue
                owned_count += 1
                if (
                    set(group) != {"matcher", "hooks"}
                    or set(hook) != {"type", "command"}
                    or hook.get("type") != "command"
                ):
                    malformed = True
                    continue
                if len(parts) != 3:
                    malformed = True
                    continue
                interpreter, isolation, script_path = parts
                canonical = "%s -I %s" % (
                    shlex.quote(interpreter),
                    shlex.quote(script_path),
                )
                if (
                    command != canonical
                    or interpreter != merger.SYSTEM_PYTHON
                    or isolation != "-I"
                    or not os.path.isabs(interpreter)
                    or not os.path.isabs(script_path)
                ):
                    malformed = True
                    continue
                try:
                    resolved_script_path = str(Path(script_path).resolve())
                except OSError:
                    malformed = True
                    continue
                interpreters.add(interpreter)
                actual_records.append(
                    (event, group.get("matcher"), resolved_script_path)
                )

    interpreter_available = False
    if len(interpreters) == 1:
        registered_interpreter = next(iter(interpreters))
        interpreter_available = (
            os.path.isfile(registered_interpreter)
            and os.access(registered_interpreter, os.X_OK)
        )

    result["owned_count"] = owned_count
    if owned_count == 0:
        result["status"] = "not_registered"
        _warning(
            warnings,
            "hooks_not_registered",
            "Claude settings do not contain safe-start hook registrations.",
        )
    elif (
        not malformed
        and sorted(actual_records) == expected_records
        and script_files_present
        and interpreter_available
    ):
        result.update({"status": "registered", "registered": True})
    else:
        result["status"] = "mismatch"
        _warning(
            warnings,
            "hook_registration_mismatch",
            "safe-start hook registrations or installed hook files do not match this package.",
        )
    return result


def _permission_report(
    sources: Sequence[Tuple[str, Path]],
    cached_settings: Dict[Path, Tuple[str, Optional[Dict[str, Any]]]],
    warnings: List[Dict[str, str]],
) -> Dict[str, Any]:
    configured: List[Dict[str, Any]] = []
    checked: List[Dict[str, str]] = []
    for scope, path in sources:
        status, data = cached_settings.get(path, (None, None))
        if status is None:
            status, data = _read_json_object(path)
            cached_settings[path] = (status, data)
        checked.append({"scope": scope, "path": str(path), "status": status})
        if status not in {"ok", "missing"}:
            _warning(
                warnings,
                "permission_settings_%s_unreadable" % scope,
                "The %s Claude settings file could not be safely parsed." % scope,
            )
            continue
        if not data:
            continue
        permissions = data.get("permissions")
        if not isinstance(permissions, dict) or "defaultMode" not in permissions:
            continue
        raw_mode = permissions.get("defaultMode")
        recognized = isinstance(raw_mode, str) and raw_mode in KNOWN_PERMISSION_MODES
        configured.append({
            "scope": scope,
            "path": str(path),
            "mode": raw_mode if recognized else None,
            "recognized": recognized,
        })
        if not recognized:
            _warning(
                warnings,
                "permission_mode_%s_unknown" % scope,
                "The %s Claude settings file has an unrecognized default permission mode."
                % scope,
            )
        elif raw_mode == "auto" and scope in {"project", "project_local"}:
            _warning(
                warnings,
                "permission_mode_%s_auto_ignored" % scope,
                (
                    "Current Claude Code ignores auto as a %s settings default; "
                    "this does not establish the active session mode."
                ) % scope,
            )
        elif raw_mode in REDUCED_REVIEW_PERMISSION_MODES:
            _warning(
                warnings,
                "permission_mode_%s_reduced_review" % scope,
                (
                    "The %s settings default is %s, which reduces one or more "
                    "ask-before-acting checks; this does not establish the active "
                    "session mode."
                ) % (scope, raw_mode),
            )
    return {
        "configured_defaults": configured,
        "sources_checked": checked,
        "active_session_mode_observed": False,
        "note": (
            "Settings defaults are not proof of the active Claude Code session mode; "
            "check /permissions in that session."
        ),
    }


def _claude_md_report(project_root: Path, home: Path) -> Dict[str, Any]:
    candidates = [
        ("project_root", project_root / "CLAUDE.md"),
        ("project_dot_claude", project_root / ".claude" / "CLAUDE.md"),
        ("user", home / ".claude" / "CLAUDE.md"),
    ]
    items = [
        {
            "scope": scope,
            "path": str(path),
            "present": path.is_file(),
        }
        for scope, path in candidates
    ]
    return {
        "locations": items,
        "project_present": any(
            item["present"] and item["scope"].startswith("project") for item in items
        ),
        "user_present": any(
            item["present"] and item["scope"] == "user" for item in items
        ),
    }


def collect_report(
    *,
    cwd: Optional[Path] = None,
    home: Optional[Path] = None,
    system_name: Optional[str] = None,
    mac_version: Optional[str] = None,
    finder: Callable[[str], Optional[str]] = DEFAULT_FINDER,
) -> Dict[str, Any]:
    warnings: List[Dict[str, str]] = []
    physical_cwd = Path(os.path.realpath(str(cwd))) if cwd is not None else _physical_cwd()
    physical_home = Path(os.path.realpath(str(home))) if home is not None else _home_path()
    if not physical_cwd.is_dir():
        raise DoctorInvocationError("the current working folder is not accessible")

    system_value = platform.system() if system_name is None else system_name
    mac_value = platform.mac_ver()[0] if mac_version is None else mac_version
    platform_data = _platform_report(system_value, mac_value)
    if not platform_data["supported"]:
        _warning(
            warnings,
            "unsupported_platform",
            "safe-start's Claude Code hooks support macOS; this platform is reported only.",
        )

    # Production macOS runs bind Git to the sealed system entry point. Explicit
    # finder injection remains available to the hermetic unit tests and to
    # unsupported-platform reporting, but the CLI never trusts PATH for Git.
    git_finder = (
        _macos_system_git
        if platform_data["is_macos"] and finder is DEFAULT_FINDER
        else finder
    )
    git_probe = _command_probe("git", warnings, git_finder)
    claude_probe = _command_probe("claude", warnings, finder)
    git_data = _git_report(git_probe, physical_cwd, warnings)
    project_root = Path(git_data["repository"]["root"] or physical_cwd)

    user_settings = physical_home / ".claude" / "settings.json"
    shared_settings = project_root / ".claude" / "settings.json"
    local_settings = project_root / ".claude" / "settings.local.json"
    settings_cache: Dict[Path, Tuple[str, Optional[Dict[str, Any]]]] = {}
    settings_cache[user_settings] = _read_json_object(user_settings)
    settings_status, settings_data = settings_cache[user_settings]

    hooks = _hooks_report(
        user_settings,
        settings_status,
        settings_data,
        warnings,
    )
    permissions = _permission_report(
        (
            ("user", user_settings),
            ("project", shared_settings),
            ("project_local", local_settings),
        ),
        settings_cache,
        warnings,
    )

    cloud = _cloud_report(physical_cwd)
    if cloud["likely"]:
        _warning(
            warnings,
            "cloud_sync_path_likely",
            "The working folder is in a likely %s-synced location." % cloud["provider"],
        )

    return {
        "schema_version": SCHEMA_VERSION,
        "cwd": {"physical": str(physical_cwd)},
        "platform": platform_data,
        "commands": {"git": git_probe, "claude": claude_probe},
        "git": git_data,
        "cloud_sync": cloud,
        "safe_start": {
            "root": str(ROOT),
            "version": _read_version(warnings),
        },
        "hooks": hooks,
        "permissions": permissions,
        "claude_md": _claude_md_report(project_root, physical_home),
        "warnings": warnings,
    }


def _availability_line(label: str, data: Dict[str, Any]) -> str:
    if not data["found"]:
        return "%s: not found" % label
    if not data["available"]:
        return "%s: found, but unavailable" % label
    return "%s: available%s" % (
        label,
        " — %s" % data["version"] if data["version"] else "",
    )


def _display_path(path: str) -> str:
    """Quote path controls/newlines while preserving the exact path value."""
    return json.dumps(path, ensure_ascii=True)


def _permission_mode_label(mode: str) -> str:
    if mode == "default":
        return "Manual (default)"
    if mode == "manual":
        return "Manual (manual alias)"
    return mode


def _identity_line(identity: Dict[str, Any]) -> str:
    parts = []
    for label in ("name", "email"):
        item = identity[label]
        if item["present"]:
            parts.append("%s configured (%s)" % (label, item["effective_scope"]))
        elif item["effective_scope"] in item.get("empty_scopes", []):
            parts.append(
                "%s not configured (empty %s value)"
                % (label, item["effective_scope"])
            )
        else:
            parts.append("%s not configured" % label)
    return "Git identity: " + "; ".join(parts) + " — values are not shown"


def render_human(report: Dict[str, Any]) -> str:
    version = report["safe_start"]["version"] or "unknown"
    platform_data = report["platform"]
    if platform_data["is_macos"]:
        platform_text = "macOS%s (supported)" % (
            " " + platform_data["macos_version"]
            if platform_data["macos_version"] else ""
        )
    else:
        platform_text = "%s (not the supported safe-start platform)" % platform_data["system"]

    repository = report["git"]["repository"]
    if repository["inside"] is True:
        state = "clean" if repository["clean"] is True else (
            "has changes" if repository["clean"] is False else "state unknown"
        )
        repo_text = "inside a Git repository — %s" % state
        if repository["root"]:
            repo_text += "\nGit project root: %s" % _display_path(repository["root"])
    elif repository["inside"] is False:
        repo_text = "not inside a Git repository"
    else:
        repo_text = "could not determine repository state"

    cloud = report["cloud_sync"]
    cloud_text = (
        "likely %s-synced path" % cloud["provider"]
        if cloud["likely"] else
        "no known provider marker found (not proof that sync is off)"
    )

    hooks = report["hooks"]
    hook_labels = {
        "registered": "registration points to this installed package",
        "not_registered": "not registered",
        "mismatch": "registration mismatch",
        "unverifiable": "could not verify",
    }

    configured = report["permissions"]["configured_defaults"]
    known = [
        "%s=%s" % (
            item["scope"],
            _permission_mode_label(item["mode"]),
        )
        for item in configured if item["recognized"]
    ]
    unknown_count = sum(1 for item in configured if not item["recognized"])
    if known:
        permission_text = ", ".join(known)
    else:
        permission_text = "no recognized defaults found"
    if unknown_count:
        permission_text += "; %d unrecognized value%s hidden" % (
            unknown_count, "" if unknown_count == 1 else "s"
        )

    claude_md = report["claude_md"]
    project_notes = [
        _display_path(item["path"]) for item in claude_md["locations"]
        if item["present"] and item["scope"].startswith("project")
    ]
    notes_text = ", ".join(project_notes) if project_notes else "not found at the project root"

    lines = [
        "safe-start doctor v%s" % version,
        "Working folder (physical): %s" % _display_path(report["cwd"]["physical"]),
        "Platform: %s" % platform_text,
        _availability_line("Git", report["commands"]["git"]),
        _availability_line("Claude Code", report["commands"]["claude"]),
        "Git project: %s" % repo_text,
        _identity_line(report["git"]["identity"]),
        "Cloud sync: %s" % cloud_text,
        "safe-start hooks: %s (%s)" % (
            hook_labels.get(hooks["status"], hooks["status"]),
            _display_path(hooks["settings_path"]),
        ),
        "Configured permission defaults (not current session mode): %s" % permission_text,
        "Active Claude permission mode: not observable here; use /permissions in Claude Code",
        "Project CLAUDE.md: %s" % notes_text,
    ]
    if report["warnings"]:
        lines.append("Warnings:")
        lines.extend("  - %s" % item["message"] for item in report["warnings"])
    else:
        lines.append("Warnings: none")
    lines.append("Doctor completed; ordinary warnings do not change its exit status.")
    return "\n".join(lines) + "\n"


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Read-only macOS/Claude Code preflight for safe-start."
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="emit a stable JSON report instead of plain-language output",
    )
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = _parser().parse_args(argv)
    try:
        report = collect_report()
    except DoctorInvocationError as exc:
        sys.stderr.write("safe-start doctor could not run: %s\n" % exc)
        return 1
    except Exception:
        sys.stderr.write("safe-start doctor could not run because of an internal error.\n")
        return 1
    if args.json:
        sys.stdout.write(json.dumps(report, indent=2, sort_keys=True) + "\n")
    else:
        sys.stdout.write(render_human(report))
    return 0


if __name__ == "__main__":
    sys.exit(main())
