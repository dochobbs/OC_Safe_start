#!/bin/bash
# SPDX-License-Identifier: Apache-2.0
# Install or update safe-start without exposing a half-installed safety net.
#
#   /usr/bin/curl -fsSL <url>/install.sh | /bin/bash
#
# Remote installs are pinned to a release tag.  Developers may explicitly set
# SAFE_START_SRC to test a local checkout.
set -euo pipefail
umask 077
SAFE_SYSTEM_PATH="/usr/bin:/bin:/usr/sbin:/sbin"
SYSTEM_PYTHON="/usr/bin/python3"
# The package is executable code. Do not let a caller-controlled PATH choose
# the shell tools or Python runtime that validate, install, and register it.
export PATH="$SAFE_SYSTEM_PATH"
unset PYTHONHOME PYTHONINSPECT PYTHONPATH PYTHONSTARTUP
export PYTHONDONTWRITEBYTECODE=1
export PYTHONNOUSERSITE=1

# Git is part of the remote-package trust boundary. A caller's shell may carry
# repository redirects (GIT_DIR/GIT_WORK_TREE), injected config, URL rewrites,
# trace sinks, credential helpers, or prompt helpers. Clear every inherited
# GIT_* shell variable, then install only the small fixed environment required
# for deterministic, non-interactive clone and ref verification. This runs in
# the installer process as well as inside safe_git so staged self-tests cannot
# inherit the hostile Git environment either. Bash 3.2's compgen and process
# substitution are available on the oldest supported macOS shell.
sanitize_git_environment() {
  while IFS= read -r variable_name; do
    unset "$variable_name"
  done < <(compgen -A variable GIT_ || true)
  unset SSH_AGENT_PID SSH_ASKPASS SSH_ASKPASS_REQUIRE SSH_AUTH_SOCK GCM_INTERACTIVE
  export GIT_ASKPASS=/usr/bin/false
  export GIT_CONFIG_COUNT=0
  export GIT_CONFIG_GLOBAL=/dev/null
  export GIT_CONFIG_NOSYSTEM=1
  export GIT_CONFIG_SYSTEM=/dev/null
  export GIT_NO_REPLACE_OBJECTS=1
  export GIT_OPTIONAL_LOCKS=0
  export GIT_SSH_COMMAND='/usr/bin/ssh -oBatchMode=yes'
  export GIT_SSH_VARIANT=ssh
  export GIT_TERMINAL_PROMPT=0
  export SSH_ASKPASS=/usr/bin/false
  export SSH_ASKPASS_REQUIRE=force
  export GCM_INTERACTIVE=never
}

safe_git() (
  sanitize_git_environment
  PATH="$SAFE_SYSTEM_PATH" /usr/bin/git "$@"
)

sanitize_git_environment

CLAUDE_LINK="${HOME:?HOME must be set}/.claude"
CLAUDE_DIR="$CLAUDE_LINK"
SKILLS_DIR="$CLAUDE_DIR/skills"
DEST="$SKILLS_DIR/safe-start"
STATE_DIR="$CLAUDE_DIR/safe-start"
CONFIG="$STATE_DIR/config.json"
DEFAULT_REF="v1.1.0"

STAGE_ROOT=""
STAGED_DEST=""
CLONE_ROOT=""
BACKUP_ROOT=""
CONFIG_TMP=""
TRANSACTION_OPEN=0
OLD_INSTALL_SAVED=0
NEW_INSTALL_PLACED=0
REGISTRATION_IN_PROGRESS=0
COMMITTED=0
STATE_CREATED=0
CONFIG_CREATED=0
PRESERVE_BACKUP=0
PATHS_PREPARED=0

say() { printf '%s\n' "$*"; }
ignore_interrupts() { trap '' HUP INT TERM; }
restore_interrupts() { trap 'exit 130' HUP INT TERM; }

prepare_install_paths() {
  local logical_skills
  # A symlinked ~/.claude is an explicitly supported relocation. Resolve that
  # one boundary once, but do not let a nested `skills` link redirect package
  # replacement and recursive cleanup into an unrelated directory.
  if [ -L "$CLAUDE_LINK" ]; then
    if [ ! -d "$CLAUDE_LINK" ]; then
      say "  ✗ $CLAUDE_LINK must point to a real directory."
      return 1
    fi
  elif [ -e "$CLAUDE_LINK" ] && [ ! -d "$CLAUDE_LINK" ]; then
    say "  ✗ $CLAUDE_LINK must be a directory."
    return 1
  elif [ ! -e "$CLAUDE_LINK" ]; then
    if ! mkdir -- "$CLAUDE_LINK"; then
      say "  ✗ Could not create $CLAUDE_LINK."
      return 1
    fi
  fi

  logical_skills="$CLAUDE_LINK/skills"
  if [ -L "$logical_skills" ]; then
    say "  ✗ $logical_skills must be a real directory, not a link."
    return 1
  fi
  if [ -e "$logical_skills" ] && [ ! -d "$logical_skills" ]; then
    say "  ✗ $logical_skills must be a directory."
    return 1
  fi
  if [ ! -d "$logical_skills" ]; then
    if ! mkdir -- "$logical_skills"; then
      say "  ✗ Could not create $logical_skills."
      return 1
    fi
  fi
  # Recheck after creation so a concurrent replacement cannot be accepted as
  # the directory that was just prepared.
  if [ -L "$logical_skills" ] || [ ! -d "$logical_skills" ]; then
    say "  ✗ $logical_skills changed while it was being prepared."
    return 1
  fi

  CLAUDE_DIR="$(CDPATH= cd -- "$CLAUDE_LINK" && pwd -P)" || return 1
  SKILLS_DIR="$(CDPATH= cd -- "$logical_skills" && pwd -P)" || return 1
  if [ "$SKILLS_DIR" != "$CLAUDE_DIR/skills" ]; then
    say "  ✗ $logical_skills resolves outside the Claude directory."
    return 1
  fi
  DEST="$SKILLS_DIR/safe-start"
  STATE_DIR="$CLAUDE_DIR/safe-start"
  CONFIG="$STATE_DIR/config.json"
  PATHS_PREPARED=1
}

managed_roots_are_safe() {
  [ "$PATHS_PREPARED" -eq 1 ] \
    && [ -d "$CLAUDE_DIR" ] \
    && [ ! -L "$CLAUDE_DIR" ] \
    && [ -d "$SKILLS_DIR" ] \
    && [ ! -L "$SKILLS_DIR" ] \
    && [ "$SKILLS_DIR" = "$CLAUDE_DIR/skills" ] \
    && [ "$(CDPATH= cd -- "$CLAUDE_DIR" 2>/dev/null && pwd -P)" = "$CLAUDE_DIR" ] \
    && [ "$(CDPATH= cd -- "$SKILLS_DIR" 2>/dev/null && pwd -P)" = "$SKILLS_DIR" ]
}

managed_tree_is_safe() {
  local candidate="$1"
  local parent="$2"
  [ "${candidate%/*}" = "$parent" ] \
    && [ ! -L "$candidate" ] \
    && { [ ! -e "$candidate" ] || [ -d "$candidate" ]; }
}

remove_managed_tree() {
  local candidate="$1"
  local parent="$2"
  if ! managed_roots_are_safe \
    || ! managed_tree_is_safe "$candidate" "$parent"; then
    say "  ✗ Refusing unsafe cleanup path: $candidate"
    return 1
  fi
  if [ -d "$candidate" ]; then
    rm -rf -- "$candidate"
  fi
}

cleanup() {
  status=$?
  trap - EXIT HUP INT TERM
  set +e

  if [ "$REGISTRATION_IN_PROGRESS" -eq 1 ]; then
    PRESERVE_BACKUP=1
    say "  ✗ installation was interrupted while settings were being updated."
    say "    The new hook files and previous-install backup were preserved;"
    say "    re-run the installer to converge safely."
  elif [ "$TRANSACTION_OPEN" -eq 1 ] && [ "$COMMITTED" -eq 0 ]; then
    if [ "$NEW_INSTALL_PLACED" -eq 1 ] \
      && { [ -e "$DEST" ] || [ -L "$DEST" ]; } \
      && ! remove_managed_tree "$DEST" "$SKILLS_DIR"; then
      PRESERVE_BACKUP=1
      status=1
    fi
    if [ "$OLD_INSTALL_SAVED" -eq 1 ] \
      && [ -d "$BACKUP_ROOT/safe-start" ]; then
      if managed_roots_are_safe \
        && managed_tree_is_safe "$BACKUP_ROOT" "$SKILLS_DIR" \
        && [ ! -L "$BACKUP_ROOT/safe-start" ] \
        && [ -d "$BACKUP_ROOT/safe-start" ] \
        && [ ! -e "$DEST" ] \
        && mv -- "$BACKUP_ROOT/safe-start" "$DEST"; then
        say "  ✓ restored the previous safe-start installation"
      else
        PRESERVE_BACKUP=1
        status=1
        say "  ✗ automatic restore failed; the previous installation is"
        say "    preserved at $BACKUP_ROOT/safe-start"
      fi
    fi
  fi

  if [ "$COMMITTED" -eq 0 ] && [ "$REGISTRATION_IN_PROGRESS" -eq 0 ] \
    && managed_roots_are_safe \
    && managed_tree_is_safe "$STATE_DIR" "$CLAUDE_DIR"; then
    if [ "$CONFIG_CREATED" -eq 1 ]; then
      rm -f -- "$CONFIG"
    fi
    if [ "$STATE_CREATED" -eq 1 ]; then
      rmdir -- "$STATE_DIR" 2>/dev/null
    fi
  fi

  if [ -n "$CONFIG_TMP" ]; then
    if managed_roots_are_safe \
      && managed_tree_is_safe "$STATE_DIR" "$CLAUDE_DIR" \
      && [ "${CONFIG_TMP%/*}" = "$STATE_DIR" ]; then
      rm -f -- "$CONFIG_TMP"
    else
      say "  ✗ Refusing unsafe cleanup path: $CONFIG_TMP"
      status=1
    fi
  fi
  if [ -n "$STAGE_ROOT" ] \
    && ! remove_managed_tree "$STAGE_ROOT" "$SKILLS_DIR"; then
    status=1
  fi
  if [ -n "$CLONE_ROOT" ]; then
    rm -rf -- "$CLONE_ROOT"
  fi
  if [ -n "$BACKUP_ROOT" ] && [ "$PRESERVE_BACKUP" -eq 0 ] \
    && ! remove_managed_tree "$BACKUP_ROOT" "$SKILLS_DIR"; then
    status=1
  fi
  exit "$status"
}

trap cleanup EXIT
restore_interrupts

say "Installing safe-start…"

# --- prerequisites -------------------------------------------------------- #
PYTHON_BIN="$SYSTEM_PYTHON"
if [ ! -x "$PYTHON_BIN" ]; then
  say "  ✗ Python 3 is required (it ships with the macOS developer tools:"
  say "    run 'xcode-select --install', then try again)."
  exit 1
fi
if ! "$PYTHON_BIN" -I -c \
  'import sys; raise SystemExit(sys.version_info < (3, 9))'; then
  say "  ✗ safe-start requires Python 3.9 or newer."
  exit 1
fi
if [ ! -x /usr/bin/git ]; then
  say "  ✗ git is required (run 'xcode-select --install', then try again)."
  exit 1
fi

# --- locate an explicit local source, a real adjacent file, or a pinned tag #
# Do not fall back to $0 or the current directory: when this script is piped to
# bash, those identify bash/the caller's CWD rather than the downloaded file.
SCRIPT_FILE="${BASH_SOURCE[0]:-}"
SCRIPT_DIR=""
if [ -n "$SCRIPT_FILE" ] && [ -f "$SCRIPT_FILE" ]; then
  SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$SCRIPT_FILE")" && pwd -P)"
fi

REMOTE_SOURCE=0
if [ -n "${SAFE_START_SRC:-}" ]; then
  if [ ! -d "$SAFE_START_SRC" ]; then
    say "  ✗ SAFE_START_SRC is not a directory: $SAFE_START_SRC"
    exit 1
  fi
  SRC="$(CDPATH= cd -- "$SAFE_START_SRC" && pwd -P)"
elif [ -n "$SCRIPT_DIR" ] \
  && [ -f "$SCRIPT_DIR/SKILL.md" ] \
  && [ -f "$SCRIPT_DIR/hooks/pretooluse.py" ]; then
  SRC="$SCRIPT_DIR"
else
  REPO_URL="${SAFE_START_REPO:-https://github.com/dochobbs/OC_Safe_start.git}"
  REPO_REF="${SAFE_START_REF:-$DEFAULT_REF}"
  case "$REPO_REF" in
    ""|-*)
      say "  ✗ SAFE_START_REF must be a non-empty Git ref, not an option."
      exit 1
      ;;
  esac
  if ! safe_git check-ref-format "refs/tags/$REPO_REF" >/dev/null 2>&1; then
    say "  ✗ SAFE_START_REF must name a valid Git tag."
    exit 1
  fi
  CLONE_ROOT="$(mktemp -d)"
  SRC="$CLONE_ROOT"
  REMOTE_SOURCE=1
  say "  Fetching safe-start ${REPO_REF}…"
  if ! safe_git clone --depth 1 --branch "$REPO_REF" -- "$REPO_URL" "$SRC" \
    >/dev/null 2>&1; then
    say "  ✗ Could not fetch safe-start $REPO_REF from $REPO_URL"
    say "    Set SAFE_START_SRC to an explicit local copy and re-run."
    exit 1
  fi
  if ! HEAD_COMMIT="$(safe_git -C "$SRC" rev-parse --verify HEAD 2>/dev/null)" \
    || ! REF_COMMIT="$(safe_git -C "$SRC" rev-parse --verify \
      "refs/tags/${REPO_REF}^{commit}" \
      2>/dev/null)" \
    || [ -z "$HEAD_COMMIT" ] \
    || [ "$HEAD_COMMIT" != "$REF_COMMIT" ]; then
    say "  ✗ The fetched checkout is not the exact $REPO_REF tag; refusing it."
    exit 1
  fi
fi

# --- stage and validate without touching the live installation ------------ #
if ! prepare_install_paths; then
  exit 1
fi
STAGE_ROOT="$(mktemp -d "$SKILLS_DIR/.safe-start.stage.XXXXXX")"
STAGED_DEST="$STAGE_ROOT/safe-start"
mkdir -- "$STAGED_DEST"

if ! (cd -- "$SRC" \
  && tar --exclude='.git' --exclude='__pycache__' --exclude='*.pyc' -cf - .) \
  | (cd -- "$STAGED_DEST" && tar -xf -); then
  say "  ✗ Could not stage the safe-start files; the live install is unchanged."
  exit 1
fi

# A package is executable code. Refuse links, devices, sockets, and other
# entries whose eventual target or behavior is not contained in the reviewed
# package bytes.
if find "$STAGED_DEST" ! -type f ! -type d -print -quit | grep -q .; then
  say "  ✗ Source validation failed: package entries must be regular files or directories."
  exit 1
fi

REQUIRED_FILES=(
  "LICENSE"
  "SKILL.md"
  "VERSION"
  "install.sh"
  "uninstall.sh"
  "hooks/pretooluse.py"
  "hooks/userpromptsubmit.py"
  "hooks/sessionstart.py"
  "install/merge_settings.py"
  "scripts/doctor.py"
  "tests/test_detectors.py"
  "tests/test_doctor.py"
  "tests/test_hooks.py"
  "tests/test_lifecycle.py"
)
for relative_path in "${REQUIRED_FILES[@]}"; do
  if [ ! -f "$STAGED_DEST/$relative_path" ] \
    || [ -L "$STAGED_DEST/$relative_path" ]; then
    say "  ✗ Source validation failed: missing regular file $relative_path"
    exit 1
  fi
done

PACKAGE_VERSION="$(tr -d '\r\n' < "$STAGED_DEST/VERSION")"
if [[ ! "$PACKAGE_VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
  say "  ✗ VERSION must contain a semantic version such as 1.1.0."
  exit 1
fi
if [ "$REMOTE_SOURCE" -eq 1 ]; then
  if [[ "$REPO_REF" =~ ^v[0-9]+\.[0-9]+\.[0-9]+$ ]] \
    && [ "v$PACKAGE_VERSION" != "$REPO_REF" ]; then
    say "  ✗ Release mismatch: $REPO_REF contains VERSION $PACKAGE_VERSION."
    exit 1
  fi
fi

chmod 755 \
  "$STAGED_DEST/install.sh" \
  "$STAGED_DEST/uninstall.sh" \
  "$STAGED_DEST/scripts/doctor.py"
if ! /bin/bash -n "$STAGED_DEST/install.sh" "$STAGED_DEST/uninstall.sh" \
  || ! /usr/bin/env PATH="$SAFE_SYSTEM_PATH" PYTHONDONTWRITEBYTECODE=1 \
    PYTHONNOUSERSITE=1 "$PYTHON_BIN" -I -c \
    'import pathlib, sys; compile(pathlib.Path(sys.argv[1]).read_text(), sys.argv[1], "exec")' \
    "$STAGED_DEST/install/merge_settings.py" \
  || ! /usr/bin/env PATH="$SAFE_SYSTEM_PATH" PYTHONDONTWRITEBYTECODE=1 \
    PYTHONNOUSERSITE=1 "$PYTHON_BIN" -I -c \
    'import pathlib, sys; compile(pathlib.Path(sys.argv[1]).read_text(), sys.argv[1], "exec")' \
    "$STAGED_DEST/scripts/doctor.py"; then
  say "  ✗ Installer validation failed; the live install is unchanged."
  exit 1
fi

TEST_LOG="$STAGE_ROOT/self-test.log"
if ! /usr/bin/env PATH="$SAFE_SYSTEM_PATH" PYTHONDONTWRITEBYTECODE=1 \
    PYTHONNOUSERSITE=1 "$PYTHON_BIN" -I \
    "$STAGED_DEST/tests/test_detectors.py" \
    >"$TEST_LOG" 2>&1 \
  || ! /usr/bin/env PATH="$SAFE_SYSTEM_PATH" PYTHONDONTWRITEBYTECODE=1 \
    PYTHONNOUSERSITE=1 "$PYTHON_BIN" -I \
    "$STAGED_DEST/tests/test_hooks.py" \
    >>"$TEST_LOG" 2>&1 \
  || ! /usr/bin/env PATH="$SAFE_SYSTEM_PATH" PYTHONDONTWRITEBYTECODE=1 \
    PYTHONNOUSERSITE=1 "$PYTHON_BIN" -I \
    "$STAGED_DEST/tests/test_doctor.py" \
    >>"$TEST_LOG" 2>&1; then
  say "  ✗ Self-test failed; the live install is unchanged."
  cat "$TEST_LOG" >&2
  exit 1
fi
say "  ✓ detection + hook + doctor self-test passed"

# --- prepare private state before opening the install transaction ---------- #
if [ -L "$STATE_DIR" ] \
  || { [ -e "$STATE_DIR" ] && [ ! -d "$STATE_DIR" ]; }; then
  say "  ✗ $STATE_DIR must be a real directory, not a link or file."
  exit 1
fi
if [ ! -d "$STATE_DIR" ]; then
  mkdir -- "$STATE_DIR"
  STATE_CREATED=1
fi
chmod 700 "$STATE_DIR"

if [ -L "$CONFIG" ] \
  || { [ -e "$CONFIG" ] && [ ! -f "$CONFIG" ]; }; then
  say "  ✗ $CONFIG must be a regular file, not a link."
  exit 1
fi
if [ -f "$CONFIG" ]; then
  chmod 600 "$CONFIG"
else
  CONFIG_TMP="$(mktemp "$STATE_DIR/.config.json.XXXXXX")"
  chmod 600 "$CONFIG_TMP"
  printf '{\n  "verbosity": "teaching"\n}\n' > "$CONFIG_TMP"
  mv -- "$CONFIG_TMP" "$CONFIG"
  CONFIG_TMP=""
  CONFIG_CREATED=1
fi

# --- atomically replace the live skill, then register and verify its hooks -- #
if ! managed_roots_are_safe; then
  say "  ✗ The Claude install directories changed; refusing to replace anything."
  exit 1
fi
if [ -L "$DEST" ] || { [ -e "$DEST" ] && [ ! -d "$DEST" ]; }; then
  say "  ✗ $DEST must be a real directory; refusing to replace it."
  exit 1
fi

BACKUP_ROOT="$(mktemp -d "$SKILLS_DIR/.safe-start.backup.XXXXXX")"
TRANSACTION_OPEN=1

# A rename and its state flag form one logical step. Ignore catchable signals
# only across these tiny windows so cleanup never mistakes the old install for
# the new one or loses track of the backup.
ignore_interrupts
if [ -d "$DEST" ]; then
  if ! mv -- "$DEST" "$BACKUP_ROOT/safe-start"; then
    restore_interrupts
    say "  ✗ Could not preserve the previous installation; nothing was replaced."
    exit 1
  fi
  OLD_INSTALL_SAVED=1
fi
if ! managed_roots_are_safe || [ -e "$DEST" ] || [ -L "$DEST" ]; then
  restore_interrupts
  say "  ✗ The install destination changed; rolling back."
  exit 1
fi
if ! mv -- "$STAGED_DEST" "$DEST"; then
  restore_interrupts
  say "  ✗ Could not activate the staged installation; rolling back."
  exit 1
fi
NEW_INSTALL_PLACED=1
restore_interrupts

# If interrupted while the transactional settings merger is running, cleanup
# preserves both the new scripts and the old backup. That avoids dangling hook
# commands while still allowing a blocked lock acquisition to be interrupted.
REGISTRATION_IN_PROGRESS=1
if ! "$PYTHON_BIN" -I "$DEST/install/merge_settings.py" add "$DEST/hooks" \
  --claude-dir "$CLAUDE_DIR"; then
  REGISTRATION_IN_PROGRESS=0
  say "  ✗ Guard registration failed; the new installation will be rolled back."
  exit 1
fi
COMMITTED=1
REGISTRATION_IN_PROGRESS=0

say "  ✓ guards registered and verified in $CLAUDE_DIR/settings.json"

cat <<EOF

  ──────────────────────────────────────────────
  safe-start v$PACKAGE_VERSION is on. Quietly, in every project, it:
    • asks before covered high-blast-radius delete/history commands
    • rejects a prompt when it detects a secret or structured
      patient identifier, and checks Git candidates too
    • asks before direct paths leave your project; this is advisory,
      not a sandbox
    • greets you with where you are, and helps if Git tangles

  Remove anytime:  ~/.claude/skills/safe-start/uninstall.sh
  Check setup:     /usr/bin/python3 -I ~/.claude/skills/safe-start/scripts/doctor.py
  ──────────────────────────────────────────────
EOF
