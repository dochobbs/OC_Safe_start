#!/usr/bin/env python3
"""Guard the lesson's route, return, and recovery contracts."""

from __future__ import annotations

from pathlib import Path


SKILL_ROOT = Path(__file__).resolve().parents[1]
SKILL = SKILL_ROOT / "SKILL.md"
MIRROR = SKILL_ROOT.parents[1] / "docs" / "team" / "the-lesson-skill.md"
SESSIONS = SKILL_ROOT / "references" / "sessions-and-context.md"
PERMISSIONS = SKILL_ROOT / "references" / "permissions-and-autonomy.md"
BASIC_USE = SKILL_ROOT / "references" / "basic-use-and-safety.md"


def require(condition: bool, message: str) -> None:
  if not condition:
    raise AssertionError(message)


def section(text: str, start: str, end: str) -> str:
  require(start in text, f"missing section start: {start}")
  require(end in text, f"missing section end: {end}")
  return text.split(start, 1)[1].split(end, 1)[0]


def main() -> int:
  skill = SKILL.read_text(encoding="utf-8")
  mirror = MIRROR.read_text(encoding="utf-8")
  sessions = SESSIONS.read_text(encoding="utf-8")
  permissions = PERMISSIONS.read_text(encoding="utf-8")
  basic_use = BASIC_USE.read_text(encoding="utf-8")
  compact_sessions = " ".join(sessions.split())
  compact_basic_use = " ".join(basic_use.split())

  require(len(skill.splitlines()) < 500, "SKILL.md must stay under 500 lines")
  require(skill == mirror, "team lesson mirror differs from packaged SKILL.md")

  require(
    "Only when the user seeks general first-time orientation" in skill,
    "generic opening is no longer limited to general orientation",
  )
  require(
    "A direct build, learn, explore,\nprivacy, permissions, pause, or return request goes straight to that branch"
    in skill,
    "direct requests can be diverted through the generic route menu",
  )
  require(
    "a reviewed isolated project reduces—never eliminates—risk" in skill
    and "nothing happens until you say yes" in skill
    and "it only affects this folder" in skill,
    "nervous-user opening can again make an absolute safety promise",
  )
  require(
    "The hard opening's second line is the route\nquestion" in skill
    and "Never repeat it after an answer" in skill
    and "Do not replay the hard opening or route question" in skill,
    "route choice can be asked again after the user already answered",
  )

  build = section(
    skill,
    "After the user chooses **Build**",
    "**Load only the reference",
  )
  compact_skill = " ".join(skill.split())
  compact_build = " ".join(build.split())
  agenda = section(
    skill,
    "**Hand them the agenda once.**",
    "After the user chooses **Build**",
  )
  compact_agenda = " ".join(agenda.split())
  read_room = section(
    skill,
    "**Read the room and keep the choice reversible.**",
    "When both signals appear",
  )
  compact_read_room = " ".join(read_room.split())
  require(
    "Treat the three choices as invitations" in compact_agenda
    and "- **Build**" in agenda
    and "- **Learn**" in agenda
    and "- **Explore**" in agenda
    and "Exploration does not have to end in a file" in compact_agenda,
    "Build, Learn, and Explore are no longer neutral peer routes",
  )
  require(
    "do not know what to build or where to start" in compact_agenda
    and "one sentence, one annoyance" in compact_agenda
    and "When it is done, offer another annoyance" in compact_agenda
    and "Never start one of those routes without a new affirmative choice"
    in compact_agenda,
    "the one-annoyance prompt can again become an automatic build sequence",
  )
  require(
    "**Already experienced**" in read_room
    and "explicitly offer to skip ahead" in compact_read_room
    and "Want to skip to building, explore a capability, or stop here?"
    in compact_read_room,
    "already-experienced users can again be sent through the basic lesson",
  )
  require(
    "**Pushes back on redirection**" in read_room
    and "stop steering immediately" in compact_read_room
    and "Do not defend the drill, call it \"tiny,\" bargain for two minutes"
    in compact_read_room
    and "declining the drill ends the drill with no guilt or warning"
    in compact_read_room,
    "pushback no longer makes the lesson back off without bargaining",
  )
  require(
    "Tool-call preflight is mandatory" in compact_skill
    and "the entire Bash input must be exactly `mkdir -- \"<approved absolute path>\"`"
    in compact_skill
    and "`mkdir -p`, operators, arguments to `git init`, and listing or existence checks are forbidden"
    in compact_skill
    and "for its repository initialization, exactly `git init`" in compact_skill
    and "arguments to `git init`" in compact_skill
    and "the tool budget is zero until a new user message" in compact_skill
    and "never make a corrective second call in the same assistant turn"
    in compact_skill
    and "Count shell executables, not Bash tool boxes" in compact_skill
    and "Satisfying a user-set condition in your own reply is never same-turn permission"
    in compact_skill,
    "Build folder creation can again bundle verification or retry after denial",
  )
  require(
    "## One-action Build setup" in basic_use
    and 'exactly one Bash request: `mkdir -- "<approved absolute path>"`'
    in basic_use
    and "A successful `mkdir` exit is sufficient evidence for this step"
    in basic_use
    and "make no second tool call until a new user message arrives" in basic_use
    and "exactly: `git init`. It takes no arguments and must run in the approved destination"
    in compact_basic_use
    and "For the ordinary Git-backed Build/Learn route" in compact_basic_use
    and "Within this ordinary Git-backed route, successful repository initialization is a hard gate"
    in compact_basic_use
    and "before it, do not preview or write file content" in compact_basic_use
    and "On failure or denial, report that result and stop" in compact_basic_use,
    "the recency-loaded Build reference can again bundle or retry folder creation",
  )
  require(
    "only after a fresh user turn explicitly approves repository initialization"
    in compact_basic_use
    and "“What's next?”, an acknowledgment, and a pacing or scope correction are not approval"
    in compact_basic_use
    and "Ask separately for fresh approval to create the exact named file"
    in compact_basic_use,
    "the basic-use reference can again treat generic replies as mutation consent",
  )
  require(
    "Only output the user actually reports is evidence" in compact_basic_use
    and "Never print, format, infer, or summarize a command result as though you observed it"
    in compact_basic_use
    and "Finished,” “ready,” or “it worked” is not the result" in compact_basic_use
    and "fresh Git version, physical path, and repository state" in compact_basic_use
    and "Active-session metadata is not a substitute" in compact_basic_use
    and "repository-local Git identity is checked only after the repository exists and before its first commit"
    in compact_basic_use
    and "Leave safe-start as not installed or unverified" in compact_basic_use,
    "manual verification can again invent or relabel unobserved output",
  )
  require(
    "Ask for a check without quoting, paraphrasing, or explaining any possible output"
    in compact_basic_use
    and "A pathname alone never proves" in compact_basic_use
    and "Never call or imitate `Write`" in compact_basic_use
    and "create hidden Claude memory" in compact_basic_use
    and "stop without proposing folder creation, Git initialization, or a build"
    in compact_basic_use
    and "hidden agent memory, or a simulated tool invocation" in compact_skill,
    "conversational-only setup can again preview output, infer path safety, or write memory",
  )
  require(
    "The slammed-skeptic fast path is the narrow exception" in compact_basic_use
    and "honor an explicit refusal of Git" in compact_basic_use
    and "freshly approves one exact named payoff file" in compact_basic_use
    and "create only that file without arguing for or running `git init`"
    in compact_basic_use,
    "the basic-use reference can again block the rushed payoff on Git",
  )
  require(
    "git diff --cached --check -- <path>" in basic_use
    and "git diff --cached -- <path>" in basic_use
    and "Never try a broad `git diff --cached` or broad `git diff --cached --check` first"
    in compact_basic_use
    and 'git commit -m "<message>"' in basic_use
    and "do not add a second `-m`, a trailer, or a `Co-Authored-By` line"
    in compact_basic_use
    and "each savepoint action waits for a fresh user turn" in compact_basic_use
    and "status, named stage, each per-path check, each per-path review, identity read or configuration, commit, and final verification"
    in compact_basic_use
    and "Never batch a stage with its check or review" in compact_basic_use,
    "the basic-use reference lost named cached review, one-message commits, or one-action sequencing",
  )
  require(
    "Folder creation, session relocation, and working-folder verification are separate turns"
    in compact_build
    and 'run only `mkdir -- "<approved absolute path>"`' in compact_build
    and "use `/cd <path>`" in compact_build
    and "run only `pwd -P`" in compact_build
    and "Never use shell `cd` as persistent relocation" in compact_build
    and "append `cd`, `pwd`, `ls`, `stat`, or another verification to `mkdir`"
    in compact_build,
    "Build setup can again bundle folder creation, relocation, and verification",
  )
  require(
    "submit exact argument-free `git init` as the entire Bash input" in compact_build
    and "Only a successful exit permits any file-content preview or write" in compact_build
    and "On failure or denial, report that result and stop—never preview or write file content"
    in compact_build
    and "For the ordinary Git-backed Build/Learn route" in compact_build
    and "Ordinary Git-backed Build and Learn require successful repository initialization before any preview or write"
    in compact_skill
    and "the slammed-skeptic fast path below is the narrow exception"
    in compact_skill,
    "ordinary Build can preview or write before repository initialization, or the fast exception disappeared",
  )
  require(
    "Generic replies such as “okay,” “what's next?”, a scope clarification, or a pacing/style correction are never action approval"
    in compact_skill
    and "Agreement that a location “works” selects only the path and never approves folder creation"
    in compact_skill
    and "only a fresh later user answer can approve it" in compact_skill
    and "approval is one-shot" in compact_skill
    and "ask only whether you may run exact `git init` in that exact path" in compact_build
    and "ask separately for approval to create the agreed named file" in compact_build,
    "Build mutations can again reuse generic or stale consent",
  )
  require(
    "absolute physical form of `$HOME/Projects/<simple-project-name>`" in compact_build
    and "not Desktop, Documents, Downloads, the home root, or a literal `$HOME` alias"
    in compact_build
    and "Before every first-time Build location choice, state the exact starting cwd"
    in compact_build
    and "using only verified path facts" in compact_build,
    "cloud-synced Build handoff no longer proposes the durable Projects path",
  )
  require(
    "do not substitute source inspection, `grep`, inline Node, or reimplemented logic"
    in compact_build
    and '`open -a Safari "<absolute-file>"`' in compact_build
    and "wait for their observed Safari report" in compact_build,
    "HTML Build can again substitute source review for functional browser evidence",
  )
  require(
    "never\nincludes deliberate deletion or restoration by default" in build,
    "Build no longer excludes automatic deletion and recovery",
  )
  require(
    "completion\nof one route is not permission to begin another" in build,
    "Build no longer requires a new route choice",
  )
  require(
    "The path-check result turn reports only" in build
    and "its result turn reports only" in build,
    "Build setup results can again queue the next action",
  )
  require(
    "A write result reports\nonly" in build and "each result reports only" in build,
    "Build write or test results can again queue the next action",
  )
  require(
    "The final test-result\nturn never offers another route" in build,
    "Build test result can again append a route menu",
  )

  fast = section(skill, "## The fast build path", "## The safety lesson arc")
  require(
    "Offer deletion-and-recovery only as a separate **Learn** choice" in fast,
    "fast Build silently regained a mandatory recovery drill",
  )
  compact_fast = " ".join(fast.split())
  require(
    "create only the exact approved durable folder" in compact_fast
    and "user use `/cd <path>`" in compact_fast
    and "run only `pwd -P` after they confirm relocation" in compact_fast
    and "Do not ask for or run `git init` before the payoff" in compact_fast,
    "rushed payoff no longer requires verified durable relocation before writing",
  )
  require(
    "explicitly declines Git and freshly approves one exact named payoff file"
    in compact_fast
    and "write that approved file now before Git" in compact_fast
    and "Do not argue, defend `git init`, re-ask for Git, or withhold the payoff"
    in compact_fast,
    "rushed path can again argue or block after exact payoff approval",
  )
  require(
    'open -a Safari "<absolute-file>"' in fast
    and "that user-supplied nominal input and one obvious synthetic boundary case"
    in compact_fast
    and "Test-input gate" in fast
    and "when no nominal synthetic example has been supplied, ask only for the smallest made-up example needed to test and stop"
    in compact_fast
    and "Do not give a Safari command or invent or substitute any nominal value until the user supplies it"
    in compact_fast
    and "wait for the user's observed Safari report" in compact_fast
    and "On the user's next turn offer neutral choices" in compact_fast
    and "Do not favor Git" in compact_fast,
    "rushed payoff lost its Safari evidence gate or neutral return choice",
  )
  require(
    "Save only after a separate Git choice" in compact_fast
    and "when a five-minute user chooses Git or recovery, say once before its first action that reviewed saving or recovery may take longer than five minutes if setup or approvals require it"
    in compact_fast
    and "ask for fresh approval to run exact argument-free `git init`"
    in compact_fast
    and "The earlier Build choice, file approval, write, or Safari report authorizes no Git action"
    in compact_fast,
    "rushed path can again initialize or save without a separate Git choice",
  )
  require(
    "Only then may you delete" not in fast,
    "fast Build still authorizes deletion without a separate choice",
  )

  require(
    "For every Git savepoint, stage only named paths" in compact_skill
    and "git diff --cached --check -- <path>" in skill
    and "git diff --cached -- <path>" in skill
    and "Never run either cached diff broadly" in compact_skill
    and 'git commit -m "<approved message>"' in skill
    and "never add a second `-m`, trailer, `Co-Authored-By`, or other metadata"
    in compact_skill,
    "universal Git savepoint review can again become broad or multi-message",
  )
  require(
    "status, named stage, each per-path check, each per-path review, identity reads or configuration, commit, and verification each wait for a fresh user turn"
    in compact_skill
    and "Never batch stage with review" in compact_skill,
    "one-action users can again receive a batched Git savepoint turn",
  )

  require(
    "**Every return has an inspection gate after the session choice.**" in skill,
    "return inspection gate is missing",
  )
  require(
    "Use `/resume` to reopen the earlier\nsession, or say ‘continue here.’" in skill,
    "fresh-session resume offer conflicts with the inspection gate",
  )
  require(
    "Do NOT replay onboarding for users who already completed it" in skill
    and "never search broadly, replay the greeting" in compact_skill
    and "accept that and do not replay it" in compact_sessions,
    "pause or fresh-session return can again replay onboarding",
  )
  require(
    "Paused. `/rename` names this session; `/resume` returns to it later."
    in compact_skill
    and "Paused. `/rename` names this session; `/resume` returns to it later."
    in compact_sessions
    and "Show the current tool's verified rename command; do not make naming a gate"
    in compact_skill,
    "session rename/resume guidance is missing or can become a lesson gate",
  )
  for phrase in ("got as far as", "break half", "still need to", "next step"):
    require(
      phrase in skill,
      f"return narration prohibition is missing: {phrase}",
    )

  require("run nothing by default" in skill, "ordinary pause may run a command")
  require(
    "Without explicit inspection permission, output only three lines" in skill,
    "no-inspection pause response is no longer closed-form",
  )
  require(
    "The pause inspector result has no intro, heading, or question: only the exact four" in skill,
    "inspected pause can again append a fallback or another action",
  )
  require(
    "Never infer that nothing was started" in skill,
    "pause can again invent an empty lesson history",
  )
  require(
    "scripts/restore_recovery.py" in skill,
    "Learn restore no longer invokes the bundled guarded helper",
  )
  require(
    "Reviewed helper base directory for\nclinician-first-cli-session" in skill
    and "Never derive it from the staged `.claude/skills` directory" in compact_skill
    and "Treat the matching helper as already reviewed and externally bound"
    in compact_skill
    and "never Read, cat, hash, copy, or otherwise inspect its source during the lesson"
    in compact_skill
    and "If no reviewed helper base\nor matching helper is available, stop"
    in skill,
    "restore can again resolve a staged, copied, or unreviewed helper path",
  )
  require(
    "Reviewed helper base directory for\n   clinician-first-cli-session" in sessions
    and "never substitute the staged `.claude/skills` directory" in compact_sessions
    and "never Read, cat, hash, copy, or otherwise inspect its source during the lesson"
    in compact_sessions,
    "session inspection can again resolve the helper from the staged skill shell",
  )
  require(
    "output exactly three bullet lines labeled **Restored**, **Before**, and\n**After**"
    in skill,
    "restore-result turn can continue the lesson or ask another question",
  )
  require(
    "Never issue `git restore` directly" in sessions,
    "session recovery regained a direct restore shortcut",
  )
  require(
    "Use the neutral menu; do not ask a chronology question" in sessions,
    "clean return state can again trigger a chronology question",
  )
  require(
    "Only when `simple_unstaged_deletion` is true may you use the exact restore"
    in sessions
    and "A tracked deletion whose version exists in `HEAD` is recoverable" not in sessions,
    "return guidance can over-offer restore when other changes exist",
  )
  require(
    "starts immediately with exactly four\nbullet lines and no intro, heading, or question"
    in sessions,
    "inspector state card no longer has an exact shared render contract",
  )
  require(
    "The restore transaction above applies during the lesson" in sessions,
    "session reference no longer makes guarded restore universal",
  )
  require(
    "Current state: unknown; I have not rechecked it." in sessions,
    "hard-pause unknown-state wording is missing",
  )

  require("`/private/tmp`" in skill, "temporary-folder prohibition is missing")
  require("here's your seatbelt" not in skill.lower(), "mandatory analogy returned")
  require(
    "default to at most four lines" in permissions,
    "permissions overview no longer has a compact default",
  )
  require("not `/auto`" in permissions, "Auto mode is mislabeled as a slash command")
  compact_permissions = " ".join(permissions.split())
  require(
    "Keep **Manual** (`default`) visible" in compact_permissions
    and "review aid, not a sandbox or security boundary" in compact_permissions
    and "Auto mode changes how often Claude asks" in compact_permissions
    and "`Ctrl+C` cancels the current operation" in compact_permissions,
    "four-line first-session permissions brief drifted",
  )
  require(
    "Agreement that a folder location works approves path selection only"
    in compact_basic_use
    and "Before its first commit, check and confirm the user's chosen repository-local"
    in compact_basic_use,
    "location consent or future repository-local identity timing drifted",
  )

  print("lesson behavioral contract tests passed")
  return 0


if __name__ == "__main__":
  raise SystemExit(main())
