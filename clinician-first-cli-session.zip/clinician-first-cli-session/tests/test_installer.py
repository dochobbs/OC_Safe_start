#!/usr/bin/env python3
"""Lifecycle tests for the clinician-first CLI lesson installer."""

from __future__ import annotations

import hashlib
import os
from pathlib import Path
import subprocess
import tempfile


ROOT = Path(__file__).resolve().parents[3]
SKILL = ROOT / "skills" / "clinician-first-cli-session"
INSTALLER = SKILL / "install.sh"
UNINSTALLER = SKILL / "uninstall.sh"
ARCHIVE = ROOT / "dist" / "clinician-first-cli-session.zip"
PACKAGE = "clinician-first-cli-session"


def checksums(directory: Path, archive: Path = ARCHIVE, *, digest: str | None = None) -> Path:
  directory.mkdir(parents=True, exist_ok=True)
  target = directory / "SHA256SUMS"
  value = digest or hashlib.sha256(archive.read_bytes()).hexdigest()
  target.write_text(f"{value}  {archive.name}\n", encoding="utf-8")
  return target


def install(home: Path, checksum_file: Path, archive: Path = ARCHIVE) -> subprocess.CompletedProcess[str]:
  env = os.environ.copy()
  env.update({
    "HOME": str(home),
    "LESSON_ARCHIVE": str(archive),
    "LESSON_CHECKSUMS": str(checksum_file),
  })
  return subprocess.run(
    ["bash", str(INSTALLER)],
    env=env,
    text=True,
    stdout=subprocess.PIPE,
    stderr=subprocess.STDOUT,
    check=False,
  )


def uninstall(home: Path, script: Path = UNINSTALLER) -> subprocess.CompletedProcess[str]:
  env = os.environ.copy()
  env["HOME"] = str(home)
  return subprocess.run(
    ["bash", str(script)],
    env=env,
    text=True,
    stdout=subprocess.PIPE,
    stderr=subprocess.STDOUT,
    check=False,
  )


def require(condition: bool, message: str) -> None:
  if not condition:
    raise AssertionError(message)


def main() -> int:
  require(ARCHIVE.is_file(), "build dist archive before running installer tests")
  with tempfile.TemporaryDirectory(prefix="lesson-installer-test-") as temporary:
    root = Path(temporary)
    checksum_file = checksums(root)

    fresh_home = root / "fresh-home"
    fresh_home.mkdir()
    result = install(fresh_home, checksum_file)
    dest = fresh_home / ".claude" / "skills" / PACKAGE
    require(result.returncode == 0, result.stdout)
    require((dest / "SKILL.md").is_file(), "fresh install omitted SKILL.md")
    expected_references = {
      "basic-use-and-safety.md",
      "git-and-github-framework.md",
      "models-and-speed.md",
      "permissions-and-autonomy.md",
      "sessions-and-context.md",
      "teaching-aids.md",
    }
    installed_references = {
      path.name for path in (dest / "references").glob("*.md")
    }
    require(
      installed_references == expected_references,
      "reference set mismatch: expected %s, got %s"
      % (sorted(expected_references), sorted(installed_references)),
    )
    require(not (fresh_home / ".claude" / "settings.json").exists(), "installer changed settings")

    marker = dest / "old-marker"
    marker.write_text("old\n", encoding="utf-8")
    result = install(fresh_home, checksum_file)
    require(result.returncode == 0, result.stdout)
    require(not marker.exists(), "reinstall did not replace old package")

    preserved = dest / "preserve-me"
    preserved.write_text("prior\n", encoding="utf-8")
    bad_checksums = checksums(root / "bad", digest="0" * 64)
    result = install(fresh_home, bad_checksums)
    require(result.returncode != 0, "checksum mismatch unexpectedly installed")
    require(preserved.read_text(encoding="utf-8") == "prior\n", "failed install changed prior package")

    blocked_home = root / "blocked-home"
    blocked_dest = blocked_home / ".claude" / "skills" / PACKAGE
    blocked_dest.parent.mkdir(parents=True)
    blocked_dest.write_text("not owned\n", encoding="utf-8")
    result = install(blocked_home, checksum_file)
    require(result.returncode != 0, "non-directory destination was replaced")
    require(blocked_dest.read_text(encoding="utf-8") == "not owned\n", "blocked destination changed")

    symlink_home = root / "symlink-home"
    symlink_home.mkdir()
    symlink_dest = symlink_home / ".claude" / "skills" / PACKAGE
    symlink_dest.parent.mkdir(parents=True)
    symlink_target = root / "symlink-target"
    symlink_target.mkdir()
    symlink_marker = symlink_target / "keep"
    symlink_marker.write_text("keep\n", encoding="utf-8")
    symlink_dest.symlink_to(symlink_target, target_is_directory=True)
    result = uninstall(symlink_home)
    require(result.returncode != 0, "uninstaller accepted a symlink destination")
    require(
      "not an owned lesson directory; refusing to remove it" in result.stdout,
      "symlink refusal did not use the owned-directory guard",
    )
    require(symlink_dest.is_symlink(), "uninstaller removed a symlink destination")
    require(
      symlink_marker.read_text(encoding="utf-8") == "keep\n",
      "uninstaller changed the symlink target",
    )

    malformed_home = root / "malformed-home"
    malformed_home.mkdir()
    malformed_dest = malformed_home / ".claude" / "skills" / PACKAGE
    malformed_dest.mkdir(parents=True)
    malformed_marker = malformed_dest / "keep"
    malformed_marker.write_text("keep\n", encoding="utf-8")
    result = uninstall(malformed_home)
    require(result.returncode != 0, "uninstaller accepted a non-owned lesson directory")
    require(
      "does not look like the installed lesson; refusing to remove it" in result.stdout,
      "non-owned-directory refusal did not use the package-shape guard",
    )
    require(malformed_dest.is_dir(), "uninstaller removed a non-owned lesson directory")
    require(
      malformed_marker.read_text(encoding="utf-8") == "keep\n",
      "uninstaller changed a non-owned lesson directory",
    )

    other_skill = fresh_home / ".claude" / "skills" / "other-skill"
    other_skill.mkdir()
    (other_skill / "keep").write_text("keep\n", encoding="utf-8")
    settings = fresh_home / ".claude" / "settings.json"
    settings.write_text('{"keep": true}\n', encoding="utf-8")
    installed_uninstaller = dest / "uninstall.sh"
    result = uninstall(fresh_home, installed_uninstaller)
    require(result.returncode == 0, result.stdout)
    require(not dest.exists(), "uninstall left lesson directory")
    require((other_skill / "keep").read_text(encoding="utf-8") == "keep\n", "uninstall changed another skill")
    require(settings.read_text(encoding="utf-8") == '{"keep": true}\n', "uninstall changed settings")
    result = uninstall(fresh_home)
    require(result.returncode == 0, "repeated uninstall was not idempotent")

  print("lesson installer lifecycle tests passed")
  return 0


if __name__ == "__main__":
  raise SystemExit(main())
