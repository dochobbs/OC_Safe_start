#!/usr/bin/env python3
"""Lifecycle tests for the clinician-first CLI lesson installer."""

from __future__ import annotations

import hashlib
import os
from pathlib import Path
import subprocess
import tempfile


ROOT = Path(__file__).resolve().parents[3]
SKILL = ROOT / "skills" / "clinician-first-cli-session"
INSTALLER = SKILL / "install.sh"
ARCHIVE = ROOT / "dist" / "clinician-first-cli-session.zip"
PACKAGE = "clinician-first-cli-session"


def checksums(directory: Path, archive: Path = ARCHIVE, *, digest: str | None = None) -> Path:
  directory.mkdir(parents=True, exist_ok=True)
  target = directory / "SHA256SUMS"
  value = digest or hashlib.sha256(archive.read_bytes()).hexdigest()
  target.write_text(f"{value}  {archive.name}\n", encoding="utf-8")
  return target


def install(home: Path, checksum_file: Path, archive: Path = ARCHIVE) -> subprocess.CompletedProcess[str]:
  env = os.environ.copy()
  env.update({
    "HOME": str(home),
    "LESSON_ARCHIVE": str(archive),
    "LESSON_CHECKSUMS": str(checksum_file),
  })
  return subprocess.run(
    ["bash", str(INSTALLER)],
    env=env,
    text=True,
    stdout=subprocess.PIPE,
    stderr=subprocess.STDOUT,
    check=False,
  )


def require(condition: bool, message: str) -> None:
  if not condition:
    raise AssertionError(message)


def main() -> int:
  require(ARCHIVE.is_file(), "build dist archive before running installer tests")
  with tempfile.TemporaryDirectory(prefix="lesson-installer-test-") as temporary:
    root = Path(temporary)
    checksum_file = checksums(root)

    fresh_home = root / "fresh-home"
    fresh_home.mkdir()
    result = install(fresh_home, checksum_file)
    dest = fresh_home / ".claude" / "skills" / PACKAGE
    require(result.returncode == 0, result.stdout)
    require((dest / "SKILL.md").is_file(), "fresh install omitted SKILL.md")
    require(len(list((dest / "references").glob("*.md"))) == 5, "references missing")
    require(not (fresh_home / ".claude" / "settings.json").exists(), "installer changed settings")

    marker = dest / "old-marker"
    marker.write_text("old\n", encoding="utf-8")
    result = install(fresh_home, checksum_file)
    require(result.returncode == 0, result.stdout)
    require(not marker.exists(), "reinstall did not replace old package")

    preserved = dest / "preserve-me"
    preserved.write_text("prior\n", encoding="utf-8")
    bad_checksums = checksums(root / "bad", digest="0" * 64)
    result = install(fresh_home, bad_checksums)
    require(result.returncode != 0, "checksum mismatch unexpectedly installed")
    require(preserved.read_text(encoding="utf-8") == "prior\n", "failed install changed prior package")

    blocked_home = root / "blocked-home"
    blocked_dest = blocked_home / ".claude" / "skills" / PACKAGE
    blocked_dest.parent.mkdir(parents=True)
    blocked_dest.write_text("not owned\n", encoding="utf-8")
    result = install(blocked_home, checksum_file)
    require(result.returncode != 0, "non-directory destination was replaced")
    require(blocked_dest.read_text(encoding="utf-8") == "not owned\n", "blocked destination changed")

  print("lesson installer lifecycle tests passed")
  return 0


if __name__ == "__main__":
  raise SystemExit(main())
