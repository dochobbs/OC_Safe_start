#!/usr/bin/env python3
"""Tests for read-only lesson recovery inspection."""

from __future__ import annotations

import json
from pathlib import Path
import subprocess
import tempfile


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "inspect_recovery.py"


def run(path: Path, practice_file: str = "hello.txt") -> tuple[int, dict[str, object]]:
  result = subprocess.run(
    ["python3", str(SCRIPT), "--path", str(path), "--file", practice_file],
    text=True,
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
    check=False,
  )
  return result.returncode, json.loads(result.stdout)


def command(path: Path, *args: str) -> None:
  subprocess.run(args, cwd=path, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)


def require(condition: bool, message: str) -> None:
  if not condition:
    raise AssertionError(message)


def main() -> int:
  with tempfile.TemporaryDirectory(prefix="lesson-recovery-test-") as temporary:
    root = Path(temporary)
    code, state = run(root)
    require(code == 0 and state["git_repository"] is False, "non-repo misidentified")

    command(root, "git", "init", "-q")
    command(root, "git", "config", "user.name", "Lesson Test")
    command(root, "git", "config", "user.email", "lesson@example.invalid")
    practice = root / "hello.txt"
    practice.write_text("hello\n", encoding="utf-8")
    command(root, "git", "config", "status.showUntrackedFiles", "no")
    code, state = run(root)
    require(code == 0 and state["untracked_count"] == 1, "untracked state missed")
    require(state["practice_file"]["present_in_head"] is False, "untracked file claimed saved")
    require(state["practice_file"]["status"] == "?? hello.txt", "per-file untracked state missed")

    command(root, "git", "add", "hello.txt")
    command(root, "git", "commit", "-qm", "our first savepoint")
    code, state = run(root)
    require(state["clean"] is True and state["head"] is not None, "clean commit missed")
    require(state["practice_file"]["present_in_head"] is True, "committed file missed")

    practice.unlink()
    code, state = run(root)
    require(state["clean"] is False, "tracked deletion called clean")
    require(state["practice_file"]["present"] is False, "deleted file called present")
    require(state["practice_file"]["present_in_head"] is True, "recoverable file missed")
    require(state["practice_file"]["simple_unstaged_deletion"] is True, "simple deletion missed")

    command(root, "git", "restore", "hello.txt")
    code, state = run(root)
    require(state["clean"] is True and state["practice_file"]["present"] is True, "restore missed")

    unrelated = root / "unrelated.txt"
    unrelated.write_text("leave me alone\n", encoding="utf-8")
    practice.unlink()
    code, state = run(root)
    require(state["pending_change_count"] == 2, "unrelated change missed")
    require(state["practice_file"]["simple_unstaged_deletion"] is False, "mixed state called simple")
    unrelated.unlink()
    command(root, "git", "restore", "hello.txt")

    practice.unlink()
    command(root, "git", "add", "hello.txt")
    code, state = run(root)
    require(state["staged_change_count"] == 1, "staged deletion missed")
    require(state["practice_file"]["simple_unstaged_deletion"] is False, "staged deletion called simple")
    command(root, "git", "restore", "--staged", "hello.txt")
    command(root, "git", "restore", "hello.txt")

    renamed = root / "renamed.txt"
    command(root, "git", "mv", "hello.txt", "renamed.txt")
    code, state = run(root)
    require(state["practice_file"]["simple_unstaged_deletion"] is False, "rename called simple")
    command(root, "git", "restore", "--staged", "hello.txt")
    command(root, "git", "restore", "hello.txt")
    renamed.unlink()

    code, state = run(root, "../outside")
    require(code == 2 and state["error"] == "unsafe_file_path", "unsafe file path accepted")

    nested = root / "nested"
    nested.mkdir()
    code, state = run(nested)
    require(code == 3 and state["error"] == "path_is_inside_parent_repository", "parent repo accepted")

    broken = root / "broken"
    broken.mkdir()
    (broken / ".git").write_text("gitdir: /definitely/missing/lesson-git-dir\n", encoding="utf-8")
    code, state = run(broken)
    require(code == 3 and state["error"] == "git_repository_check_failed", "broken Git metadata called non-repo")

    index = root / ".git" / "index"
    original_index = index.read_bytes()
    index.write_bytes(b"corrupt index\n")
    code, state = run(root)
    require(code == 3 and state["error"] == "git_status_failed", "Git failure called safe")
    index.write_bytes(original_index)

    practice.unlink()
    command(root, "git", "add", "hello.txt")
    command(root, "git", "commit", "-qm", "remove practice file")
    code, state = run(root)
    require(state["practice_file"]["present_in_head"] is False, "deleted HEAD claimed file")
    require(state["practice_file"]["latest_commit_with_file"] is not None, "earlier saved copy missed")
    require(state["practice_file"]["simple_unstaged_deletion"] is False, "committed deletion called simple")

  with tempfile.TemporaryDirectory(prefix="lesson-recovery-conflict-") as temporary:
    root = Path(temporary)
    command(root, "git", "init", "-q")
    command(root, "git", "config", "user.name", "Lesson Test")
    command(root, "git", "config", "user.email", "lesson@example.invalid")
    command(root, "git", "checkout", "-qb", "lesson-main")
    practice = root / "hello.txt"
    practice.write_text("base\n", encoding="utf-8")
    command(root, "git", "add", "hello.txt")
    command(root, "git", "commit", "-qm", "base")
    command(root, "git", "checkout", "-qb", "lesson-other")
    practice.write_text("other\n", encoding="utf-8")
    command(root, "git", "commit", "-qam", "other")
    command(root, "git", "checkout", "-q", "lesson-main")
    practice.write_text("main\n", encoding="utf-8")
    command(root, "git", "commit", "-qam", "main")
    merge = subprocess.run(
      ["git", "merge", "lesson-other"],
      cwd=root,
      text=True,
      stdout=subprocess.PIPE,
      stderr=subprocess.PIPE,
      check=False,
    )
    require(merge.returncode != 0, "conflict fixture did not conflict")
    code, state = run(root)
    require(code == 0 and state["practice_file"]["status"] == "UU hello.txt", "conflict missed")
    require(state["practice_file"]["simple_unstaged_deletion"] is False, "conflict called simple")

  print("lesson recovery inspection tests passed")
  return 0


if __name__ == "__main__":
  raise SystemExit(main())
