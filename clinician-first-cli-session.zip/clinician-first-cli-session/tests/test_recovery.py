#!/usr/bin/env python3
"""Tests for read-only lesson recovery inspection."""

from __future__ import annotations

import json
from pathlib import Path
import subprocess
import tempfile


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "inspect_recovery.py"
RESTORE_SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "restore_recovery.py"


def run(path: Path, practice_file: str = "hello.txt") -> tuple[int, dict[str, object]]:
  result = subprocess.run(
    ["python3", str(SCRIPT), "--path", str(path), "--file", practice_file],
    text=True,
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
    check=False,
  )
  return result.returncode, json.loads(result.stdout)


def restore(
  path: str | Path,
  practice_file: str,
  expected_root: str,
  expected_head: str,
) -> tuple[int, dict[str, object]]:
  result = subprocess.run(
    [
      "python3",
      str(RESTORE_SCRIPT),
      "--path",
      str(path),
      "--file",
      practice_file,
      "--expected-root",
      expected_root,
      "--expected-head",
      expected_head,
    ],
    text=True,
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
    check=False,
  )
  return result.returncode, json.loads(result.stdout)


def recovery_binding(state: dict[str, object]) -> tuple[str, str, str]:
  head = state["head"]
  practice_file = state["practice_file"]
  require(isinstance(head, dict), "inspection omitted HEAD")
  require(isinstance(practice_file, dict), "inspection omitted practice file")
  return str(state["git_root"]), str(head["sha"]), str(practice_file["path"])


def command(path: Path, *args: str) -> None:
  subprocess.run(args, cwd=path, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)


def require(condition: bool, message: str) -> None:
  if not condition:
    raise AssertionError(message)


def main() -> int:
  invalid = subprocess.run(
    ["python3", str(RESTORE_SCRIPT)],
    text=True,
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
    check=False,
  )
  invalid_payload = json.loads(invalid.stdout)
  require(
    invalid.returncode == 2
    and invalid_payload["restored"] is False
    and invalid_payload["error"] == "invalid_arguments",
    "invalid helper invocation did not fail as JSON",
  )

  with tempfile.TemporaryDirectory(prefix="lesson-recovery-test-") as temporary:
    root = Path(temporary)
    code, state = run(root)
    require(code == 0 and state["git_repository"] is False, "non-repo misidentified")

    command(root, "git", "init", "-q")
    command(root, "git", "config", "user.name", "Lesson Test")
    command(root, "git", "config", "user.email", "lesson@example.invalid")
    practice = root / "hello.txt"
    practice.write_text("hello\n", encoding="utf-8")
    command(root, "git", "config", "status.showUntrackedFiles", "no")
    code, state = run(root)
    require(code == 0 and state["untracked_count"] == 1, "untracked state missed")
    require(state["practice_file"]["present_in_head"] is False, "untracked file claimed saved")
    require(state["practice_file"]["status"] == "?? hello.txt", "per-file untracked state missed")

    command(root, "git", "add", "hello.txt")
    command(root, "git", "commit", "-qm", "our first savepoint")
    code, state = run(root)
    require(state["clean"] is True and state["head"] is not None, "clean commit missed")
    require(state["practice_file"]["present_in_head"] is True, "committed file missed")

    practice.unlink()
    code, state = run(root)
    require(state["clean"] is False, "tracked deletion called clean")
    require(state["practice_file"]["present"] is False, "deleted file called present")
    require(state["practice_file"]["present_in_head"] is True, "recoverable file missed")
    require(state["practice_file"]["status"] == " D hello.txt", "deletion status lost its index column")
    require(state["practice_file"]["simple_unstaged_deletion"] is True, "simple deletion missed")

    expected_root, expected_head, expected_file = recovery_binding(state)
    index_before = (root / ".git" / "index").read_bytes()
    restore_code, recovery = restore(
      state["path"], expected_file, expected_root, expected_head
    )
    require(
      restore_code == 0 and recovery["restored"] is True,
      "guarded restore failed: %s" % recovery,
    )
    require(
      set(recovery) == {
        "action", "restored", "path", "file", "expected", "before", "after", "command",
      },
      "success JSON contract changed",
    )
    require(recovery["before"]["practice_file"]["simple_unstaged_deletion"] is True, "pre-state missing")
    require(recovery["after"]["clean"] is True, "post-state was not inspected clean")
    require(recovery["after"]["practice_file"]["present"] is True, "post-state missed file")
    require(recovery["command"] == {
      "source": expected_head,
      "worktree_only": True,
    }, "restore did not report exact worktree-only source")
    require((root / ".git" / "index").read_bytes() == index_before, "guarded restore changed index")
    require(practice.read_text(encoding="utf-8") == "hello\n", "wrong file content restored")
    code, state = run(root)
    require(state["clean"] is True and state["practice_file"]["present"] is True, "restore missed")

    practice.unlink()
    code, state = run(root)
    expected_root, expected_head, expected_file = recovery_binding(state)
    restore_code, recovery = restore(
      state["path"], expected_file, expected_root, "0" * len(expected_head)
    )
    require(restore_code != 0 and recovery["restored"] is False, "wrong HEAD restored file")
    require(not practice.exists(), "HEAD mismatch changed worktree")

    restore_code, recovery = restore(
      state["path"], expected_file, expected_root, expected_head[:12]
    )
    require(
      restore_code != 0 and recovery["error"] == "expected_head_must_be_full_sha",
      "abbreviated HEAD accepted",
    )
    require(not practice.exists(), "abbreviated-HEAD refusal changed worktree")

    with tempfile.TemporaryDirectory(prefix="lesson-wrong-root-") as wrong_root:
      restore_code, recovery = restore(
        state["path"], expected_file, str(Path(wrong_root).resolve()), expected_head
      )
    require(restore_code != 0 and recovery["error"] == "path_root_mismatch", "wrong root accepted")
    require(not practice.exists(), "root mismatch changed worktree")

    restore_code, recovery = restore(
      state["path"], "different.txt", expected_root, expected_head
    )
    require(restore_code != 0 and recovery["restored"] is False, "wrong file binding accepted")
    require(not practice.exists(), "file mismatch changed worktree")

    checkpoint = root / "checkpoint.txt"
    checkpoint.write_text("new HEAD\n", encoding="utf-8")
    command(root, "git", "add", "checkpoint.txt")
    command(root, "git", "commit", "-qm", "advance head")
    restore_code, recovery = restore(
      state["path"], expected_file, expected_root, expected_head
    )
    require(restore_code != 0 and recovery["restored"] is False, "stale inspection restored file")
    require(not practice.exists(), "stale HEAD changed worktree")
    code, state = run(root)
    expected_root, expected_head, expected_file = recovery_binding(state)
    restore_code, recovery = restore(
      state["path"], expected_file, expected_root, expected_head
    )
    require(restore_code == 0 and recovery["restored"] is True, "fresh binding did not restore")

    unrelated = root / "unrelated.txt"
    unrelated.write_text("leave me alone\n", encoding="utf-8")
    practice.unlink()
    code, state = run(root)
    require(state["pending_change_count"] == 2, "unrelated change missed")
    require(state["practice_file"]["simple_unstaged_deletion"] is False, "mixed state called simple")
    expected_root, expected_head, expected_file = recovery_binding(state)
    restore_code, recovery = restore(
      state["path"], expected_file, expected_root, expected_head
    )
    require(
      restore_code != 0 and recovery["error"] == "not_sole_unstaged_deletion",
      "mixed state was restored",
    )
    require(not practice.exists(), "mixed-state refusal changed deleted file")
    require(unrelated.read_text(encoding="utf-8") == "leave me alone\n", "mixed-state refusal changed other file")
    unrelated.unlink()
    command(root, "git", "restore", "hello.txt")

    practice.unlink()
    command(root, "git", "add", "hello.txt")
    code, state = run(root)
    require(state["staged_change_count"] == 1, "staged deletion missed")
    require(state["practice_file"]["simple_unstaged_deletion"] is False, "staged deletion called simple")
    expected_root, expected_head, expected_file = recovery_binding(state)
    restore_code, recovery = restore(
      state["path"], expected_file, expected_root, expected_head
    )
    require(restore_code != 0 and recovery["restored"] is False, "staged deletion was restored")
    require(not practice.exists(), "staged-deletion refusal changed worktree")
    command(root, "git", "restore", "--staged", "hello.txt")
    command(root, "git", "restore", "hello.txt")

    renamed = root / "renamed.txt"
    command(root, "git", "mv", "hello.txt", "renamed.txt")
    code, state = run(root)
    require(state["practice_file"]["simple_unstaged_deletion"] is False, "rename called simple")
    command(root, "git", "restore", "--staged", "hello.txt")
    command(root, "git", "restore", "hello.txt")
    renamed.unlink()

    code, state = run(root, "../outside")
    require(code == 2 and state["error"] == "unsafe_file_path", "unsafe file path accepted")

    nested = root / "nested"
    nested.mkdir()
    code, state = run(nested)
    require(code == 3 and state["error"] == "path_is_inside_parent_repository", "parent repo accepted")

    broken = root / "broken"
    broken.mkdir()
    (broken / ".git").write_text("gitdir: /definitely/missing/lesson-git-dir\n", encoding="utf-8")
    code, state = run(broken)
    require(code == 3 and state["error"] == "git_repository_check_failed", "broken Git metadata called non-repo")

    index = root / ".git" / "index"
    original_index = index.read_bytes()
    index.write_bytes(b"corrupt index\n")
    code, state = run(root)
    require(code == 3 and state["error"] == "git_status_failed", "Git failure called safe")
    index.write_bytes(original_index)

    practice.unlink()
    command(root, "git", "add", "hello.txt")
    command(root, "git", "commit", "-qm", "remove practice file")
    code, state = run(root)
    require(state["practice_file"]["present_in_head"] is False, "deleted HEAD claimed file")
    require(state["practice_file"]["latest_commit_with_file"] is not None, "earlier saved copy missed")
    require(state["practice_file"]["simple_unstaged_deletion"] is False, "committed deletion called simple")

  with tempfile.TemporaryDirectory(prefix="lesson-recovery-symlink-") as temporary:
    root = Path(temporary)
    command(root, "git", "init", "-q")
    command(root, "git", "config", "user.name", "Lesson Test")
    command(root, "git", "config", "user.email", "lesson@example.invalid")
    nested = root / "nested"
    nested.mkdir()
    practice = nested / "hello.txt"
    practice.write_text("nested\n", encoding="utf-8")
    command(root, "git", "add", "nested/hello.txt")
    command(root, "git", "commit", "-qm", "nested file")
    practice.unlink()
    code, state = run(root, "nested/hello.txt")
    require(code == 0 and state["practice_file"]["simple_unstaged_deletion"] is True, "nested fixture invalid")
    expected_root, expected_head, expected_file = recovery_binding(state)

    outside = root.parent / (root.name + "-outside")
    outside.mkdir()
    marker = outside / "marker.txt"
    marker.write_text("outside\n", encoding="utf-8")
    nested.rmdir()
    nested.symlink_to(outside, target_is_directory=True)
    restore_code, recovery = restore(
      state["path"], expected_file, expected_root, expected_head
    )
    require(
      restore_code != 0 and recovery["error"] == "unsafe_file_parent_symlink",
      "symlink parent accepted",
    )
    require(marker.read_text(encoding="utf-8") == "outside\n", "symlink refusal changed outside file")
    require(not (outside / "hello.txt").exists(), "restore escaped through symlink")

    nested.unlink()
    nested.mkdir()
    code, state = run(root, "nested/hello.txt")
    expected_root, expected_head, expected_file = recovery_binding(state)
    alias = root.parent / (root.name + "-alias")
    alias.symlink_to(root, target_is_directory=True)
    restore_code, recovery = restore(alias, expected_file, expected_root, expected_head)
    require(
      restore_code != 0 and recovery["error"] == "path_must_be_canonical",
      "symlink repository path accepted",
    )
    require(not practice.exists(), "symlink-path refusal restored file")
    alias.unlink()

    practice.symlink_to(marker)
    restore_code, recovery = restore(
      state["path"], expected_file, expected_root, expected_head
    )
    require(
      restore_code != 0 and recovery["error"] == "unsafe_file_symlink",
      "symlink target accepted",
    )
    require(marker.read_text(encoding="utf-8") == "outside\n", "target symlink changed outside file")
    practice.unlink()

    command(root, "git", "restore", "nested/hello.txt")
    head_link = root / "head-link.txt"
    head_link.symlink_to(marker)
    command(root, "git", "add", "head-link.txt")
    command(root, "git", "commit", "-qm", "tracked symlink")
    head_link.unlink()
    code, state = run(root, "head-link.txt")
    require(code == 0 and state["practice_file"]["simple_unstaged_deletion"] is True, "HEAD symlink fixture invalid")
    expected_root, expected_head, expected_file = recovery_binding(state)
    restore_code, recovery = restore(
      state["path"], expected_file, expected_root, expected_head
    )
    require(
      restore_code != 0 and recovery["error"] == "head_entry_is_not_regular_file",
      "symlink from HEAD was restored",
    )
    require(not head_link.exists(), "HEAD symlink refusal recreated link")
    require(marker.read_text(encoding="utf-8") == "outside\n", "HEAD symlink refusal changed outside file")
    marker.unlink()
    outside.rmdir()

  with tempfile.TemporaryDirectory(prefix="lesson-recovery-conflict-") as temporary:
    root = Path(temporary)
    command(root, "git", "init", "-q")
    command(root, "git", "config", "user.name", "Lesson Test")
    command(root, "git", "config", "user.email", "lesson@example.invalid")
    command(root, "git", "checkout", "-qb", "lesson-main")
    practice = root / "hello.txt"
    practice.write_text("base\n", encoding="utf-8")
    command(root, "git", "add", "hello.txt")
    command(root, "git", "commit", "-qm", "base")
    command(root, "git", "checkout", "-qb", "lesson-other")
    practice.write_text("other\n", encoding="utf-8")
    command(root, "git", "commit", "-qam", "other")
    command(root, "git", "checkout", "-q", "lesson-main")
    practice.write_text("main\n", encoding="utf-8")
    command(root, "git", "commit", "-qam", "main")
    merge = subprocess.run(
      ["git", "merge", "lesson-other"],
      cwd=root,
      text=True,
      stdout=subprocess.PIPE,
      stderr=subprocess.PIPE,
      check=False,
    )
    require(merge.returncode != 0, "conflict fixture did not conflict")
    code, state = run(root)
    require(code == 0 and state["practice_file"]["status"] == "UU hello.txt", "conflict missed")
    require(state["practice_file"]["simple_unstaged_deletion"] is False, "conflict called simple")

  print("lesson recovery inspection tests passed")
  return 0


if __name__ == "__main__":
  raise SystemExit(main())
