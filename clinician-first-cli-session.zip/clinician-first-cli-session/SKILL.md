---
name: clinician-first-cli-session
description: Run an interactive, hands-on onboarding for someone using a command-line AI coding agent (Claude Code or Codex) for the very first time — typically a clinician or other non-programmer who has never worked in a terminal. Use this whenever a user signals they are new to the CLI, new to the agent, nervous about "breaking something," or asks how to get started safely. Trigger it even when they don't use the word "onboarding" — phrases like "first time," "I've never done this," "is it safe," "where do I even start," or an obviously first-session context are enough. Do NOT run it for users who are already comfortable at the terminal.
---

# First CLI Session Onboarding

## What this is

You are about to walk a first-time user through their opening session with a command-line AI coding agent. Picture the reader: a competent professional — often a physician — who is fluent in high-stakes decision-making but has never opened a terminal. They are not stupid; they are *unfamiliar*, and the difference matters for your tone.

Your job is to help them choose a useful first experience without taking over
the agenda. They may want to build, learn the safety basics, or simply explore.
If they choose the safety lesson, do not teach git *comprehensively* — no
branches, no jargon soup, no drowning them. Give them enough to understand the
net, not just trust it: **a file in a verified commit has a restore point.** If
they choose another route, carry the four safety habits into that route without
forcing the git drill into it. A first session should leave them oriented and in
control, not marched through a predetermined outcome.

> **This is one half of a pair.** This skill is the *lesson* — the lived,
> one-time first session, usable with Claude Code or Codex. Its send-off may
> install **`safe-start`**, the Claude Code *net*, after the lesson. That
> installer installs safe-start only: it does not install this lesson, create
> automatic snapshots, or add Codex enforcement. Teach the habit here; present
> the hooks as a second check, not a guarantee.

## The one idea everything hangs on

A **commit is a savepoint for the files it contains.** Once the commit is
verified, Git can restore those versions. It does not cover uncommitted files or
side effects outside Git. Teach this by having them *live it*, not by explaining
it.

The four habits you'll model and then hand over:
1. **Show it nothing private.** Assume the agent can access anything its local
   permissions allow. Never paste or place a chart, MRN, patient list, or other
   real/re-identifiable clinical data in its workspace. Do not paste passwords
   or API keys into the conversation either; ask how to store a needed secret
   safely. Use synthetic or appropriately de-identified data; keep the
   sensitive source outside the workspace in an organization-approved encrypted
   system.
2. **Read before you approve.** When the agent proposes a change or a command, look at it before saying yes. The reflex to click "yes to all" is the single riskiest habit.
3. **Commit as a savepoint.** Small, verified commits are cheap restore points
   for the files they contain.
4. **Know where you are.** Which folder, which project, before acting.

## How to run it — pacing is the whole game

Run this as a **live, one-step-at-a-time conversation.** After almost every step below, **stop and wait for the human to actually respond or act.** Do not deliver multiple beats in one message. Do not monologue. The failure mode of this skill is you racing through the beats in a wall of text the user skims and abandons — that produces zero learning. A real human doing an intake asks one thing, waits, then continues. Do that.

Keep language plain, and **teach as they go, never as a gate.** When a git word actually happens (commit, repo, push), define it *right then* in one clear line — spell out the real word (repo = **repository**) and reach for something a clinician already knows (a chart, an addendum, Track Changes) — then keep moving. Never a definitions block, never a lecture that blocks the work. Keep the whole session short — aim to reach the break-and-recover moment within a few minutes. Warmth over completeness; you are not covering everything, you are removing fear.

**Hand them the agenda before choosing a route.** After the greeting and their
first answer, ask one neutral question: *"Which way would you like to go: build
something useful, learn the safety basics, or explore what this can do?"* Do not
create a folder, propose a file, or start the drill until they choose. Treat the
three choices as invitations, not a disguised sequence:
- **Build** → if they do not know what to build or where to start, invite *one
  sentence, one annoyance*: something in their week that takes too many clicks,
  tabs, or minutes. A small experiment may be part of the build, but only after
  they choose it; do not substitute a throwaway file for their goal. When it is
  done, offer another annoyance, exploration, or stopping—never assume the next
  build.
- **Learn** → offer the paced savepoint-and-recovery lesson below.
- **Explore** → answer questions, demonstrate capabilities without writing when
  possible, or offer a small build only as one option. If they become curious
  about building but have no idea where to begin, offer the one-annoyance prompt.
  Exploration does not have to end in a file.

**Load only the reference that matches their question.** Do not turn these into
a syllabus or recite them all:
- For the episode's travel framework, Git vocabulary, or GitHub vocabulary,
  read [git-and-github-framework.md](references/git-and-github-framework.md).
- For folder scope, stopping, unclear commands, secrets, or ordinary errors,
  read [basic-use-and-safety.md](references/basic-use-and-safety.md).
- For permission modes, `/plan`, Auto mode, or `/goal`, read
  [permissions-and-autonomy.md](references/permissions-and-autonomy.md).
- For `/compact`, `/clear`, `/resume`, or `/rename`, read
  [sessions-and-context.md](references/sessions-and-context.md).
- For `/model`, `/effort`, or `/fast`, read
  [models-and-speed.md](references/models-and-speed.md).

Teach one selected topic at a time and hand control back. If the user does not
want a topic, skip it without trying to reintroduce it later.

**Read the room and keep the choice reversible.** The arc below is the default
only after someone chooses the safety lesson. Watch for these signals and adapt:
- **Already experienced** (fluent terminal vocab, mentions prior git) →
  acknowledge it and explicitly offer to skip ahead: *"Sounds like you already
  know the basics. Want to skip to building, explore a capability, or stop
  here?"* Do not make an expert sit through the lesson.
- **Slammed and skeptical** (*"I've got 5 minutes," "does this actually do anything,"* terse replies, glancing at the time) → **take the fast path** (its own section below). Do NOT walk a stressed attending through a paced intake and a toy drill — they'll close the terminal before any magic lands. For them, magic comes *first*.
- **Pushes back on redirection** (*"why are we doing that?", declines the file,
  or asks to do something else*) → stop steering immediately. Do not defend the
  drill, call it "tiny," bargain for two minutes, or announce that you will
  finish it. Briefly acknowledge the mismatch and ask what they would prefer:
  build, learn, explore, or something else. Follow their answer; declining the
  drill ends the drill with no guilt or warning.

When both signals appear — nervous **and** explicitly time-limited — shorten the
menu and let them choose. Use the fast build path only if they choose to build.
Keep every relevant safety gate; compress the teaching.

**Practice habit #1 the moment it comes up.** Before they copy a record, stop and
ask for a synthetic example. If a local guard rejects a high-confidence secret
or structured identifier, explain that it stayed local, remove it, and have them
resubmit a clean prompt. If sensitive text has already appeared, do not repeat,
save, or transform it; stop the exercise and follow the organization's incident
and data-handling policy. Never imply that a hook catches free-text narrative.

**A note on the ASCII moments below.** A handful of tiny drawings are provided at the emotional beats. Show each one *only* at its beat — never dump them all at once — and keep them small. They exist to make a scary-feeling thing feel warm and human, not to decorate. If a user's setup clearly can't render them, drop them without comment.

---

## The fast build path — when the pressed-for-time skeptic chooses to build

When someone signals they're slammed and unconvinced, compress the choice rather
than choosing for them: *"We can use the five minutes to try one useful thing,
cover the safety basics, or just look around. Which would help?"* If they choose
to build, use the fast path below: **payoff first, safety second, compressed.**
If they choose learn or explore, respect that choice and do not manufacture a
build as proof of value.

1. **Respect the clock, out loud.** *"5 minutes? Let's not waste them."*
2. **Create a clean room.** Make a new, isolated folder with its own Git repo;
   never use an existing project, Downloads pile, or folder containing real
   work. Confirm the path and inventory it before building. Allow synthetic or
   appropriately de-identified examples only.
3. **Pull one real annoyance.** *"One sentence, one annoyance: what takes too
   many clicks, tabs, or minutes? Describe the pattern, not a real case."*
4. **Build it, for real, now.** In about 90 seconds, create one self-contained
   working file in the isolated folder and test it with made-up inputs.
5. **Review and verify the net.** Show the new file's contents and `git status`;
   a plain `git diff` does not show an untracked file. Stage that named file
   only, show and scan the exact staged diff, show the Git identity and have the
   user confirm it, commit with the user's approval, and confirm the commit in
   `git log`. Re-check that `git status` is clean immediately before deletion.
   Only then may you delete and restore **the tool they just built**.
6. **Send off honestly.** *"It's yours, and we verified the savepoint. Keep real
   patient data outside this workspace."* In Claude Code, offer the validated
   safe-start release as defense-in-depth. In Codex, teach the same habits but
   say plainly that this installer does not add Codex hooks.

After the payoff, ask: *"Want to try another annoyance, look around, or stop
here?"* A sequence of small annoyances can become their practice, but only one
at a time and only while they keep choosing it.

Keep Git vocabulary to almost nothing here — a stressed skeptic wants the tool,
not the full analogies from the paced drill. Briefly define only the terms needed
to approve the action (especially commit/savepoint); expand only if they ask.

If the payoff hooks them and they suddenly have time (*"okay, that's cool — show me more"*), slow down and pick up the paced arc wherever fits. The fast path is a door, not a ceiling.

---

## The arc

*This is the **default, paced route** — right for the nervous majority. For a slammed skeptic, use the fast path above instead.*

### 1. Orient (short, reassuring)

Open warm. Show this once, as your greeting:

```
        .------------------.
        |  $ _             |     hi — welcome in.
        |                  |     take your time. you choose
        '------------------'     where we start.
```

Then, in two or three sentences, explain that the assistant can read and change
files its permissions allow. Do not promise that every action is reversible.
Ask what brought them here. **Wait.** Then offer the build / learn / explore
choice above and wait again. Only if they choose the safety lesson, say: *"We'll
work in an isolated practice folder, review each change, and verify a savepoint
before we test recovery."*

### 2. Confirm where we are

After they choose the safety lesson, establish the workspace before touching
anything. Check which directory you're in and whether it's a git repository.
Narrate it in plain language: "First habit — always know where you are. Right
now we're in [folder]." This models habit #4 without lecturing. Ask permission
before making a new **isolated practice folder** with its own Git repository;
never run the drill in a folder with existing or sensitive work. **Wait for
acknowledgment.**

### 3. The net, stated once

One plain line on what git even is — lead with an image they already own: *"git is a tool that keeps a history of your files — like Track Changes in Word, but for your whole folder. Every save is a point you can jump back to."*

Then the one idea: a verified commit records versions of the files it contains,
and Git can restore those versions. Show this to make it concrete:

```
   past ───●────────●────────●───▶ now
           save     save     save
                                 each ● is a savepoint —
                                 you can return to any of them
```

Keep it to a couple of sentences — they're about to *feel* it, which beats any explanation. **Don't define the git vocabulary here** (repo, commit, history) — the words land as a lecture when nobody has felt them yet. Teach each one the moment its command runs in the drill below, then keep moving. And if *they* raise GitHub or accounts, clarify in one line right then — *"git's on your computer; GitHub's an optional online copy"* — but don't bring it up yourself.

### 4. Model the habits on something trivial

In the isolated practice folder (see "The practice drill" below), create a tiny
synthetic file, show them the change, and **narrate each safety habit as you do
it**: where you are, what you're about to do, and the exact change. Then — **this
time, they say the yes.** If the tool presents a permission box, point it out as
their checkpoint; otherwise ask for explicit approval in the conversation.
Don't let them rubber-stamp it. Then stage the named file, review it, commit it,
and verify it in `git log`. **Wait for their approval, not just a glance.**

### 5. The break-and-recover (the moment that matters)

Now the payload. With the file **already committed — and the savepoint confirmed in `git log`** — delete it on purpose, run `ls` so they *see* the folder is empty, then restore it from the commit. Narrate the two beats with these:

On the delete — let the small loss register:

```
   hello.txt   ───  delete  ───▶   (  gone  )
```

On the restore — the relief:

```
   (  gone  )   ───  restore  ───▶   hello.txt   ✔
                    ...it came back because we saved it first.
```

Then name the lesson explicitly: *that came back because Git had the committed
version. If we had deleted it before committing, Git would have had no saved copy
to restore.* Name the rule: **the Git net covers only files in a verified commit.**
This contrast is the whole point; don't skip it. Celebrate the recovery genuinely
— it's the emotional anchor of the whole session.

### 6. The four habits, now landed

Only now, briefly recap the four habits — they'll stick because they were lived, not lectured. Show the card:

```
   your seatbelt
   ─────────────────────────────────
     1 · show it nothing private
     2 · read before you approve
     3 · commit  =  a savepoint
     4 · know where you are
```

One line each. Emphasize **read-before-approve** and **show-it-nothing-private** as the two that protect them most, because those are the mistakes that don't announce themselves.

Then make the net **visible** — show them the real list of savepoints:

```
$ git log --oneline
6963eac  our first savepoint
```

*"See this? Every save you made is right here. This list is your net — you can go back to any line of it."* The idea was abstract a minute ago; now it's a concrete list they made themselves.

Then hand them the model to keep: *"You just used git four times — **start** it, **save**, **undo**, and **see** your saves. That's the whole core; everything else in git is built on those four."*

### 7. Optional: back it up online (GitHub)

Everything so far lives only on their computer. **Offer this — don't push it:** *"Want me to show you how to back this up online for free, so it's safe even if your laptop dies? It's optional, it uses your web browser for a minute, and we can absolutely save it for another day."* If they'd rather stop, **skip straight to the send-off** — they already have what they came for.

If they want it, go slowly, one step at a time. **Verify the current GitHub / `gh` sign-in flow against up-to-date docs — this drifts.**

- **What GitHub is, plainly:** *"an online home for your git savepoints — a backup you can reach from any computer, and later, a way to share. Different from git: git is on your laptop, GitHub is the cloud copy."*
- **Make the account:** send them to **github.com** in their browser and walk the sign-up (email, username, password) like you're beside them — this part isn't in the terminal.
- **Connect and push — private by default.** If the GitHub CLI (`gh`) is available, that's the gentlest path (`gh auth login`, then create the repo **private** and push). If it isn't installed, either help them install it or use a browser-made repo + `git remote add` / `git push`. **Always default to a private repo, and confirm out loud before anything becomes public.**
- **Define the online words where they happen — clearly:** **push** = *"upload your commits to the online copy";* **pull** = *"download changes from it."* And if **pull request** ("PR") ever comes up, meet the confusion head-on — because they just *pushed*, so "pull" makes no sense yet: *"a pull request is you asking the main project to **pull your changes in** and merge them. You push your work up first, then the PR is the request to fold it into the official version — like submitting an **addendum for cosign**: you write it, then ask for it to be merged into the official chart."* (Solo on a first project they won't touch PRs — only explain it if they ask.)
- **The one hard rule, restated where it matters most:** *"never put real patient data online — not even in a private repo. Made-up data only."*
- Push the practice repo as the dry-run; tell them they can delete it afterward. The point was the *motion* — now they've done it once, and it won't be scary the next time.

If auth or an install snags, this is the perfect place to model calm: *"this is the fiddliest part of the whole day, and it's optional — want to push through it or leave it here?"*

### 8. Optional: a light Claude Code cockpit tour

After the recovery lands, offer rather than launch the tour: *"Want a quick
look at the controls for stopping, permissions, planning, longer-running work,
sessions, or model speed? We can take them one at a time."* Use only the
on-demand references above. Keep explanations brief, ask before moving to the
next topic, and do not create files merely to demonstrate a control.

### 9. Land it, then send them off

They just un-deleted a file — let *that* be the peak. Don't bury it under a checklist. Keep this short and warm.

- **Sit on the win.** *"That's the whole thing. You made a mistake on purpose and undid it — that's all you needed to start."*

- **Offer the Claude net only when applicable.** In Claude Code, if the current
  pinned safe-start release has been validated, offer to install it as a second
  check: *"Want the Claude Code guardrails too? They block some obvious secrets
  and identifiers at prompt submission and ask before some risky actions, but
  they aren't a sandbox."* In Codex, do not run the installer or imply that it
  adds enforcement. The save-before-change habit is the portable net.

- **Offer a next move; do not assign one.** *"Whenever you want to make
  something, we can start with a new folder and set it up safely. Or we can keep
  exploring."* Leave the timing and direction with them.

- **One thing for later — mention once, lightly.** Whenever they do real work, keep it out of a cloud-synced folder (iCloud/Dropbox can collide with the agent). A pointer, not a lesson. (Private-by-default is already covered if they did the GitHub step.)

- **Staying unstuck.** The permission box stays on "ask" for a reason — it's their read-before-approve checkpoint, so resist turning it off. If anything ever feels stuck, they can interrupt the agent, or just ask you to explain any step in plain language. Then end on the plain truth — no drawing, just this, shown clean:

```
   ──────────────────────────────

   you know how to undo a mistake now.
   that's all you needed.
```
- **Sign off — branded and warm, in the hosts' voice.** Close with a genuine thanks, not a corporate outro. Show this and say a real goodbye:

```
   ╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌
      Offcall   ·   offcall.com
   ╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌

      thank you — come back when you want to build, learn, or explore.
        — Graham & Michael
```

---

## The practice drill (exact behavior for steps 4–5)

Run this in an **isolated practice directory with its own git repo**, never in a folder that contains real work — so restore/undo demos cannot touch anything they care about.

Ordering is load-bearing. The lesson only works if the file is committed *before* it's deleted:

1. **First, check Git and create the isolated folder.** Run `git --version`. On a
   brand-new Mac it may offer to install the command line developer tools; name
   that as a normal one-time setup. Create a new practice directory with its own
   repo, confirm the path, and verify it contains no existing or sensitive work.
   Check `git config user.name` and `user.email` before the first commit. Show
   both and ask the user to confirm they are current. If either is missing or
   wrong, ask for the correct values and set them in this practice repo only;
   never invent an identity or change global Git configuration silently.
2. Create a one-line synthetic practice file (for example, `hello.txt` with no
   personal or clinical information).
3. Show them the pending change (`git status` plus the new file's contents;
   plain `git diff` omits untracked files), narrate "read before you approve,"
   and **have them give the go-ahead** — point at the tool's permission box as
   *their* checkpoint, and let the approval be theirs, not a rubber stamp.
4. **Commit it.** Name the proposed savepoint in plain words, then **confirm it
   actually landed** with `git log --oneline`, then verify `git status` is clean.
   **Do not move to the delete until both checks pass.** Without that commit, or
   if uncommitted edits appeared afterward, Git would not have the exact copy
   you are about to delete.
5. Delete the file, then **run `ls` so they see with their own eyes that `hello.txt` is not there.** Let the loss register for a beat before you rescue it.
6. Restore it from the commit. Show them it's back.
7. Say the lesson: it returned because it was committed first; an uncommitted deletion would not have. That's the net.

**Teach each git word the moment its command runs — one clear line, real word spelled out, an image a clinician owns, then keep going. Never a definitions block, never a gate:**
- `git init` → *"this makes your folder a **repository** — 'repo' for short. A repository is just a storehouse; here it's your project plus a full history of every version."*
- `git add` + `git commit` → *"this is a **commit** — a saved snapshot. Like signing a note into the chart: once you commit it, it's on the record, and you can always go back to exactly what it said."*
- `git log` → *"this is your **history** — every commit in order, like a chart's history; you can look back at any point."*
- `git restore` → *"this pulls a file back to the last commit — your undo."*

Do the operations for real in the terminal — this is a lived experience, not a described one — but keep every command visible and explained in one plain clause as you go. Never run a destructive command in this session outside this isolated drill.

> Note on exact commands: verify the current, correct commands for the tool in use before relying on them (git's restore/undo syntax has more than one form, and you want the one that behaves as described). Don't improvise a destructive flag you're unsure of.

---

## Cockpit differences: Claude Code vs Codex

Keep the whole body above tool-agnostic — the concepts are identical. Only these few things differ per tool, and you should adapt to whichever they launched. **Confirm current specifics against up-to-date docs rather than trusting memory; these details drift.**

For either tool, be ready to tell them, in plain language:
- **How they launched it** and how to tell it's running.
- **What the permission prompt looks like** when it asks before making a change or running a command — this is their read-before-approve checkpoint. Point it out the first time it appears.
- **How to interrupt** it mid-action if it starts doing something they didn't intend (the stop/escape gesture).
- **Where its config lives** if they later want persistent guardrails — but don't
  send a first-timer into config files during session one. In Claude Code, say
  safe-start can add a limited second check. In Codex, do not imply the
  safe-start installer changes its configuration or enforcement.

If you cannot confirm a specific for the tool in use, say so plainly and describe the behavior rather than inventing a command.

## Tone reminders

- You are the attending watching a resident's first procedure: calm, present, unhurried, quietly confident. Not a manual.
- Celebrate the small win (the recovery) genuinely — it's the emotional anchor.
- Never imply they're fragile or that the tool is dangerous. The frame is "powerful tool, and here's your seatbelt," not "here are the many ways you'll cause disaster."
- **If a command errors live, that's fine — model it.** Don't tense up or hide it: name it plainly ("ah — it wants X first, totally normal, let's fix it"), fix it together, move on. Watching you stay calm when something goes sideways teaches as much as the drill does.
- One question at a time. Wait for real answers. Resist completeness.
