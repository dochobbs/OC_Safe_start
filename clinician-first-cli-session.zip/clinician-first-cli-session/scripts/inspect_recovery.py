#!/usr/bin/env python3
"""Inspect lesson recovery state without changing the workspace."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import subprocess
import sys


def git(path: Path, *args: str) -> subprocess.CompletedProcess[str]:
  env = os.environ.copy()
  env["GIT_OPTIONAL_LOCKS"] = "0"
  for variable in (
    "GIT_DIR",
    "GIT_WORK_TREE",
    "GIT_INDEX_FILE",
    "GIT_OBJECT_DIRECTORY",
    "GIT_ALTERNATE_OBJECT_DIRECTORIES",
  ):
    env.pop(variable, None)
  return subprocess.run(
    ["git", "-C", str(path), *args],
    text=True,
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
    env=env,
    check=False,
  )


def main() -> int:
  parser = argparse.ArgumentParser()
  parser.add_argument("--path", required=True, type=Path)
  parser.add_argument("--file", dest="practice_file")
  args = parser.parse_args()

  path = args.path.expanduser().resolve()
  if not path.is_dir():
    print(json.dumps({"path": str(path), "error": "not_a_directory"}))
    return 2

  result: dict[str, object] = {"path": str(path), "git_repository": False}
  root = git(path, "rev-parse", "--show-toplevel")
  if root.returncode != 0:
    git_marker_present = any(
      os.path.lexists(candidate / ".git") for candidate in (path, *path.parents)
    )
    if git_marker_present:
      result["error"] = "git_repository_check_failed"
      print(json.dumps(result, sort_keys=True))
      return 3
    print(json.dumps(result, sort_keys=True))
    return 0

  git_root = Path(root.stdout.strip()).resolve()
  if git_root != path:
    result.update({
      "git_root": str(git_root),
      "error": "path_is_inside_parent_repository",
    })
    print(json.dumps(result, sort_keys=True))
    return 3

  status = git(path, "status", "--porcelain=v1", "--untracked-files=all")
  if status.returncode != 0:
    result.update({"git_root": str(git_root), "error": "git_status_failed"})
    print(json.dumps(result, sort_keys=True))
    return 3
  lines = [line for line in status.stdout.splitlines() if line]
  head_exists = git(path, "rev-parse", "--verify", "HEAD").returncode == 0
  head = git(path, "log", "-1", "--format=%H%x00%s")
  head_info = None
  if head_exists and head.returncode != 0:
    result.update({"git_root": str(git_root), "error": "git_log_failed"})
    print(json.dumps(result, sort_keys=True))
    return 3
  if head_exists and head.stdout.strip():
    sha, _, subject = head.stdout.strip().partition("\0")
    head_info = {"sha": sha, "subject": subject}

  result.update({
    "git_repository": True,
    "git_root": str(git_root),
    "clean": not lines,
    "pending_change_count": len(lines),
    "staged_change_count": sum(1 for line in lines if line[0] not in (" ", "?")),
    "unstaged_change_count": sum(1 for line in lines if len(line) > 1 and line[1] != " "),
    "untracked_count": sum(1 for line in lines if line.startswith("??")),
    "head": head_info,
  })

  if args.practice_file:
    requested = Path(args.practice_file)
    if requested.is_absolute() or ".." in requested.parts:
      print(json.dumps({"path": str(path), "error": "unsafe_file_path"}))
      return 2
    relative = requested.as_posix()
    tracked_result = git(git_root, "ls-files", "--stage", "--", relative)
    if tracked_result.returncode != 0:
      print(json.dumps({"path": str(path), "error": "git_file_check_failed"}))
      return 3
    tracked = bool(tracked_result.stdout.strip())
    in_head = head_info is not None and git(git_root, "cat-file", "-e", "HEAD:%s" % relative).returncode == 0
    file_status = git(
      git_root,
      "status",
      "--porcelain=v1",
      "--untracked-files=all",
      "--",
      relative,
    )
    if file_status.returncode != 0:
      print(json.dumps({"path": str(path), "error": "git_file_status_failed"}))
      return 3

    latest_commit_with_file = None
    if head_info is not None:
      history = git(git_root, "rev-list", "HEAD", "--", relative)
      if history.returncode != 0:
        print(json.dumps({"path": str(path), "error": "git_file_history_failed"}))
        return 3
      for commit in history.stdout.splitlines():
        if git(git_root, "cat-file", "-e", "%s:%s" % (commit, relative)).returncode == 0:
          latest_commit_with_file = commit
          break
    result["practice_file"] = {
      "path": relative,
      "present": (git_root / requested).is_file(),
      "tracked": tracked,
      "present_in_head": in_head,
      "latest_commit_with_file": latest_commit_with_file,
      "status": file_status.stdout.strip() or "clean",
      "simple_unstaged_deletion": (
        len(lines) == 1 and file_status.stdout.rstrip("\n") == " D %s" % relative
        and in_head
      ),
    }

  print(json.dumps(result, sort_keys=True))
  return 0


if __name__ == "__main__":
  raise SystemExit(main())
