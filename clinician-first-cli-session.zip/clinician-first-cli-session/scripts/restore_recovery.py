#!/usr/bin/env python3
"""Restore one inspected lesson-file deletion and verify the result.

This helper is intentionally narrower than ``git restore``.  It will only act
when a fresh inspection still matches the exact repository, full HEAD object
name, and sole ordinary unstaged deletion supplied by the caller.
"""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
from typing import NoReturn


INSPECTOR = Path(__file__).with_name("inspect_recovery.py")
FULL_OBJECT_NAME = re.compile(r"(?:[0-9a-f]{40}|[0-9a-f]{64})\Z")
GIT_ENVIRONMENT = (
  "GIT_COMMON_DIR",
  "GIT_CONFIG",
  "GIT_CONFIG_PARAMETERS",
  "GIT_DIR",
  "GIT_NAMESPACE",
  "GIT_WORK_TREE",
  "GIT_INDEX_FILE",
  "GIT_OBJECT_DIRECTORY",
  "GIT_ALTERNATE_OBJECT_DIRECTORIES",
)


class JsonArgumentParser(argparse.ArgumentParser):
  """Keep invalid invocations machine-readable too."""

  def error(self, message: str) -> NoReturn:
    print(json.dumps({
      "action": "restore_recovery",
      "restored": False,
      "error": "invalid_arguments",
      "detail": message,
    }, sort_keys=True))
    raise SystemExit(2)


def git_environment() -> dict[str, str]:
  environment = os.environ.copy()
  environment["GIT_OPTIONAL_LOCKS"] = "0"
  for variable in GIT_ENVIRONMENT:
    environment.pop(variable, None)
  for variable in tuple(environment):
    if variable == "GIT_CONFIG_COUNT" or variable.startswith((
      "GIT_CONFIG_KEY_",
      "GIT_CONFIG_VALUE_",
    )):
      environment.pop(variable, None)
  return environment


def git(path: Path, *args: str, binary: bool = False) -> subprocess.CompletedProcess:
  return subprocess.run(
    ["git", "-C", str(path), *args],
    text=not binary,
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
    env=git_environment(),
    check=False,
  )


def inspect(path: Path, relative: str) -> tuple[int, dict[str, object]]:
  result = subprocess.run(
    [
      sys.executable,
      str(INSPECTOR),
      "--path",
      str(path),
      "--file",
      relative,
    ],
    text=True,
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
    env=git_environment(),
    check=False,
  )
  try:
    payload = json.loads(result.stdout)
  except (json.JSONDecodeError, TypeError):
    payload = {"error": "invalid_inspector_output"}
  if not isinstance(payload, dict):
    payload = {"error": "invalid_inspector_output"}
  return result.returncode, payload


def finish(
  payload: dict[str, object],
  *,
  error: str | None = None,
  code: int = 0,
) -> int:
  payload["restored"] = error is None
  if error is not None:
    payload["error"] = error
  print(json.dumps(payload, sort_keys=True))
  return code


def canonical_existing_directory(raw: str) -> tuple[Path | None, str | None]:
  expanded = Path(raw).expanduser()
  if not expanded.is_absolute():
    return None, "path_must_be_absolute"
  lexical = Path(os.path.abspath(str(expanded)))
  try:
    canonical = expanded.resolve(strict=True)
  except OSError:
    return None, "not_a_directory"
  if lexical != canonical:
    return None, "path_must_be_canonical"
  if not canonical.is_dir():
    return None, "not_a_directory"
  return canonical, None


def safe_relative_file(raw: str) -> tuple[Path | None, str | None]:
  requested = Path(raw)
  if (
    not raw
    or raw == "."
    or requested.is_absolute()
    or ".." in requested.parts
    or any(ord(character) < 32 for character in raw)
  ):
    return None, "unsafe_file_path"
  return requested, None


def unsafe_file_component(root: Path, requested: Path) -> str | None:
  current = root
  for part in requested.parts[:-1]:
    current = current / part
    if not os.path.lexists(current):
      return "unsafe_file_parent_missing"
    mode = os.lstat(current).st_mode
    if stat.S_ISLNK(mode):
      return "unsafe_file_parent_symlink"
    if not stat.S_ISDIR(mode):
      return "unsafe_file_parent_not_directory"

  target = root / requested
  if os.path.lexists(target):
    if stat.S_ISLNK(os.lstat(target).st_mode):
      return "unsafe_file_symlink"
    return "file_is_not_deleted"
  return None


def head_entry_is_regular_file(root: Path, head: str, relative: str) -> bool:
  tree = git(root, "ls-tree", "-z", "--full-tree", head, "--", relative, binary=True)
  if tree.returncode != 0:
    return False
  entries = [entry for entry in tree.stdout.split(b"\0") if entry]
  if len(entries) != 1:
    return False
  metadata, separator, encoded_path = entries[0].partition(b"\t")
  fields = metadata.split()
  return (
    separator == b"\t"
    and len(fields) == 3
    and fields[0] in (b"100644", b"100755")
    and fields[1] == b"blob"
    and os.fsdecode(encoded_path) == relative
  )


def operation_in_progress(root: Path) -> bool:
  for marker in (
    "MERGE_HEAD",
    "CHERRY_PICK_HEAD",
    "REVERT_HEAD",
    "REBASE_HEAD",
    "rebase-apply",
    "rebase-merge",
    "sequencer",
  ):
    location = git(root, "rev-parse", "--git-path", marker)
    if location.returncode != 0:
      return True
    candidate = Path(location.stdout.strip())
    if not candidate.is_absolute():
      candidate = root / candidate
    if os.path.lexists(candidate):
      return True
  return False


def main() -> int:
  parser = JsonArgumentParser()
  parser.add_argument("--path", required=True)
  parser.add_argument("--file", required=True, dest="practice_file")
  parser.add_argument("--expected-root", required=True)
  parser.add_argument("--expected-head", required=True)
  args = parser.parse_args()

  payload: dict[str, object] = {
    "action": "restore_recovery",
    "restored": False,
    "path": args.path,
    "file": args.practice_file,
    "expected": {
      "git_root": args.expected_root,
      "head_sha": args.expected_head,
    },
  }

  path, path_error = canonical_existing_directory(args.path)
  if path_error is not None or path is None:
    return finish(payload, error=path_error or "not_a_directory", code=2)
  payload["path"] = str(path)

  expected_root, root_error = canonical_existing_directory(args.expected_root)
  if root_error is not None or expected_root is None:
    return finish(payload, error="unsafe_expected_root", code=2)
  if path != expected_root:
    return finish(payload, error="path_root_mismatch", code=3)

  head = args.expected_head
  if FULL_OBJECT_NAME.fullmatch(head) is None:
    return finish(payload, error="expected_head_must_be_full_sha", code=2)

  requested, file_error = safe_relative_file(args.practice_file)
  if file_error is not None or requested is None:
    return finish(payload, error=file_error or "unsafe_file_path", code=2)
  relative = requested.as_posix()
  payload["file"] = relative

  if os.path.islink(path / ".git"):
    return finish(payload, error="unsafe_git_metadata_symlink", code=3)

  before_code, before = inspect(path, relative)
  payload["before"] = before
  if before_code != 0 or before.get("error") is not None:
    return finish(payload, error="inspection_failed", code=3)

  before_head = before.get("head")
  before_file = before.get("practice_file")
  if (
    before.get("path") != str(path)
    or before.get("git_repository") is not True
    or before.get("git_root") != str(expected_root)
    or not isinstance(before_head, dict)
    or before_head.get("sha") != head
    or not isinstance(before_file, dict)
    or before_file.get("path") != relative
  ):
    return finish(payload, error="inspection_binding_mismatch", code=3)

  root_check = git(path, "rev-parse", "--show-toplevel")
  if root_check.returncode != 0:
    return finish(payload, error="git_root_check_failed", code=3)
  try:
    live_root = Path(root_check.stdout.strip()).resolve(strict=True)
  except OSError:
    return finish(payload, error="git_root_check_failed", code=3)
  if live_root != expected_root:
    return finish(payload, error="git_root_mismatch", code=3)

  head_check = git(path, "rev-parse", "--verify", "HEAD^{commit}")
  if head_check.returncode != 0:
    return finish(payload, error="head_check_failed", code=3)
  if head_check.stdout.strip() != head:
    return finish(payload, error="head_mismatch", code=3)

  component_error = unsafe_file_component(path, requested)
  if component_error is not None:
    return finish(payload, error=component_error, code=3)
  if operation_in_progress(path):
    return finish(payload, error="git_operation_in_progress", code=3)

  status = git(
    path,
    "status",
    "--porcelain=v1",
    "-z",
    "--untracked-files=all",
    binary=True,
  )
  expected_status = b" D " + os.fsencode(relative) + b"\0"
  if status.returncode != 0:
    return finish(payload, error="git_status_failed", code=3)
  if status.stdout != expected_status:
    return finish(payload, error="not_sole_unstaged_deletion", code=3)
  if (
    before.get("pending_change_count") != 1
    or before.get("staged_change_count") != 0
    or before.get("unstaged_change_count") != 1
    or before.get("untracked_count") != 0
    or before_file.get("status") != " D %s" % relative
    or before_file.get("simple_unstaged_deletion") is not True
    or before_file.get("present") is not False
    or before_file.get("present_in_head") is not True
  ):
    return finish(payload, error="not_sole_unstaged_deletion", code=3)
  if not head_entry_is_regular_file(path, head, relative):
    return finish(payload, error="head_entry_is_not_regular_file", code=3)

  payload["command"] = {
    "source": head,
    "worktree_only": True,
  }
  restore = git(
    path,
    "restore",
    "--source=%s" % head,
    "--worktree",
    "--",
    relative,
  )
  after_code, after = inspect(path, relative)
  payload["after"] = after

  if restore.returncode != 0:
    payload["git_stderr"] = restore.stderr.strip()
    return finish(payload, error="git_restore_failed", code=4)

  target = path / requested
  target_is_regular = False
  if os.path.lexists(target):
    target_is_regular = stat.S_ISREG(os.lstat(target).st_mode)
  after_head = after.get("head") if isinstance(after, dict) else None
  after_file = after.get("practice_file") if isinstance(after, dict) else None
  if (
    after_code != 0
    or after.get("error") is not None
    or after.get("path") != str(path)
    or after.get("git_root") != str(expected_root)
    or not isinstance(after_head, dict)
    or after_head.get("sha") != head
    or after.get("clean") is not True
    or after.get("pending_change_count") != 0
    or not isinstance(after_file, dict)
    or after_file.get("path") != relative
    or after_file.get("present") is not True
    or after_file.get("present_in_head") is not True
    or after_file.get("status") != "clean"
    or not target_is_regular
  ):
    return finish(payload, error="post_restore_verification_failed", code=5)

  return finish(payload)


if __name__ == "__main__":
  try:
    raise SystemExit(main())
  except OSError as error:
    print(json.dumps({
      "action": "restore_recovery",
      "restored": False,
      "error": "operating_system_error",
      "detail": error.strerror or error.__class__.__name__,
    }, sort_keys=True))
    raise SystemExit(3)
