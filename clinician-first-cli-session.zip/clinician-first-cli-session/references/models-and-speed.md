# Models and speed

Confirm availability and current behavior against the active tool's official
documentation; these controls vary by account, model, surface, and version.

- **`/model`:** choose the model for the current session.
- **`/effort`:** adjust how much reasoning the selected model uses when
  supported.
- **`/fast`:** favor faster responses, potentially using the subscription
  allowance more quickly.

In Codex, `/model` selects the model and available reasoning effort, while
`/fast` toggles the current model's Fast service tier when the catalog exposes
one. Do not teach Claude-only `/effort` as a Codex command.

Recommend leaving the defaults alone unless the user has a concrete reason to
change them. Do not turn this into a model-comparison lecture.
