# Models and speed in Claude Code

Confirm availability and current behavior against official Claude Code
documentation; these controls vary by account, model, and version.

- **`/model`:** choose the model for the current session.
- **`/effort`:** adjust how much reasoning the selected model uses when
  supported.
- **`/fast`:** favor faster responses, potentially using the subscription
  allowance more quickly.

Recommend leaving the defaults alone unless the user has a concrete reason to
change them. Do not turn this into a model-comparison lecture.
