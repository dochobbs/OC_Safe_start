# Claude Code and Codex controls

Confirm the installed version when a control has changed. Use only the active
tool's syntax; the lesson behavior and approval gates remain the same.

## Start the lesson

- **Claude Code:** enter `/clinician-first-cli-session`.
- **Codex CLI or IDE:** enter `$clinician-first-cli-session`, or use `/skills`
  and select **Clinician-first CLI session**.

Both tools may also activate the lesson from a matching first-time request. For
a predictable first session, prefer the explicit invocation above.

## Move into a newly approved project folder

Folder creation, relocation, and verification remain separate user turns.

- **Claude Code:** ask the user to enter `/cd <absolute-path>` when that command
  is available. If it is unavailable, exit and relaunch Claude Code in the
  approved folder.
- **Codex CLI:** preserve the chat with `/rename first-cli-session`, exit, then
  run `codex -C "<absolute-path>" resume --last`. This changes the workspace and
  resumes the saved chat. Do not claim relocation until the user reports that
  Codex reopened there.
- **Codex IDE or desktop app:** ask the user to open the approved folder as the
  active workspace, then return to or resume the same chat.

After the user confirms relocation, run only `pwd -P` as the next action. Never
use shell `cd`, `git -C`, or absolute-path writes from the old workspace as a
substitute for changing the active workspace.

## Review and interruption controls

- **Claude Code:** use the installed permission prompt and mode selector. `Esc`
  interrupts the current response or tool call; `Ctrl+C` cancels the current
  operation.
- **Codex:** use `/permissions` in the CLI or the permissions control beneath
  the composer in the IDE or desktop app. Keep **Ask for approval** for the
  first session. `Ctrl+C` interrupts current CLI work.
- **Either tool:** use `/plan` before a larger or uncertain change. Plan mode is
  a review aid, not a sandbox or security boundary.

When a prompt offers approval scopes, recommend the narrowest one-time scope
that permits the named action. Do not weaken permissions to keep a demo moving.

## Pause, rename, and return

- **Claude Code:** `/rename` names the session and `/resume` returns to it.
- **Codex CLI:** `/rename` names the chat and `/resume` opens the saved-session
  picker. From the shell, `codex resume` opens the picker and
  `codex resume --last` resumes the latest chat.

Session history is not a file backup. Re-inspect the project state on return and
use verified Git history for durable file recovery.

## Persistent safety boundary

The lesson installs natively for both tools. `safe-start` and its hooks remain
Claude Code-only. In Codex, rely on Codex's sandbox, approval controls, the
lesson's one-action review behavior, and verified Git savepoints; never claim
the installer added Codex hooks or enforcement.
