# Optional teaching aids

Load this file only when the user asks for visual or expanded teaching and has
not requested a terse, no-analogy, or no-decoration style. The execution order,
safety gates, and handoff facts remain authoritative in `SKILL.md`.

## Commit timeline

```text
past --- save --- save --- save ---> now
                    each save is a verified commit
```

## Recovery sequence

```text
useful tool --- approved delete ---> gone
gone ------- guarded restore ------> useful tool
```

Explain literally: the file came back because Git had its committed version. An
untracked file deleted before its first commit would not have a Git copy.

## Four habits

1. Show the agent nothing private.
2. Read each action before approving it.
3. Treat only a verified commit as a Git savepoint.
4. Know the exact physical project path.

## Expanded handoff layout

Use only when the user's response budget permits it. Fill every field from real
tool results; omit decorative branding if it would distract from the run command.

```text
Project:            /Users/name/Projects/tool-name
Main file:          /Users/name/Projects/tool-name/tool.html
Run:                open -a Safari "/Users/name/Projects/tool-name/tool.html"
Synthetic tests:    [inputs] -> [verified outputs] | not checked
Verified commit:    abc1234 message | not committed | not checked
Status:             clean | [exact pending paths] | not checked
GitHub:             not pushed | [visibility, URL, and commit] | not checked
safe-start:         verified | installed, unverified | not installed | not checked
Clinical boundary:  non-clinical | unvalidated learning prototype
```
