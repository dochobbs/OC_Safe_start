# Git and GitHub: the travel framework

Use the episode's shared metaphor only when the user welcomes analogies. If they
ask for literal language, teach the same facts without metaphor. Reveal only the
concepts needed now; never present all eight steps as a required workflow.

## The mental models

- **The terminal is a foreign country:** the graphical apps they already know
  are the tourist district; the command line is where the locals live. They do
  not need fluency before the first trip. A handful of phrases plus a guide gets
  them remarkably far.
- **Claude is the local:** it speaks both ordinary language and terminal. The
  user can ask where they are, what a command means, or how to get somewhere;
  they do not have to memorize the language first.
- **Git is the travel journal:** a local record of important places reached,
  what changed along the way, and how to return to a recorded point. Each
  commit is a dated entry showing what the project looked like then. A branch
  is a side road for exploring separately.
- **GitHub is the home base:** an optional online home for Git history, sharing,
  collaboration, and review. Work reaches it only when pushed; it is not
  automatic cloud sync.
- **Claude is the guide; the command line is the terrain:** Claude can suggest
  directions and explain obstacles, while the terminal is where the user sees
  and approves the actual movement through files and history.

Use the phrasebook idea lightly: teach only the few words needed for the current
trip. The purpose is to help them travel, not make them study the language
before they leave.

Keep one accuracy boundary explicit: local Git commits are restore points, not
a separate-device backup. A reviewed remote copy can add backup value, but no
Git or GitHub framing makes patient data appropriate to upload.

## The version pipeline

Teach the pipeline in layers:

1. **Repository** — the project and its recorded history.
2. **Status** — what has changed right now.
3. **Staging** — the exact selected changes for the next savepoint.
4. **Commit** — the saved entry in local history.
5. **Push** — send commits to the chosen remote home.
6. **Branch** — work on a separate line of history.
7. **Pull request** — ask for a proposed branch to be reviewed and folded into
   the shared project.
8. **Merge** — integrate the approved histories.

The opening recovery lesson needs only steps 1 through 4. Add step 5 only if the
user chooses the optional GitHub path. Explain steps 6 through 8 only if they
ask, are collaborating, or are ready to explore beyond the first lesson.
