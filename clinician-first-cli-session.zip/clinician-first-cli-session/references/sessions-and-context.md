# Sessions and context

Confirm exact commands against the installed Claude Code or Codex version.
Teach only the command relevant to the user's immediate need.

- **`/compact`:** condense a long conversation while continuing the same task.
- **`/clear`:** start fresh when switching to unrelated work.
- **`/resume`:** return to an earlier session.
- **`/rename`:** give an important session a recognizable name so it is easier
  to find later.

Use the same session while working on the same task. Do not imply that session
history is a file backup; Git and other backups protect files.

## Pause protocol

When the user asks to pause:

1. Stop immediately. Do not finish the current beat or persuade them to stay.
2. Do not start another write, commit, or delete operation. The only possible
   mutation after a pause request is one explicitly approved restoration under
   the narrow condition in step 5.
3. If they say “no more commands” or equivalent, run nothing; report the last
   verified state and mark the current state unknown. If no verified state is
   visible, say plainly that folder, file, and Git state are unknown; do not
   claim nothing was started, nothing is pending, or no savepoint exists.
   Otherwise, if the practice folder is known, run only state-inspection checks.
   Resolve the bundled script
   relative to the loaded `SKILL.md` directory (commonly
   `~/.claude/skills/clinician-first-cli-session/scripts/inspect_recovery.py`)
   and run `python3 <script> --path <folder> --file <practice-file>`. If it is
   unavailable, use only equivalent checks for the four pause-card fields. Do
   not query or report Git identity, remotes, file contents, or unrelated
   metadata. If checks fail, label the state unknown.
4. Give a short pause card: folder, pending-change count, latest verified commit
   or “none verified,” and whether the practice file is present.
5. Offer restoration only when the practice file is the sole ordinary unstaged
   deletion and its exact version exists in the named commit. Never use the
   simple restore path for a staged deletion, rename, merge conflict, combined
   staged/unstaged state, or unrelated pending changes. Do not restore without
   explicit approval. After approval, run the inspector again immediately. Go
   ahead only if the folder, Git root, `HEAD`, file path, and sole-deletion state
   still match the pause card. Restore that named file's worktree copy from the
   named commit with `git restore --source=<full-sha> --worktree -- <file>`,
   without changing the index, then inspect once more and report the result. Do
   not use plain `git restore`. If anything drifted or a check fails, stop and
   explain that the state needs review; never force or overwrite through the
   mismatch.
6. Offer to name the session `first-cli-session` using the current tool's
   verified rename command. Explain the current tool's resume command and shell
   fallback, including returning to the same folder. End the turn without the
   lesson-completion message or branded completion sign-off.

## Return in the original session

On `/resume`, use the conversation only as a clue. Re-run the read-only state
check before acting because files may have changed while Claude was closed.
Recap the verified state in one or two lines, then ask: *"Continue where we
stopped, restart the lesson, explore something else, or stop?"*

## Return in a fresh session

If the user says they are returning but did not resume the original session:

1. Offer `/resume` first. If they prefer to continue here, proceed without
   pressuring them to switch sessions.
2. Confirm the prior practice folder. If the current folder is not clearly it,
   ask for its path; do not search broad personal directories.
3. Inspect folder and Git metadata read-only with the bundled inspector. If it
   is unavailable, use only equivalent checks needed for the state card.
   Preserve all partial work. Do not query or report Git identity, remotes, or
   unrelated metadata, and do not open the practice file or read its
   working-tree or committed contents merely to reconstruct lesson state.
4. Use only evidence-based conclusions:
   - A tracked deletion whose version exists in `HEAD` is recoverable from that
     commit; offer restoration. If it exists only in an earlier commit, name the
     exact commit and explain that the current `HEAD` no longer contains it.
   - Uncommitted or untracked work has no verified Git savepoint; do not delete,
     overwrite, stage, or recreate it while reconstructing state.
   - A clean repo with the practice file present could be either before the
     delete demonstration or after restoration. Ask; never repeat the drill
     automatically.
   - No repository or no commit means no verified lesson savepoint.
   - A nested folder that merely belongs to a parent repository is not the
     isolated lesson repo. Treat the lesson state as unknown and ask for the
     intended folder.
5. If a narrow recoverable deletion is verified, say separately: *"A copy exists
   in commit `<short-sha>`. I can restore that file if you ask; I have not done
   so."* Then offer these meanings without embellishment:
   - **Continue** — ask what they want to do from the verified state before any
     mutation.
   - **Restart** — start over later in a new, separate folder; keep this folder
     untouched.
   - **Explore** — answer questions without a set lesson path.
   - **Stop** — leave the current state untouched.
6. If they say the lesson was already completed, accept that and do not replay
   it. Present the choices neutrally: do not recommend continuing, call the next
   beat a payoff, estimate how quick it would be, or add a personal hunch about
   what they should choose. Do not turn inspected state into invented lesson
   history. A missing recoverable file does not prove that restoration was the
   next step or that they were "about to" do anything. Never label restoration
   the "undo beat," "natural next step," or the meaning of **continue** in a
   fresh session.

If they choose **restart**, preserve the partial folder untouched. Explain that
restart means creating a new uniquely named isolated practice folder, and do so
only after approval. Never reset, clean, overwrite, or reuse the partial folder
as part of restarting.
