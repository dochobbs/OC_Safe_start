# Sessions and context in Claude Code

Confirm exact commands against the installed Claude Code version. Teach only
the command relevant to the user's immediate need.

- **`/compact`:** condense a long conversation while continuing the same task.
- **`/clear`:** start fresh when switching to unrelated work.
- **`/resume`:** return to an earlier session.
- **`/rename`:** give an important session a recognizable name so it is easier
  to find later.

Use the same session while working on the same task. Do not imply that session
history is a file backup; Git and other backups protect files.
