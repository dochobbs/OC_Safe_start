# Sessions and context

Confirm exact commands against the installed Claude Code or Codex version.
Teach only the command relevant to the user's immediate need.

- **`/compact`:** condense a long conversation while continuing the same task.
- **`/clear`:** start fresh when switching to unrelated work.
- **`/resume`:** return to an earlier session.
- **`/rename`:** give an important session a recognizable name so it is easier
  to find later.

Use the same session while working on the same task. Do not imply that session
history is a file backup; Git and other backups protect files.

## Inspector state-card rendering

A successful pause or return inspection starts immediately with exactly four
bullet lines and no intro, heading, or question:

- **Folder / repository:** exact folder and repository result
- **Pending changes:** exact count and narrow summary
- **Latest verified commit:** short SHA and subject, or none verified
- **Practice file:** exact presence/recoverability result

For a clean repository with the file present and tracked, the fourth field must
say: **“present and tracked; current metadata cannot distinguish before deletion
from after restoration.”** Do not call it recoverable merely because it is in
`HEAD`. Only when `simple_unstaged_deletion` is true may the card add exactly:
*“A copy exists in commit `<short-sha>`. I can restore that file if you ask; I
have not done so.”* Add no other restore claim.

## Pause protocol

When the user asks to pause:

1. Stop immediately. Do not finish the current beat or persuade them to stay.
   This stops teaching and mutation. Run no command by default; inspect only
   when the user explicitly allows it and both folder and filename are known.
2. Do not start another write, commit, or delete operation. The only possible
   mutation after a pause request is one explicitly approved restoration under
   the narrow condition in step 5.
3. Unless the user explicitly allows the inspection described below, run
   nothing and output only three lines:
   **“Current state: unknown; I have not rechecked it.”**; **“Last verified state: [facts]”** or **“Last verified state:
   none available.”**; and **“Paused. `/rename` names this session; `/resume`
   returns to it later.”** Do not claim nothing was started, nothing is pending,
   or no savepoint exists. Only if the user
   explicitly allows one read-only inspection and
   both the practice folder and filename are known, resolve the bundled script
   from the exact **Reviewed helper base directory for
   clinician-first-cli-session** supplied in the current system context. Copy
   that base exactly; never substitute the staged `.claude/skills` directory,
   a home alias, a copied helper, or a temporary wrapper. The matching helper is
   already reviewed and externally bound: never Read, cat, hash, copy, or
   otherwise inspect its source during the lesson. Run
   `python3 <base>/scripts/inspect_recovery.py --path <folder> --file
   <practice-file>`. If the reviewed helper base or helper is
   unavailable or fails, label current state unknown; do not substitute ad hoc
   checks. Never query or report identity, remotes, contents, or extra metadata.
4. Render the shared exact four-field card above and only its permitted optional
   restore sentence.
5. End the inspected-pause result with exactly: *“Paused. `/rename` names this
   session; `/resume` returns to it later.”* Add no question, shell fallback,
   lesson interpretation, or other action. If the user later asks to restore,
   use it only when the file is still the sole ordinary unstaged deletion in the
   named commit; never use it for a staged deletion, rename, conflict, mixed
   state, or unrelated change. After explicit approval, invoke only
   `python3 <base>/scripts/restore_recovery.py
   --path <folder> --file <practice-file> --expected-root <full-root>
   --expected-head <full-sha>`. The helper binds the operation to that root and
   SHA, re-inspects immediately, performs only the exact-SHA worktree restore,
   then inspects again. Never issue `git restore` directly or inspect the helper
   source first. On mismatch or
   failure, report that state needs review; never force through it.
6. The restore-helper result follows its own exact three-bullet stop shape. Any
   additional resume explanation belongs to a later user turn.

The restore transaction above applies during the lesson, at pause, and in same-
or fresh-session recovery. There is no direct restore shortcut.

## Return in the original session

On `/resume`, or ordinary language such as “I'm back” or “continue where we
stopped,” use the conversation only as a clue. Unless commands are forbidden or
the folder or filename is unknown, run the bundled inspector as the sole first
action before any state claim, completion claim, or menu. Files may have changed
while Claude was closed. Use the closed-form return response below. If commands
are forbidden, say current state is unknown and report only clearly labeled
last-verified state; do not present it as current.

## Return in a fresh session

If the user says they are returning but did not resume the original session:

1. If they have not already chosen to continue here, output exactly: *“Use
   `/resume` to reopen the earlier session, or say ‘continue here.’”* and stop.
   Once they choose here, skip that line and proceed without pressure.
2. Confirm the prior practice folder. If the current folder is not clearly it,
   ask for its path; do not search broad personal directories.
3. Inspect folder and Git metadata read-only with the bundled inspector. If it
   is unavailable or fails, label current state unknown and stop; do not replace
   it with ad hoc commands. Preserve all partial work. Do not query identity, remotes, or
   unrelated metadata, and do not open the practice file or read its
   working-tree or committed contents merely to reconstruct lesson state.
4. Use only evidence-based conclusions:
   - Only when `simple_unstaged_deletion` is true may you use the exact restore
     sentence above. A tracked deletion amid any other change gets no restore
     offer; preserve it for review. Do not search earlier history.
   - Uncommitted or untracked work has no verified Git savepoint; do not delete,
     overwrite, stage, or recreate it while reconstructing state.
   - For a clean repo with the practice file present, say in that field that
     current metadata cannot distinguish before deletion from after restoration.
     Use the neutral menu; do not ask a chronology question or repeat the drill.
   - No repository or no commit means no verified lesson savepoint.
   - A nested folder that merely belongs to a parent repository is not the
     isolated lesson repo. Label current state unknown and stop. Ask for the
     intended folder only on a later user turn.
5. Render the shared exact four-field card and only its permitted optional restore
   sentence. Then offer these meanings without embellishment:
   - **Continue** — ask what they want to do from the verified state before any
     mutation.
   - **Restart** — start over later in a new, separate folder; keep this folder
     untouched.
   - **Explore** — answer questions without a set lesson path.
   - **Stop** — leave the current state untouched.
6. Do not add chronology or a lesson-phase interpretation. Never say “got as far
   as,” “break half,” “still need to,” or “next step.” A state card proves only
   current metadata, not where the lesson stopped. If they say the lesson was
   already completed, accept that and do not replay
   it. Present the choices neutrally: do not recommend continuing, call the next
   beat a payoff, estimate how quick it would be, or add a personal hunch about
   what they should choose. Do not turn inspected state into invented lesson
   history. A missing recoverable file does not prove that restoration was the
   next step or that they were "about to" do anything. Never label restoration
   the "undo beat," "natural next step," or the meaning of **continue** in a
   fresh session.

If they choose **restart**, preserve the partial folder untouched. Explain that
restart means creating a new uniquely named isolated practice folder, and do so
only after approval. Never reset, clean, overwrite, or reuse the partial folder
as part of restarting.
