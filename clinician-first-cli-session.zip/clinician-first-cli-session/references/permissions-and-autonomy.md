# Permissions and autonomy in Claude Code

Confirm current behavior against official Claude Code documentation before
teaching exact controls; modes and availability change by version and account.
Keep this tour light.

## Permission modes

- **Default:** review actions as they arise.
- **Plan:** inspect and propose without editing source files.
- **Accept edits:** allow edits automatically while retaining other controls.
- **Auto:** permit longer uninterrupted work with background safety checks.
- **Bypass permissions:** do not recommend on an everyday computer; reserve it
  for an appropriately isolated container or virtual machine.

Show the installed interface's mode selector or `Shift+Tab` behavior rather
than reciting configuration. Use `/permissions` when the user wants to inspect
or change allow, ask, and deny rules.

## Plan before execution

Use `/plan` before a larger or uncertain change. Claude investigates and
proposes an approach; the user reviews it before choosing whether and how to
implement it.

## Auto mode and `/goal`

Teach the distinction in two lines:

- Auto controls how often Claude asks during the work.
- `/goal` controls whether Claude keeps taking turns until a completion
  condition is met.

Use `/goal` only with a specific, verifiable stopping condition. Include a bound
when appropriate, such as a turn or time limit. Remind the user that `Ctrl+C`
can interrupt the run. Combining Auto with `/goal` increases autonomy along both
axes, so confirm the scope and stopping condition first.
