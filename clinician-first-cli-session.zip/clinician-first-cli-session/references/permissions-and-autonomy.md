# Permissions and autonomy in Claude Code

Confirm current behavior against official Claude Code documentation before
teaching exact controls; modes and availability change by version and account.
Keep this tour light.

For a broad first-session permissions question, default to at most four lines
total. When all four topics are requested, use this exact compact structure,
adapting a label only when the installed interface visibly differs:

- Keep **Manual** (`default`) visible; `Shift+Tab` cycles the installed modes.
- Use `/plan` to inspect and propose before larger work; it is a review aid, not
  a sandbox or security boundary.
- Auto mode changes how often Claude asks; `/goal` changes whether it keeps
  taking turns toward a verifiable stopping condition.
- `Ctrl+C` cancels the current operation; `Esc` interrupts Claude's current
  response or tool call, so do not substitute Esc when asked specifically for
  the run-interrupt control.

If they ask about only one control, answer only that control. Expand only when
they ask.
Call it **Auto mode**, not `/auto`; in the CLI it is selected through the current
mode control (commonly `Shift+Tab`) when the account supports it.

If the user sets a sentence or line cap, count the entire response—intro,
bullets, and closing. Use only the requested lines and do not append a follow-up
question outside the cap.

## Permission modes

- **Default:** labeled **Manual** in the current interface; review actions as
  they arise.
- **Plan:** inspect and propose without editing source files.
- **Accept edits:** allow edits automatically while retaining other controls.
- **Auto:** permit longer uninterrupted work with background safety checks.
- **Bypass permissions:** do not recommend on an everyday computer; reserve it
  for an appropriately isolated container or virtual machine.

Show the installed interface's mode selector or `Shift+Tab` behavior rather
than reciting configuration. Use `/permissions` when the user wants to inspect
or change allow, ask, and deny rules.

## Plan before execution

Use `/plan` before a larger or uncertain change. Claude investigates and
proposes an approach; the user reviews it before choosing whether and how to
implement it. Plan is a review aid, not a sandbox or security boundary; proposed
shell actions still require the applicable permission review.

## Auto mode and `/goal`

Teach the distinction in two lines:

- Auto controls how often Claude asks during the work.
- `/goal` controls whether Claude keeps taking turns until a completion
  condition is met.

Use `/goal` only with a specific, verifiable stopping condition. Include a bound
when appropriate, such as a turn or time limit. Remind the user that `Ctrl+C`
can interrupt the run. Combining Auto with `/goal` increases autonomy along both
axes, so confirm the scope and stopping condition first.
