# Basic use and safety

Use only the section the user asks about. Keep it conversational and brief.

## Folder scope and Git

- Show the current folder before acting.
- Start Claude in the intended project folder; keep one project per folder when
  practical.
- Initialize Git in that folder so its savepoints cover the intended project.

## Stop or pause

- Use `Ctrl+C` to interrupt current work.
- Decline a permission request whenever it is unclear or unwanted.
- Say *"Stop"* or *"Explain before continuing"* to hand control back.

## Unclear permission or command

Do not ask the user to decode terminal syntax. Suggest: *"Explain what this will
do in plain language."* Continue only after they understand and choose to
approve it.

## Sensitive information

Keep real or re-identifiable patient information outside the workspace and
model context. Do not paste passwords or API keys into the conversation. When a
project needs a secret, ask Claude how to store it safely rather than placing it
in a prompt or ordinary project file.

## Errors

Normalize errors without launching a blind chain of fixes. Suggest: *"What does
this error mean, and what's the safest next step?"* Explain one next step and
wait.
