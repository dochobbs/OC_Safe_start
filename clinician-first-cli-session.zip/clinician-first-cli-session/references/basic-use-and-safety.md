# Basic use and safety

Use only the section the user asks about. Keep it conversational and brief.

## Folder scope and Git

- For an existing project or a non-Build action, show the current folder before
  acting. During the staged Build setup below, do not run `pwd` before the
  approved folder-creation action.
- Start the active coding agent in the intended project folder; keep one project
  per folder when practical.
- When the user chooses a Git-backed savepoint or the ordinary Build/Learn
  route, initialize Git in that folder so its savepoints cover the intended
  project. Git is not a prerequisite for the explicitly approved, one-file
  payoff in the slammed-skeptic fast path below.
- The repository must exist before identity is checked. Before its first commit,
  check and confirm the user's chosen repository-local `user.name` and
  `user.email`; never silently inherit or invent an identity. During setup-only
  planning, explain this timing without performing the check.
- Use a durable, user-approved folder. `/tmp`, `/private/tmp`, and paths that
  resolve into an operating-system temporary tree are never fallback project
  locations. After a permission denial, stop; later ask for access, a relaunch,
  or a different durable path.

## Stop or pause

- Use `Ctrl+C` to interrupt current work.
- Decline a permission request whenever it is unclear or unwanted.
- Say *"Stop"* or *"Explain before continuing"* to hand control back.

## Unclear permission or command

Do not ask the user to decode terminal syntax. Suggest: *"Explain what this will
do in plain language."* Continue only after they understand and choose to
approve it.

## Sensitive information

Keep real or re-identifiable patient information outside the workspace and
model context. Do not paste passwords or API keys into the conversation. When a
project needs a secret, ask Claude how to store it safely rather than placing it
in a prompt or ordinary project file.

## Errors

Normalize errors without launching a blind chain of fixes. Report the error and
stop that turn. If the user asks on a later turn, explain it and propose one
safe option.

## Manual verification when tools are unavailable

When you cannot execute checks in the current session, ask the user to run one
exact check and wait for their reported output. Only output the user actually
reports is evidence. Never print, format, infer, or summarize a command result
as though you observed it. “Finished,” “ready,” or “it worked” is not the result
of `git --version`, `pwd -P`, or a repository-state check; ask for the fresh
output before advancing. You may summarize it only after the user reports it.

In an explicitly conversational-only setup-and-location session, ask separately
for the fresh Git version, physical path, and repository state, and wait after
each. Active-session metadata is not a substitute for the user's physical-path
report in that mode. Ask for a check without quoting, paraphrasing, or explaining
any possible output before the user reports it. A pathname alone never proves
that a folder is durable, temporary, cloud-synced, or not cloud-synced; label
those properties **not checked** unless separate evidence establishes them.
Before stopping, explain that repository-local Git identity is checked only
after the repository exists and before its first commit; do not request or
configure it yet. Leave safe-start as not installed or unverified unless
separately proved.

Conversational-only means no tool-shaped output at all. If the user says to
record, note, or remember a location while forbidding files, repeat it in the
conversation only. Never call or imitate `Write`, create hidden Claude memory,
or claim a file was saved. At the setup-only close, report the requested facts
and stop without proposing folder creation, Git initialization, or a build.

## One-action Build setup

For the ordinary Git-backed Build/Learn route, when the user asks for one action
at a time, folder creation is closed-form:

- Submit exactly one Bash request: `mkdir -- "<approved absolute path>"`.
- Agreement that a folder location works approves path selection only. Ask
  separately whether you may create that exact path, explain the first
  permission prompt if requested, stop, and require fresh explicit creation
  approval before submitting `mkdir`.
- Do not add `-p`, `&&`, `ls`, `stat`, `pwd`, an existence check, or any other
  command. A successful `mkdir` exit is sufficient evidence for this step.
- Report only **“Folder: `<approved absolute path>` created.”** and stop. After
  any tool response, make no second tool call until a new user message arrives.
- After relocation and working-folder verification, submit one Bash request
  exactly: `git init`. It takes no arguments and must run in the approved destination,
  but only after a fresh user turn explicitly approves repository initialization.
  “What's next?”, an acknowledgment, and a pacing or scope correction are not
  approval. That approval is one-shot and cannot authorize a file write.
- Within this ordinary Git-backed route, successful repository initialization
  is a hard gate: before it, do not preview or write file content. On failure or
  denial, report that result and stop.
- Ask separately for fresh approval to create the exact named file. A write
  approval applies only to that file and content, once.

The slammed-skeptic fast path is the narrow exception. After the exact durable
folder is created, the active tool's verified relocation flow has made it the
workspace, and the physical working folder is verified, honor an explicit
refusal of Git. If the user then freshly approves
one exact named payoff file, create only that file without arguing for or
running `git init`. That approval authorizes no Git action. After the write,
the test-input gate is closed until a nominal synthetic example is user-supplied:
ask only for the smallest made-up example and stop; do not give a Safari command
or invent or substitute any nominal value. Offer
neutral choices only after the observed test; request Git initialization only if the user later
chooses the Git savepoint. For a five-minute user, before the first optional Git
or recovery action, state once that reviewed saving or recovery may take longer
than five minutes when setup or approvals require it.

## Named Git savepoint review

After a separate Git choice, stage only named paths. For every staged path, run
both `git diff --cached --check -- <path>` and the actual review
`git diff --cached -- <path>`. Never try a broad `git diff --cached` or broad
`git diff --cached --check` first. Commit with one plain
`git commit -m "<message>"`; do not add a second `-m`, a trailer, or a
`Co-Authored-By` line.

When the user asks for one action at a time, each savepoint action waits for a
fresh user turn: status, named stage, each per-path check, each per-path review,
identity read or configuration, commit, and final verification. Never batch a
stage with its check or review.
